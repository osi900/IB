<template>
	<div class="modal fade" data-backdrop="static" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header text-center">
					<h5 class="modal-title w-100 m-1 py-2 font-weight-bold text-primary">
						【{{title}}】
						<button type="button" class="close float-right" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</h5>
				</div>
				<div class="modal-body">
					<template v-if="info.tabs">
						<!-- 頁簽 -->
						<ul class="nav nav-tabs card-header-tabs pull-right" role="tablist" style="margin-bottom:0;">
							<li v-for="(tab, i) in info.tabs" class="nav-item">
								<a :tab-id="'Tab_' + i" :class="'nav-link ' + (tabIdx == i ? ' active' : '')" data-toggle="tab" :href="'#Tab_' + i" role="tab" aria-controls="cusincome" aria-selected="true">{{ tab.name }}</a>
							</li>
						</ul>
						<div class="tab-content" style="width:100%; min-width: 100%; height:400px;overflow-y: auto;">
							<div :id="'Tab_' + i" v-for="(tab, i) in info.tabs" :class="'tab-pane fade ' + (tabIdx == i ? 'show active' : '')" style="width:100%; min-width: 100%; height:400px;" :role="'tabpane' + i" :aria-labelledby="'tab'+i+'-tab'">
								<div style="height: 100%"></div>
							</div>
						</div>
					</template>
					<template v-if="!info.tabs">
						<div id="chart" style="width:100%; min-width: 100%; height:400px;overflow-y: auto;overflow-y: auto;">
							<div style="width:100%; min-width: 100%; height:400px;"></div>
						</div>
					</template>
				</div>
			</div>
		</div>
	</div>
</template>

<style scoped>
@import '@/assets/css/style.css';

</style>
<script type="ts" src="./ChartModal.ts"></script>