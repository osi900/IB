<template>
		<ChartTabs @showModal="showModal">
			<span slot="title">{{ title }}</span>
			<!-- 頁簽 -->
			<ul slot="tabs" class="nav nav-tabs card-header-tabs pull-right" role="tablist">
				<li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#ageTab1" role="tab" aria-controls="cusincome" aria-selected="true">年齡層分佈圖</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#ageTab2" role="tab" aria-controls="cusunincome" aria-selected="false">年齡層分佈表</a>
				</li>
			</ul>
			<template slot="chart">
				<div id="ageTab1" style="height: 100%" class="tab-pane fade show active" role="tabpanel" aria-labelledby="tab1-tab">
					<div ref="ageChart" style="height: 100%"></div>		
				</div>
				<div id="ageTab2" class="tab-pane fade" role="tabpanel" aria-labelledby="tab2-tab">
					<a @click="exportExcel" class="sidebar-brand d-flex align-items-end justify-content-end mb-2">
						<div class="sidebar-brand-icon">
							<img class="img-fluid" src="@/assets/img/excel.png" width="25" />
						</div>
					</a>
					<div class="table-responsive" ref="ageTable">
						<table class="table table-bordered table-sm table-striped table-hover">
								<thead class="text-center">
								<tr>
									<th>年齡</th>
									<th>全體戶數</th>
									<th>全體佔比(%)</th>
									<th>受眾戶數</th>
									<th>受眾佔比(%)</th>
								</tr>
							</thead>
							<tbody>
								<tr v-for="(data_, i) in data" v-bind:key="data_.label+'_'+i">
									<td class='label'>{{data_.label}}</td>
									<td style="text-align:right;">{{formatNumber(data_.baseAcctCnt)}}</td>
									<td style="text-align:right;">{{data_.baseProportion}}</td>
									<td style="text-align:right;">{{formatNumber(data_.targetAcctCnt || 0)}}</td>
									<td style="text-align:right;">{{data_.targetProportion || 0}}</td>
								</tr>
							</tbody>
						</table>		
					</div>
				</div>
			</template>
		</ChartTabs>

	
</template>

<script type="ts" src="./AgeChart.ts"></script>
<style scoped>
td.label {
	text-align: center;
}
</style>