package tw.com.fubon.dashboard.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.function.Consumer;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

public class ExcelGenerator {

	/**
	 * 產生Excel
	 * @param func
	 * @return
	 * @throws IOException
	 */
	public static ResponseEntity<Resource> generate(Consumer<Workbook> func) throws IOException {
		try (Workbook workbook = new XSSFWorkbook();
				ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			func.accept(workbook);
			workbook.write(out);
			
			InputStreamResource resource = new InputStreamResource(new ByteArrayInputStream(out.toByteArray()));

		    HttpHeaders headers = new HttpHeaders();
		    String downloadFileName = new String("dummy.xlsx".getBytes("UTF-8"),"ISO-8859-1");
		    headers.setContentDispositionFormData("attachment", downloadFileName);
		    
		    return ResponseEntity.ok()
		            .headers(headers)
		            .contentLength(out.size())
		            .contentType(MediaType.APPLICATION_OCTET_STREAM)
		            .body(resource);
		}
	}
	
}
