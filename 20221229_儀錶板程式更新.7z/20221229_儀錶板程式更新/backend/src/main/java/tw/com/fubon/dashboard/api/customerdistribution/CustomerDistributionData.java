package tw.com.fubon.dashboard.api.customerdistribution;

import java.math.BigDecimal;

public class CustomerDistributionData {
    /** 客戶分群 */
    private String custType;
    /** 全體戶數 */
    private Long allCount = 0L;
    /** 全體占比 */
    private BigDecimal allProportion = BigDecimal.ZERO;
    /** 受眾戶數 */
    private Long targetCount = 0L;
    /** 受眾占比 */
    private BigDecimal targetProportion = BigDecimal.ZERO;

    public String getCustType() {
        return custType;
    }

    public void setCustType(String custType) {
        this.custType = custType;
    }

    public Long getAllCount() {
        return allCount;
    }

    public void setAllCount(Long allCount) {
        this.allCount = allCount;
    }

    public BigDecimal getAllProportion() {
        return allProportion;
    }

    public void setAllProportion(BigDecimal allProportion) {
        this.allProportion = allProportion;
    }

    public Long getTargetCount() {
        return targetCount;
    }

    public void setTargetCount(Long targetCount) {
        this.targetCount = targetCount;
    }

    public BigDecimal getTargetProportion() {
        return targetProportion;
    }

    public void setTargetProportion(BigDecimal targetProportion) {
        this.targetProportion = targetProportion;
    }
}
