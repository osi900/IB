package tw.com.fubon.dashboard.api.taiextradevol;

public class TaiexTradeVolumeData extends TradeVolumeData{}
