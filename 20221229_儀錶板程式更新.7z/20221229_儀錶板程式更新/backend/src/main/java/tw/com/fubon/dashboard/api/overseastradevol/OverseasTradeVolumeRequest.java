package tw.com.fubon.dashboard.api.overseastradevol;

import tw.com.fubon.dashboard.api.RequestBase;

public class OverseasTradeVolumeRequest extends RequestBase {

}
