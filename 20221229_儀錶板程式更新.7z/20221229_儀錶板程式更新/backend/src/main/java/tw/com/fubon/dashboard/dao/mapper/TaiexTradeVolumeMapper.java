package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.taiextradevol.TaiexTradeData;

public interface TaiexTradeVolumeMapper {

    /**
     * 查詢台股月均交易量
     *
     * @param snapDate
     * @return
     */
    public List<TaiexTradeData> getTaiexTradeVolume(
        @Param("snapDate") String snapDate,
        @Param("snapDateStart") String snapDateStart,
        @Param("snapDateEnd") String snapDateEnd,
        @Param("conditions") String conditions);

}
