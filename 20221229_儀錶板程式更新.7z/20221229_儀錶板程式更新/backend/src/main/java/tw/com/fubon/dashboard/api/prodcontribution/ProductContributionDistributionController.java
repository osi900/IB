package tw.com.fubon.dashboard.api.prodcontribution;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.ExcelGenerator;
import tw.com.fubon.dashboard.utils.StringUtil;

/**
 * 產品貢獻度分布
 */
@RestController
@RequestMapping(path = "/prod_contribute")
public class ProductContributionDistributionController extends ControllerBase {

	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ProductContributionDistributionResponse getData(@RequestBody ProductContributionDistributionRequest rq) {
	    String snapMonth = rq.getSnapDate();
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		
		logger.info("snapMonth: {}, whereCondition: {}", snapMonth, whereCondition);
		
		ProductContributionDistributionResponse rs = new ProductContributionDistributionResponse();
		
		// 全體
		List<ProductContributionDistributionData> datas = dao.getProductContributionDistribution(snapMonth, "");
		// 受眾
		List<ProductContributionDistributionData> targets = new ArrayList<>();
		if (StringUtils.isNotBlank(whereCondition)) {
			targets = dao.getProductContributionDistribution(snapMonth, whereCondition);
		} else {
			for (ProductContributionDistributionData dt : datas) {
				ProductContributionDistributionData temp = new ProductContributionDistributionData();
				temp.setProduct(dt.getProduct());
				targets.add(temp);
			}
		}
		
		rs.setData(datas);
		rs.setTargetData(targets);
		return rs;
	}
	
	/**
	 * 匯出Excel
	 * @param data
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/exportExcel", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Resource> exportExcel(@RequestBody List<Map<String, Object>> data) throws Exception {
		
		return ExcelGenerator.generate((workbook) -> {
			Sheet sheet = workbook.createSheet();
			
			Row headRow = sheet.createRow(0);
			headRow.setHeight((short) 700);
			headRow.createCell(0).setCellValue("");
			headRow.createCell(1).setCellValue("產品");
			headRow.createCell(2).setCellValue("全體戶數");
			headRow.createCell(3).setCellValue("受眾戶數");
			headRow.createCell(4).setCellValue("全體滲透率(%)");
			headRow.createCell(5).setCellValue("受眾滲透率(%)");
			headRow.createCell(6).setCellValue("年累貢獻度(新台幣/千元)/口數");
			headRow.createCell(7).setCellValue("受眾貢獻度佔比(%)");
			headRow.createCell(8).setCellValue("年累交易量\n(新台幣/百萬)");
			
			CellStyle cs = workbook.createCellStyle();
			cs.setWrapText(true);
			headRow.getCell(8).setCellStyle(cs);
			
			int rowIdx = 0;
			for (int i = 0; i < data.size(); i++) {
				Map<String, Object> dataMain = data.get(i);
				List<String> prodNames = (List<String>) dataMain.get("productNames");
				
				List<Map<String, Object>> datas = (List<Map<String, Object>>) dataMain.get("datas");
				List<Map<String, Object>> targets = (List<Map<String, Object>>) dataMain.get("targetData");
				
				String cateName = (String) dataMain.get("cateName");
				
				for (int j = 0; j < prodNames.size(); j++, rowIdx++) {
					Row rcdRow = sheet.createRow(rowIdx + 1);
					
					
					if (j == 0) {
						Cell cell0 = rcdRow.createCell(0);
						cell0.setCellValue(cateName);
						
						// 合併第一個col
						CellRangeAddress mergedRegion = new CellRangeAddress(rowIdx + 1, rowIdx + prodNames.size(), 0, 0);
						sheet.addMergedRegion(mergedRegion);
					}
					
					// 產品名稱
					rcdRow.createCell(1).setCellValue(prodNames.get(j));
					rcdRow.createCell(2).setCellValue(datas.get(j).get("accountCnt").toString());
					rcdRow.createCell(3).setCellValue(targets.get(j).get("accountCnt").toString());
					rcdRow.createCell(4).setCellValue(datas.get(j).get("participationRate").toString());
					rcdRow.createCell(5).setCellValue(targets.get(j).get("participationRate").toString());
					rcdRow.createCell(6).setCellValue(datas.get(j).get("contributionYearly").toString());
					rcdRow.createCell(7).setCellValue(targets.get(j).get("contributionProportion").toString());
					rcdRow.createCell(8).setCellValue(datas.get(j).get("tradeVolumeYearly").toString());
					
				}
				
			}
			
			sheet.setColumnWidth(0, 4000);
			sheet.setColumnWidth(1, 4000);
			sheet.setColumnWidth(2, 4000);
			sheet.setColumnWidth(3, 4000);
			sheet.setColumnWidth(4, 4000);
			sheet.setColumnWidth(5, 4000);
			sheet.setColumnWidth(6, 4000);
			sheet.setColumnWidth(7, 4000);
			sheet.setColumnWidth(8, 4000);
			
			
			
		});
		
	}
}
