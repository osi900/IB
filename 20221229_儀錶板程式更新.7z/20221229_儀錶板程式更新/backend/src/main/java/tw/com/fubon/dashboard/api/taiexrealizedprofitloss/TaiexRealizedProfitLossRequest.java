package tw.com.fubon.dashboard.api.taiexrealizedprofitloss;

import tw.com.fubon.dashboard.api.RequestBase;

public class TaiexRealizedProfitLossRequest extends RequestBase {

}
