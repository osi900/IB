package tw.com.fubon.dashboard.vo;

import java.util.List;

public class TagData {

	private String id;
	
	private String name;
	
	private String icon;
	
	private String type;
	
	private String nameEN;
	
	private String nameCH;
	
	private String desc;
	
	private List<OptionData> options;
	
	private List<TagData> children;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getNameEN() {
		return nameEN;
	}

	public void setNameEN(String nameEN) {
		this.nameEN = nameEN;
	}

	public String getNameCH() {
		return nameCH;
	}

	public void setNameCH(String nameCH) {
		this.nameCH = nameCH;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public List<TagData> getChildren() {
		return children;
	}

	public void setChildren(List<TagData> children) {
		this.children = children;
	}

	public List<OptionData> getOptions() {
		return options;
	}

	public void setOptions(List<OptionData> options) {
		this.options = options;
	}
	
}
