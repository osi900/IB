package tw.com.fubon.dashboard.dao.bean;

import java.io.Serializable;

public class Options implements Serializable {
    private Integer optId;

    private Long tagId;

    private String label;

    private String optValue;

    private String name;

    private String srcCol;

    private Long parentOpt;

    private static final long serialVersionUID = 1L;

    public Integer getOptId() {
        return optId;
    }

    public void setOptId(Integer optId) {
        this.optId = optId;
    }

    public Long getTagId() {
        return tagId;
    }

    public void setTagId(Long tagId) {
        this.tagId = tagId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label == null ? null : label.trim();
    }

    public String getOptValue() {
        return optValue;
    }

    public void setOptValue(String optValue) {
        this.optValue = optValue == null ? null : optValue.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getSrcCol() {
        return srcCol;
    }

    public void setSrcCol(String srcCol) {
        this.srcCol = srcCol == null ? null : srcCol.trim();
    }

    public Long getParentOpt() {
        return parentOpt;
    }

    public void setParentOpt(Long parentOpt) {
        this.parentOpt = parentOpt;
    }
}