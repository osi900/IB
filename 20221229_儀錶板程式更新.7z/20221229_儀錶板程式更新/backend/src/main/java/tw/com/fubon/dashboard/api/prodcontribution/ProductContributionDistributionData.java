package tw.com.fubon.dashboard.api.prodcontribution;

import java.math.BigDecimal;

public class ProductContributionDistributionData {
    /** 產品類別 */
    private String reportlevel;

    /** 產品 */
    private String product;
    /** 人數 */ 
    private Long accountCnt = 0L;
    /** 參與率 */ 
    private BigDecimal participationRate = BigDecimal.ZERO;
    /** 年累貢獻度(千元) */
    private BigDecimal contributionYearly = BigDecimal.ZERO;
    /** 貢獻度佔比 */
    private BigDecimal contributionProportion = BigDecimal.ZERO;
    /** 戶均貢獻(元) */
    private BigDecimal contributionMonthAvg = BigDecimal.ZERO;
    /** 年累交易量(百萬)/口數 */
    private BigDecimal tradeVolumeYearly = BigDecimal.ZERO;
    /** 月均交易量(百萬)/口數 */
    private BigDecimal tradeVolumeMonthAvg = BigDecimal.ZERO;

    public String getReportlevel() {
        return reportlevel;
    }

    public void setReportlevel(String reportlevel) {
        this.reportlevel = reportlevel;
    }

    /**
     * @return the product
     */
    public String getProduct() {
        return product;
    }
    /**
     * @param product the product to set
     */
    public void setProduct(String product) {
        this.product = product;
    }
    /**
     * @return the accountCnt
     */
    public Long getAccountCnt() {
        return accountCnt;
    }
    /**
     * @param accountCnt the accountCnt to set
     */
    public void setAccountCnt(Long accountCnt) {
        this.accountCnt = accountCnt;
    }
    /**
     * @return the participationRate
     */
    public BigDecimal getParticipationRate() {
        return participationRate;
    }
    /**
     * @param participationRate the participationRate to set
     */
    public void setParticipationRate(BigDecimal participationRate) {
        this.participationRate = participationRate;
    }
    /**
     * @return the contributionYearly
     */
    public BigDecimal getContributionYearly() {
        return contributionYearly;
    }
    /**
     * @param contributionYearly the contributionYearly to set
     */
    public void setContributionYearly(BigDecimal contributionYearly) {
        this.contributionYearly = contributionYearly;
    }
    /**
     * @return the contributionProportion
     */
    public BigDecimal getContributionProportion() {
        return contributionProportion;
    }
    /**
     * @param contributionProportion the contributionProportion to set
     */
    public void setContributionProportion(BigDecimal contributionProportion) {
        this.contributionProportion = contributionProportion;
    }
    /**
     * @return the tradeVolumeYearly
     */
    public BigDecimal getTradeVolumeYearly() {
        return tradeVolumeYearly;
    }
    /**
     * @param tradeVolumeYearly the tradeVolumeYearly to set
     */
    public void setTradeVolumeYearly(BigDecimal tradeVolumeYearly) {
        this.tradeVolumeYearly = tradeVolumeYearly;
    }
    /**
     * @return the tradeVolumeMonthAvg
     */
    public BigDecimal getTradeVolumeMonthAvg() {
        return tradeVolumeMonthAvg;
    }
    /**
     * @param tradeVolumeMonthAvg the tradeVolumeMonthAvg to set
     */
    public void setTradeVolumeMonthAvg(BigDecimal tradeVolumeMonthAvg) {
        this.tradeVolumeMonthAvg = tradeVolumeMonthAvg;
    }
	public BigDecimal getContributionMonthAvg() {
		return contributionMonthAvg;
	}
	public void setContributionMonthAvg(BigDecimal contributionMonthAvg) {
		this.contributionMonthAvg = contributionMonthAvg;
	}
    
    
}
