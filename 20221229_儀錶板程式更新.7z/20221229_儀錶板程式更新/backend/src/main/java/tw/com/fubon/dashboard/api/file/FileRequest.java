package tw.com.fubon.dashboard.api.file;

import tw.com.fubon.dashboard.api.RequestBase;

public class FileRequest extends RequestBase {

	private String filename;
	
	private int fileSize;
	
	private String accts;

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public int getFileSize() {
		return fileSize;
	}

	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}

	public String getAccts() {
		return accts;
	}

	public void setAccts(String accts) {
		this.accts = accts;
	}
	
}
