package tw.com.fubon.dashboard.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import tw.com.fubon.dashboard.vo.Filter;

public class StringUtil {

	/**
	 * 轉換標籤為SQL條件
	 * @param filters
	 * @return
	 */
	public static String generateSqlConditions(Map<String, List<Filter>> filters, String joinAccts) {
		List<String> conditions = new ArrayList<>();
		for (String key : filters.keySet()) {
			if (StringUtils.equals(key, "snapYYYYMM")) {
				continue;
			}
			
			List<Filter> values = filters.get(key);
			if (values != null) {
				List<String> onekey = new ArrayList<>();
				for (Filter value : values) {
					if (StringUtils.isNotBlank(value.getOp())) {
						if ("TIME".equals(value.getType())) {
							
							if ("between".equals(value.getOp())) {
								onekey.add(String.format(" %s BETWEEN TO_DATE('%s', 'YYYY/MM/DD') AND TO_DATE('%s', 'YYYY/MM/DD')", 
										key, value.getValue(), value.getValue2()));
							} else {
								onekey.add(String.format(" %s %s TO_DATE('%s', 'YYYY/MM/DD') ", key, value.getOp(), value.getValue()));
							}
							
						} else {
							onekey.add(String.format(" %s %s %s ", key, value.getOp(), value.getValue()));
						}
						
					} else {
						onekey.add(String.format(" %s = '%s' ", key, value.getValue()));
					}
				}
				
				conditions.add(String.format(" ( %s ) ", StringUtils.join(onekey, "or")));
			}
			
		}
		
		String result = "";
		if (!conditions.isEmpty()) {
			result = StringUtils.join(conditions, "and");
		}
		
		if (StringUtils.isNotBlank(joinAccts)) {
			if (!conditions.isEmpty()) {
				result += " and ";
			}
			result += String.format(" ACCT_NBR IN (select ACCT_NBR from MDM_TAG.USER_TEMP_DASHBOARD where LOGIN_USER='%s') ", joinAccts);
		}
		
		return result;
	}


	public static String snapDateStart(String snapDate){
		if(StringUtils.isNotBlank(snapDate)){
			return snapDate.substring(0, 4) + "0101";
		}
		return snapDate;
	}

	public static String snapDateEnd(String snapDate){
		if(StringUtils.isNotBlank(snapDate)){
			return snapDate.substring(0, 4) + "1231";
		}
		return snapDate;
	}
}
