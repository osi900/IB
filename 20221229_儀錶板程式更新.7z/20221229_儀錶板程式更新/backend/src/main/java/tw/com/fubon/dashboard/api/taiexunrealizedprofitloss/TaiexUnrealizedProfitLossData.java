package tw.com.fubon.dashboard.api.taiexunrealizedprofitloss;

import tw.com.fubon.dashboard.api.taiexrealizedprofitloss.ProfitLossData;

public class TaiexUnrealizedProfitLossData extends ProfitLossData{

    public TaiexUnrealizedProfitLossData(String sc) {
        super();
        this.setScale(sc);
    }

    public TaiexUnrealizedProfitLossData() {
        super();
    }

}
