package tw.com.fubon.dashboard.api.age;

import java.math.BigDecimal;

public class AgeData {

	private String label;
	
	private Long count;
	private BigDecimal baseAcctCnt;
	private BigDecimal baseProportion;
	private BigDecimal targetCnt;
	private BigDecimal targetProp;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

    /**
     * @return the baseAcctCnt
     */
    public BigDecimal getbaseAcctCnt() {
        return baseAcctCnt;
    }

    /**
     * @param baseAcctCnt the baseAcctCnt to set
     */
    public void setbaseAcctCnt(BigDecimal baseAcctCnt) {
        this.baseAcctCnt = baseAcctCnt;
    }

    /**
     * @return the baseProportion
     */
    public BigDecimal getBaseProportion() {
        return baseProportion;
    }

    /**
     * @param baseProportion the baseProportion to set
     */
    public void setBaseProportion(BigDecimal baseProportion) {
        this.baseProportion = baseProportion;
    }

	public BigDecimal getTargetCnt() {
		return targetCnt;
	}

	public void setTargetCnt(BigDecimal targetCnt) {
		this.targetCnt = targetCnt;
	}

	public BigDecimal getTargetProp() {
		return targetProp;
	}

	public void setTargetProp(BigDecimal targetProp) {
		this.targetProp = targetProp;
	}

	
}
