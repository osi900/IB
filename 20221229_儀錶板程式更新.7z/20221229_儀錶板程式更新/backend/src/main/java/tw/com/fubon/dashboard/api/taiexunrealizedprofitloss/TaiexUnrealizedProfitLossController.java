package tw.com.fubon.dashboard.api.taiexunrealizedprofitloss;

import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.api.taiexrealizedprofitloss.TaiexRealizedProfitLossData;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.ExcelGenerator;
import tw.com.fubon.dashboard.utils.StringUtil;

/**
 * 台股月均交易量
 */
@RestController
@RequestMapping(path = "/taiex_unrealized_profitloss")
public class TaiexUnrealizedProfitLossController extends ControllerBase {

    @Autowired
    private DmsService dao;

    @RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public TaiexUnrealizedProfitLossResponse getData(@RequestBody TaiexUnrealizedProfitLossRequest rq) {
        String snapMonth = rq.getSnapDate();
        String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());

        logger.info("snapMonth: {}, whereCondition: {}", snapMonth, whereCondition);

        TaiexUnrealizedProfitLossResponse rs = new TaiexUnrealizedProfitLossResponse();

        // 全體
        List<TaiexUnrealizedProfitLossData> datas = dao.getTaiexUnrealizedProfitLoss(snapMonth, "");
        fillMissingScale(datas);

        // 受眾
        List<TaiexUnrealizedProfitLossData> targets = new ArrayList<>();
        if(StringUtils.isNotBlank(whereCondition)) {
            targets = dao.getTaiexUnrealizedProfitLoss(snapMonth, whereCondition);
            fillMissingScale(targets);
        } else {
            for(TaiexUnrealizedProfitLossData dt : datas) {
                TaiexUnrealizedProfitLossData temp = new TaiexUnrealizedProfitLossData();
                temp.setScale(dt.getScale());
                targets.add(temp);
            }
        }

        if(!CollectionUtils.isEmpty(datas)) {
            for(TaiexUnrealizedProfitLossData data : datas) {
                data.setSeq(StringUtils.substringBefore(data.getScale(), "_"));
                data.setScale(StringUtils.substringAfter(data.getScale(), "_"));
                if(null != data.getBenefitPerCapita()) {
                    data.setBenefitPerCapita(data.getBenefitPerCapita().setScale(0, RoundingMode.HALF_UP));
                }
                if(null != data.getLossPerCapita()) {
                    data.setLossPerCapita(data.getLossPerCapita().setScale(0, RoundingMode.HALF_UP));
                }
            }
            datas.sort(Comparator.comparing(TaiexUnrealizedProfitLossData::getSeq).reversed());
        }

        if(!CollectionUtils.isEmpty(targets)) {
            for(TaiexUnrealizedProfitLossData data : targets) {
                data.setSeq(StringUtils.substringBefore(data.getScale(), "_"));
                data.setScale(StringUtils.substringAfter(data.getScale(), "_"));
                if(null != data.getBenefitPerCapita()) {
                    data.setBenefitPerCapita(data.getBenefitPerCapita().setScale(0, RoundingMode.HALF_UP));
                }
                if(null != data.getLossPerCapita()) {
                    data.setLossPerCapita(data.getLossPerCapita().setScale(0, RoundingMode.HALF_UP));
                }
            }
            targets.sort(Comparator.comparing(TaiexUnrealizedProfitLossData::getSeq).reversed());
        }

        rs.setData(datas);
        rs.setTarget(targets);
        return rs;
    }

    private void fillMissingScale(List<TaiexUnrealizedProfitLossData> datas) {
        if(org.apache.commons.collections4.CollectionUtils.isNotEmpty(datas)) {
            List<String> scalesFromDb = datas.stream().map(TaiexUnrealizedProfitLossData::getScale).collect(Collectors.toList());
            Stream.of("04_50萬以上", "03_10萬~50萬", "02_1萬~10萬", "01_1萬以內").forEach(sc -> {
                if(!scalesFromDb.contains(sc)) {
                    datas.add(new TaiexUnrealizedProfitLossData(sc));
                }
            });
        }
    }

    /**
     * 匯出Excel
     *
     * @param data
     * @return
     * @throws Exception
     */
    @RequestMapping(path = "/exportExcel", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Resource> exportExcel(@RequestBody List<Map<String, String>> data) throws Exception {

        return ExcelGenerator.generate((workbook) -> {
            Sheet sheet = workbook.createSheet();

            Row headRow = sheet.createRow(0);
            headRow.createCell(0).setCellValue("");
            headRow.createCell(1).setCellValue("賺錢");
            headRow.createCell(3).setCellValue("賠錢");
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 1, 2));
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 3, 4));

            Row headRow2 = sheet.createRow(1);
            headRow2.setHeight((short) 700);
            headRow2.createCell(0).setCellValue("級距");
            headRow2.createCell(1).setCellValue("戶數");
            headRow2.createCell(2).setCellValue("戶均獲利\n(新台幣/元)");
            headRow2.createCell(3).setCellValue("戶數");
            headRow2.createCell(4).setCellValue("戶均獲利\n(新台幣/元)");

            for(int i = 0; i < data.size(); i++) {
                Map<String, String> rcd = data.get(i);

                Row rcdRow = sheet.createRow(i + 1);
                rcdRow.createCell(0).setCellValue(rcd.get("scale"));
                rcdRow.createCell(1).setCellValue(rcd.get("benefitAcct"));
                rcdRow.createCell(2).setCellValue(rcd.get("benefitPerCapita"));
                rcdRow.createCell(3).setCellValue(rcd.get("lossAcct"));
                rcdRow.createCell(4).setCellValue(rcd.get("lossPerCapita"));
            }

            sheet.setColumnWidth(0, 6000);

        });

    }
}
