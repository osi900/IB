package tw.com.fubon.dashboard.api.taiextradevol;

import java.math.BigDecimal;

public class TradeVolumeData {

    /**  */
    private String seq;
    /** 月均交易量級距 */
	private String avgMonthlyTradVolCI;
	/** 戶數 */
	private Long account;
	/** 戶數佔比 */
	private BigDecimal accountProportion;
	/** 交易量  */
	private Long tradingVolume;
	/** 交易佔比 */
	private BigDecimal tradingVolumeProportion;
	/** 人均交易量 */
	private Long tradingVolumePerCapita;

    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }

    /**
     * @return the avgMonthlyTradVolCI
     */
    public String getAvgMonthlyTradVolCI() {
        return avgMonthlyTradVolCI;
    }

    /**
     * @param avgMonthlyTradVolCI the avgMonthlyTradVolCI to set
     */
    public void setAvgMonthlyTradVolCI(String avgMonthlyTradVolCI) {
        this.avgMonthlyTradVolCI = avgMonthlyTradVolCI;
    }

    /**
     * @return the account
     */
    public Long getAccount() {
        return account;
    }

    /**
     * @param account the account to set
     */
    public void setAccount(Long account) {
        this.account = account;
    }

    /**
     * @return the accountProportion
     */
    public BigDecimal getAccountProportion() {
        return accountProportion;
    }

    /**
     * @param accountProportion the accountProportion to set
     */
    public void setAccountProportion(BigDecimal accountProportion) {
        this.accountProportion = accountProportion;
    }

    /**
     * @return the tradingVolume
     */
    public Long getTradingVolume() {
        return tradingVolume;
    }

    /**
     * @param tradingVolume the tradingVolume to set
     */
    public void setTradingVolume(Long tradingVolume) {
        this.tradingVolume = tradingVolume;
    }

    /**
     * @return the tradingVolumeProportion
     */
    public BigDecimal getTradingVolumeProportion() {
        return tradingVolumeProportion;
    }

    /**
     * @param tradingVolumeProportion the tradingVolumeProportion to set
     */
    public void setTradingVolumeProportion(BigDecimal tradingVolumeProportion) {
        this.tradingVolumeProportion = tradingVolumeProportion;
    }

    /**
     * @return the tradingVolumePerCapita
     */
    public Long getTradingVolumePerCapita() {
        return tradingVolumePerCapita;
    }

    /**
     * @param tradingVolumePerCapita the tradingVolumePerCapita to set
     */
    public void setTradingVolumePerCapita(Long tradingVolumePerCapita) {
        this.tradingVolumePerCapita = tradingVolumePerCapita;
    }




	
}
