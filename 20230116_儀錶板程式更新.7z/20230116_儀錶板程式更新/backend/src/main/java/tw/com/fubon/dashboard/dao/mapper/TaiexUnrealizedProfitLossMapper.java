package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.taiexunrealizedprofitloss.TaiexUnrealizedProfitLossData;

public interface TaiexUnrealizedProfitLossMapper {

    /**
     * 【客戶賺錢/賠錢】-台股未實現損益
     *
     * @param snapDate
     * @return
     */
    public List<TaiexUnrealizedProfitLossData> getTaiexUnrealizedProfitLoss(
        @Param("snapDate") String snapDate,
        @Param("snapDateStart") String snapDateStart,
        @Param("snapDateEnd") String snapDateEnd,
        @Param("conditions") String conditions);

}
