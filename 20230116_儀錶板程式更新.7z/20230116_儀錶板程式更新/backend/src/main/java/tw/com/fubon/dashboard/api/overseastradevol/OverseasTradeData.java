package tw.com.fubon.dashboard.api.overseastradevol;

import java.math.BigDecimal;

public class OverseasTradeData {

	private String seq;
    /** 月均交易量級距 */
	private String avgMonthlyTradVolCI;
	/** 母體戶數 */
	private Long sampleAcct;
	/** 母體戶數佔比 */
	private BigDecimal sampleActRatio;
	/** 母體交易量  */
	private Long sampleTxRatio;
	
	/** 受眾戶數 */
	private Long targetAcct;
	/** 受眾戶數佔比 */
	private BigDecimal targetActRatio;
	/** 受眾交易量  */
	private BigDecimal targetTxRatio;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getAvgMonthlyTradVolCI() {
		return avgMonthlyTradVolCI;
	}
	public void setAvgMonthlyTradVolCI(String avgMonthlyTradVolCI) {
		this.avgMonthlyTradVolCI = avgMonthlyTradVolCI;
	}
	public Long getSampleAcct() {
		return sampleAcct;
	}
	public void setSampleAcct(Long sampleAcct) {
		this.sampleAcct = sampleAcct;
	}
	public BigDecimal getSampleActRatio() {
		return sampleActRatio;
	}
	public void setSampleActRatio(BigDecimal sampleActRatio) {
		this.sampleActRatio = sampleActRatio;
	}
	public Long getSampleTxRatio() {
		return sampleTxRatio;
	}
	public void setSampleTxRatio(Long sampleTxRatio) {
		this.sampleTxRatio = sampleTxRatio;
	}
	public Long getTargetAcct() {
		return targetAcct;
	}
	public void setTargetAcct(Long targetAcct) {
		this.targetAcct = targetAcct;
	}
	public BigDecimal getTargetActRatio() {
		return targetActRatio;
	}
	public void setTargetActRatio(BigDecimal targetActRatio) {
		this.targetActRatio = targetActRatio;
	}
	public BigDecimal getTargetTxRatio() {
		return targetTxRatio;
	}
	public void setTargetTxRatio(BigDecimal targetTxRatio) {
		this.targetTxRatio = targetTxRatio;
	}
}
