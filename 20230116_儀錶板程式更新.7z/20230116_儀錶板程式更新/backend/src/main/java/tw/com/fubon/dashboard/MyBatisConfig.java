package tw.com.fubon.dashboard;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

@Configuration
public class MyBatisConfig {

	@Value("classpath:tw/com/fubon/dms/dao/mapper/*.xml")
	private Resource[] dmsMappers;
	
	@Value("classpath:tw/com/fubon/dashboard/dao/mapper/*.xml")
	private Resource[] dashboardMappers;
	
	/* DMS設定 */
	@Bean
	@Primary
	@ConfigurationProperties("spring.datasource.dms")
	public DataSourceProperties dmsDataSourceProperties() {
		return new DataSourceProperties();
	}
	
	@Bean
	public DataSource dmsDataSource(@Qualifier("dmsDataSourceProperties") DataSourceProperties dmsDataSourceProperties) {
		return dmsDataSourceProperties.initializeDataSourceBuilder().build();
	}
	
	@Bean
    public SqlSessionFactory dmsSqlSessionFactory(@Qualifier("dmsDataSource") DataSource dmsDataSource) throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dmsDataSource);
        factoryBean.setMapperLocations(dmsMappers);
        return factoryBean.getObject();
    }

	@Bean
	public SqlSessionTemplate dmsSqlSessionTemplate(SqlSessionFactory dmsSqlSessionFactory) {
		return new SqlSessionTemplate(dmsSqlSessionFactory);
	}
	
	@Bean
	public DataSourceTransactionManager dmsTxnManager(@Qualifier("dmsDataSource") DataSource dmsDataSource) {
		return new DataSourceTransactionManager(dmsDataSource);
	}
	
	/* DASHBOARD設定 */
	@Bean
	@ConfigurationProperties("spring.datasource.dashboard")
	public DataSourceProperties dashboardDataSourceProperties() {
		return new DataSourceProperties();
	}
	
	@Bean
	public DataSource dashboardDataSource(@Qualifier("dashboardDataSourceProperties") DataSourceProperties dashboardDataSourceProperties) {
		return dashboardDataSourceProperties.initializeDataSourceBuilder().build();
	}
	
	@Bean
    public SqlSessionFactory dashboardSqlSessionFactory(@Qualifier("dashboardDataSource") DataSource dashboardDataSource) throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dashboardDataSource);
        factoryBean.setMapperLocations(dashboardMappers);
        return factoryBean.getObject();
    }

	@Bean
	public SqlSessionTemplate dashboardSqlSessionTemplate(SqlSessionFactory dashboardSqlSessionFactory) {
		return new SqlSessionTemplate(dashboardSqlSessionFactory);
	}
	
	@Bean
	public DataSourceTransactionManager dashboardTxnManager(@Qualifier("dashboardDataSource") DataSource dashboardDataSource) {
		return new DataSourceTransactionManager(dashboardDataSource);
	}
}
