package tw.com.fubon.dashboard.api.effectivesignacct;

import tw.com.fubon.dashboard.api.RequestBase;

public class EffectiveSignAcctRequest extends RequestBase {

}
