package tw.com.fubon.dashboard.api;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import tw.com.fubon.dashboard.vo.Filter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestBase {

	private Map<String, String> errors = new HashMap<>();
	
	private Map<String, List<Filter>> conditions;

	/**
	 * 指定錯誤訊息
	 * @param id
	 * @param message
	 */
	protected void setFieldError(String id, String message) {
		errors.put(id, message);
	}
	
	/**
	 * 取得錯誤訊息
	 * @return
	 */
	public Map<String, String> getErrors() {
		return errors;
	}
	
	public Map<String, List<Filter>> getConditions() {
		return conditions;
	}

	public void setConditions(Map<String, List<Filter>> conditions) {
		this.conditions = conditions;
	}
	
	public String getSnapDate() {
		if (this.conditions != null) {
			return this.conditions.get("snapYYYYMM").get(0).getValue();
		}
		return "";
	}
	
	public void validateSnapDate() {
		if (this.conditions != null && this.conditions.get("snapYYYYMM") != null
				&& StringUtils.isNotBlank(this.conditions.get("snapYYYYMM").get(0).getValue())) {
			try {
				String dt = this.conditions.get("snapYYYYMM").get(0).getValue();
				SimpleDateFormat df = new SimpleDateFormat("yyyyMM");
				if (!df.format(df.parse(dt)).equals(dt)) {
					this.setFieldError("snapYYYYMM", "日期格式錯誤");
				}
				
			} catch (Exception ex) {
				this.setFieldError("snapYYYYMM", "日期格式錯誤");
			}
		}
	}
	
	/**
	 * 檢核上傳資料
	 * @return
	 */
	public void validate() {
		
	}
	
}
