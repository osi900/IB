package tw.com.fubon.dashboard.api.log;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.dao.bean.TagsLog;
import tw.com.fubon.dashboard.service.DashboardService;

@RestController
@RequestMapping(path = "/log")
public class LogController extends ControllerBase {

	@Autowired
	private DashboardService dashboardDao;
	
	/**
	 * 儲存標籤使用紀錄
	 * @param rq
	 */
	@PostMapping(path = "/logTagUsage",  produces = MediaType.APPLICATION_JSON_VALUE)
    public LogResponse getBasicInfo(@RequestBody LogRequest rq) {
		
		TagsLog log = new TagsLog();
		log.setUserAcct(getLoginUser().getUserAccount());
		log.setTagName(rq.getTagName());
		log.setSrcCol(rq.getSrcCol());
		log.setCreateTime(new Date());
		
		dashboardDao.saveTagLog(log);
		
		return new LogResponse();
	}
}
