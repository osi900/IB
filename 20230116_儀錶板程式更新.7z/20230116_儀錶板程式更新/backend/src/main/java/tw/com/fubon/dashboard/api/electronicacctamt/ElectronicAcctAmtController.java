package tw.com.fubon.dashboard.api.electronicacctamt;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.StringUtil;

/**
 * 電子戶數及金額自佔率
 */
@RestController
@RequestMapping(path = "/electronic_acct_amt")
public class ElectronicAcctAmtController extends ControllerBase {

    private static final BigDecimal oneMillion = new BigDecimal("1000000");
    
	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ElectronicAcctAmtResponse getData(@RequestBody ElectronicAcctAmtRequest rq) {
	    String snapMonth = rq.getSnapDate();
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		
		logger.info("snapMonth: {}, whereCondition: {}", snapMonth, whereCondition);
		
		ElectronicAcctAmtResponse rs = new ElectronicAcctAmtResponse();
		
		List<ElectronicAcctAmtData> datas = dao.getElectronicAcctAmtProportion(snapMonth, whereCondition);
		if(!CollectionUtils.isEmpty(datas)) {
		    for (ElectronicAcctAmtData data : datas) {
                data.setSeq(StringUtils.substringBefore(data.getProduct(), "."));
                data.setProduct(StringUtils.substringAfter(data.getProduct(), "."));
                if( null != data.getElecAcctProportion()) {
                    data.setElecAcctProportion(data.getElecAcctProportion().setScale(4, RoundingMode.HALF_UP));
                }
                if( null != data.getArtiAcctProportion()) {
                    data.setArtiAcctProportion(data.getArtiAcctProportion().setScale(4, RoundingMode.HALF_UP));
                }
                if( null != data.getElecAmountProportion()) {
                    data.setElecAmountProportion(data.getElecAmountProportion().setScale(4, RoundingMode.HALF_UP));
                }
                if( null != data.getArtiAmountProportion()) {
                    data.setArtiAmountProportion(data.getArtiAmountProportion().setScale(4, RoundingMode.HALF_UP));
                }
                if( null != data.getElectronicAmount()) {
                    data.setElectronicAmount(data.getElectronicAmount().divide(oneMillion, 2, RoundingMode.HALF_UP));
                }
                if( null != data.getArtificialAmount()) {
                    data.setArtificialAmount(data.getArtificialAmount().divide(oneMillion, 2, RoundingMode.HALF_UP));
                }
            }
		}
		rs.setData(datas);
		return rs;
	}
}
