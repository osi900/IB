package tw.com.fubon.dashboard.api.branch;

import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.StringUtil;

@RestController
@RequestMapping(path = "/branch")
public class BranchController extends ControllerBase {

	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public BranchResponse getData(@RequestBody BranchRequest rq) {
		String snapMonth = rq.getSnapDate();
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		
		logger.info("snapMonth: {}, whereCondition: {}", snapMonth, whereCondition);
		
		BranchResponse rs = new BranchResponse();
		List<BranchData> datas = dao.getBranchDistribution(snapMonth, whereCondition);
		datas.removeIf(bd -> StringUtils.equals(bd.getBranchName(), "銷戶"));
		rs.setData(datas);
		return rs;
	}
}
