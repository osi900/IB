package tw.com.fubon.dashboard.api.overseastradevol;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class OverseasTradeVolumeResponse extends ResponseBase {

	private List<OverseasTradeData> data;

	public List<OverseasTradeData> getData() {
		return data;
	}

	public void setData(List<OverseasTradeData> data) {
		this.data = data;
	}
	
}
