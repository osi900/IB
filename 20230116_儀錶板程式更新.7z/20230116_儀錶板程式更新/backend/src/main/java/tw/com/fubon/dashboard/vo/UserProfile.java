package tw.com.fubon.dashboard.vo;

public class UserProfile {

	public static final String SESSION_USER_PROFILE = "tw.com.fubon.dashboard.SESSION_USER_PROFILE";
	
	private String clientIp;
	
	/** 登入類型 token, pwd */
	private String loginType;
	
	/** 使用者名稱 */
	private String userName;
	
	/** 使用者帳號 */
	private String userAccount;
	
	/** BDP使用者資訊 */
	private BdpUserInfo bdpUserInfo;
	
	private String joinAccts;
	
	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	public BdpUserInfo getBdpUserInfo() {
		return bdpUserInfo;
	}

	public void setBdpUserInfo(BdpUserInfo bdpUserInfo) {
		this.bdpUserInfo = bdpUserInfo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserAccount() {
		return userAccount;
	}

	public void setUserAccount(String userAccount) {
		this.userAccount = userAccount;
	}

	public String getJoinAccts() {
		return joinAccts;
	}

	public void setJoinAccts(String joinAccts) {
		this.joinAccts = joinAccts;
	}

}
