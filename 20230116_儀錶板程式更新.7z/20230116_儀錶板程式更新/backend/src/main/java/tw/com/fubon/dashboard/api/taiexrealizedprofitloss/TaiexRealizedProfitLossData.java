package tw.com.fubon.dashboard.api.taiexrealizedprofitloss;

public class TaiexRealizedProfitLossData extends ProfitLossData{

    public TaiexRealizedProfitLossData(String sc) {
        super();
        this.setScale(sc);
    }

    public TaiexRealizedProfitLossData() {
        super();
    }
}
