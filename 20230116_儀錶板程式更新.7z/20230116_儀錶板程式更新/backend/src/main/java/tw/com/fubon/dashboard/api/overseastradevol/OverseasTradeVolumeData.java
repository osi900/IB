package tw.com.fubon.dashboard.api.overseastradevol;

import tw.com.fubon.dashboard.api.taiextradevol.TradeVolumeData;

public class OverseasTradeVolumeData extends TradeVolumeData{}
