package tw.com.fubon.dashboard.api.taiexrealizedprofitloss;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class TaiexRealizedProfitLossResponse extends ResponseBase {

	private List<TaiexRealizedProfitLossData> data;
	
	private List<TaiexRealizedProfitLossData> target;

	public List<TaiexRealizedProfitLossData> getData() {
		return data;
	}

	public void setData(List<TaiexRealizedProfitLossData> data) {
		this.data = data;
	}

	public List<TaiexRealizedProfitLossData> getTarget() {
		return target;
	}

	public void setTarget(List<TaiexRealizedProfitLossData> target) {
		this.target = target;
	}
	
}
