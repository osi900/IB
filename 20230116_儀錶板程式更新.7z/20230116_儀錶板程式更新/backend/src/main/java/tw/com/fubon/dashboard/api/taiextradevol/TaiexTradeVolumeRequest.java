package tw.com.fubon.dashboard.api.taiextradevol;

import tw.com.fubon.dashboard.api.RequestBase;

public class TaiexTradeVolumeRequest extends RequestBase {

}
