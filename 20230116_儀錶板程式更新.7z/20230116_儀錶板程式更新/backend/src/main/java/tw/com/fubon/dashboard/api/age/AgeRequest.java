package tw.com.fubon.dashboard.api.age;

import tw.com.fubon.dashboard.api.RequestBase;

public class AgeRequest extends RequestBase {

}
