package tw.com.fubon.dashboard.api.effectivesignacct;

import java.math.BigDecimal;

public class EffectiveSignAcctData {

	private String groupName;
	
	private BigDecimal ecAcct = BigDecimal.ZERO;
	
	private BigDecimal dtSign = BigDecimal.ZERO;
	
	private BigDecimal bsblSign = BigDecimal.ZERO;
	
	private BigDecimal urulSign = BigDecimal.ZERO;
	
	private BigDecimal dcSign = BigDecimal.ZERO;
	
	private BigDecimal sbkAcct = BigDecimal.ZERO;
	
	private BigDecimal futIbAcc = BigDecimal.ZERO;
	
	private BigDecimal cdAcct = BigDecimal.ZERO;
	
	private BigDecimal wtFund = BigDecimal.ZERO;

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public BigDecimal getEcAcct() {
		return ecAcct;
	}

	public void setEcAcct(BigDecimal ecAcct) {
		this.ecAcct = ecAcct;
	}

	public BigDecimal getDtSign() {
		return dtSign;
	}

	public void setDtSign(BigDecimal dtSign) {
		this.dtSign = dtSign;
	}

	public BigDecimal getBsblSign() {
		return bsblSign;
	}

	public void setBsblSign(BigDecimal bsblSign) {
		this.bsblSign = bsblSign;
	}

	public BigDecimal getUrulSign() {
		return urulSign;
	}

	public void setUrulSign(BigDecimal urulSign) {
		this.urulSign = urulSign;
	}

	public BigDecimal getDcSign() {
		return dcSign;
	}

	public void setDcSign(BigDecimal dcSign) {
		this.dcSign = dcSign;
	}

	public BigDecimal getSbkAcct() {
		return sbkAcct;
	}

	public void setSbkAcct(BigDecimal sbkAcct) {
		this.sbkAcct = sbkAcct;
	}

	public BigDecimal getCdAcct() {
		return cdAcct;
	}

	public void setCdAcct(BigDecimal cdAcct) {
		this.cdAcct = cdAcct;
	}

	public BigDecimal getWtFund() {
		return wtFund;
	}

	public void setWtFund(BigDecimal wtFund) {
		this.wtFund = wtFund;
	}

	public BigDecimal getFutIbAcc() {
		return futIbAcc;
	}

	public void setFutIbAcc(BigDecimal futIbAcc) {
		this.futIbAcc = futIbAcc;
	}
	
}
