package tw.com.fubon.dashboard.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.servlet.ServletRequest;

import org.springframework.web.context.request.NativeWebRequest;

public class SystemUtils {

	private static final String[] IP_HEADER_CANDIDATES = {
	        "X-Forwarded-For",
	        "Proxy-Client-IP",
	        "WL-Proxy-Client-IP",
	        "HTTP_X_FORWARDED_FOR",
	        "HTTP_X_FORWARDED",
	        "HTTP_X_CLUSTER_CLIENT_IP",
	        "HTTP_CLIENT_IP",
	        "HTTP_FORWARDED_FOR",
	        "HTTP_FORWARDED",
	        "HTTP_VIA",
	        "REMOTE_ADDR"
	};
	
	public static String detectClientIp(NativeWebRequest webRequest) {
		// 提取header得到IP地址列表（多重代理場景），取第一個IP
	    for (String header : IP_HEADER_CANDIDATES) {
	        String ipList = webRequest.getHeader(header);
	        if (ipList != null && ipList.length() != 0 &&
	                !"unknown".equalsIgnoreCase(ipList)) {
	            return ipList.split(",")[0];
	        }
	    }

	    // 沒有經過代理或者SLB，直接 getRemoteAddr 方法獲取IP
	    String ip = ((ServletRequest) webRequest.getNativeRequest()).getRemoteAddr();

	    // 如果是本地環回IP，則根據網路卡取本機配置的IP
	    if ("127.0.0.1".equals(ip) || "0:0:0:0:0:0:0:1".equals(ip)) {
	        try {
	            InetAddress inetAddress = InetAddress.getLocalHost();
	            return inetAddress.getHostAddress();
	        } catch (UnknownHostException e) {
	            e.printStackTrace();
	            return ip;
	        }
	    }
	    return ip;
	}
}
