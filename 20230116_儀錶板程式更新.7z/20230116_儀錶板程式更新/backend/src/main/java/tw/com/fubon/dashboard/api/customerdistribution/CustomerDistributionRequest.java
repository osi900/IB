package tw.com.fubon.dashboard.api.customerdistribution;

import tw.com.fubon.dashboard.api.RequestBase;

public class CustomerDistributionRequest extends RequestBase {

}
