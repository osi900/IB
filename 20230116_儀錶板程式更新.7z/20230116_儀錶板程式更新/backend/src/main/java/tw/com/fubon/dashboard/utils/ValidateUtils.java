package tw.com.fubon.dashboard.utils;

import org.apache.commons.lang3.StringUtils;

public class ValidateUtils {

	/**
	 * 檢查是否為合法 EMAIL Email中不可含有特殊符號或空白；且不可以『.』為結尾' Email須含有『@』
	 *
	 * @param fieldContent欄位傳入的數值
	 * @return true success else fail
	 */
	public static boolean checkEMail(String fieldContent) {
		// 2018.10.18 去除檢核IP && 空字串也是為不合法
		// EBMWIB-18356 email須可接受使用"+"號
		return StringUtils.isNotBlank(fieldContent) && fieldContent.matches("(^[-_A-Za-z0-9-\\+]+)([.][-_A-Za-z0-9-\\+]+)*@[-_A-Za-z0-9]+([.][-_A-Za-z0-9]+)*$");
	}
	
}
