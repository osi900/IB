package tw.com.fubon.dashboard.api.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.errors.ErrorCode;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.AuthUtil;
import tw.com.fubon.dashboard.vo.BdpUserInfo;
import tw.com.fubon.dashboard.vo.UserProfile;

@RestController
@RequestMapping(path = "/login")
public class LoginController extends ControllerBase {

	@Autowired
	private AuthUtil authUtil;
	
	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/auth", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public LoginResponse login(HttpServletRequest request, HttpSession session, @RequestBody LoginRequest rq) {
		UserProfile user = new UserProfile();
		user.setClientIp(getClientIp());
		user.setLoginType("pwd");
		user.setUserAccount(rq.getEmail());
		
		dao.updateUserTemp(null, user.getUserAccount());
		long count = dao.getUserTempCount(user.getUserAccount());
		user.setJoinAccts(count > 0 ? user.getUserAccount() : null);
		
		setLoginUser(user);
		
		return new LoginResponse();
	}
	
	@RequestMapping(path = "/logout", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public LoginResponse logout(HttpSession session) {
		dao.updateUserTemp(null, getLoginUser().getUserAccount());
		setLoginUser(null);
		return new LoginResponse();
	}
	
	/**
	 * 驗證BDP Token
	 * @param token
	 * @return
	 */
	@RequestMapping(path = "/verifyToken", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public LoginResponse verifyToken(@RequestBody LoginRequest rq) {
		ErrorCode code = authUtil.checkToken(rq.getToken());
		
		LoginResponse response = new LoginResponse();
		response.setCode(code.getCode());
		if (ErrorCode.OK == code) {
			// Token驗證成功，取得使用者資訊
			BdpUserInfo userInfo = authUtil.getUserInfo(rq.getToken());
			
			UserProfile user = new UserProfile();
			user.setClientIp(getClientIp());
			user.setLoginType("token");
			user.setUserName(userInfo.getUserName());
			user.setUserAccount(userInfo.getUserAccount());
			user.setBdpUserInfo(userInfo);
			
			dao.updateUserTemp(null, user.getUserAccount());
			long count = dao.getUserTempCount(user.getUserAccount());
			user.setJoinAccts(count > 0 ? user.getUserAccount() : null);
			
			setLoginUser(user);
			
		}
		return response;
	}
	
	
}
