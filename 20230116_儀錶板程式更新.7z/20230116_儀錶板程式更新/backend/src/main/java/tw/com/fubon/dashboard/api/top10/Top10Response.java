package tw.com.fubon.dashboard.api.top10;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class Top10Response extends ResponseBase {

	private List<Top10Data> data;

	public List<Top10Data> getData() {
		return data;
	}

	public void setData(List<Top10Data> data) {
		this.data = data;
	}
	
	
}
