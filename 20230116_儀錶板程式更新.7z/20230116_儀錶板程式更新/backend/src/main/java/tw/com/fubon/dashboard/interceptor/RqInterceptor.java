package tw.com.fubon.dashboard.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;

import tw.com.fubon.dashboard.api.RequestBase;
import tw.com.fubon.dashboard.exceptions.ValidateException;
import tw.com.fubon.dashboard.utils.RequestWrapper;
import tw.com.fubon.dashboard.utils.ResponseWrapper;

public class RqInterceptor implements HandlerInterceptor {

	private static Logger _logger = LoggerFactory.getLogger(RqInterceptor.class);
	
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception exception) throws Exception {

	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		if (response instanceof ResponseWrapper) {
			ResponseWrapper responseWrapper = (ResponseWrapper) response;
			if (response.getContentType() != null && response.getContentType().indexOf("application/json") > -1) {
				_logger.info("Response資料: {} {} {}", 
						request.getSession().getId(), 
						request.getRequestURI(),
						responseWrapper.getBodyString());
			}
		}
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		if (handler instanceof HandlerMethod) {
			// 檢核Request
			ObjectMapper objectMapper = new ObjectMapper();
			HandlerMethod handlerMethod = (HandlerMethod) handler;
			for (MethodParameter param : handlerMethod.getMethodParameters()) {
				if (RequestBase.class.isAssignableFrom(param.getParameterType())) {
					RequestWrapper requestWrapper = (RequestWrapper) request;
					String rqJson = requestWrapper.getBodyString();
					_logger.debug("{} Request資料: {}", request.getSession().getId(), rqJson);
					
					RequestBase rq = (RequestBase) objectMapper.readValue(rqJson, param.getParameterType());
					rq.validateSnapDate();
					rq.validate();
					if (!rq.getErrors().isEmpty()) {
						throw new ValidateException(rq.getErrors());
					}
				}
			
			}
		}
		
		return true;
		
	}
}
