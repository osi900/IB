package tw.com.fubon.dashboard.api;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.request.NativeWebRequest;

import tw.com.fubon.dashboard.utils.SystemUtils;
import tw.com.fubon.dashboard.vo.UserProfile;

public class ControllerBase {

	@Autowired
	private HttpSession session;
	
	protected static final Logger logger = LoggerFactory.getLogger(ControllerBase.class);
	
	public static final String CLIENT_IP = "tw.com.fubon.dashboard.CLIENT_IP";
	
	
	
	@Autowired
	NativeWebRequest webRequest;
	
	/**
	 * 取得客戶端IP
	 * @return
	 */
	protected String getClientIp() {
		String clientIp = (String) session.getAttribute(CLIENT_IP);
		if (StringUtils.isBlank(clientIp)) {
			clientIp = SystemUtils.detectClientIp(webRequest);
			session.setAttribute(CLIENT_IP, clientIp);
		}
		return clientIp;
	}
	
	/**
	 * 取得登入使用者
	 * @return
	 */
	protected UserProfile getLoginUser() {
		return (UserProfile) session.getAttribute(UserProfile.SESSION_USER_PROFILE);
	}
	
	/**
	 * 儲存登入使用者
	 * @param userProfile
	 */
	protected void setLoginUser(UserProfile userProfile) {
		session.setAttribute(UserProfile.SESSION_USER_PROFILE, userProfile);
	}
}
