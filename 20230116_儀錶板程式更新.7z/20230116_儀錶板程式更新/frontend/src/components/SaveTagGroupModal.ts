import { PageBaseComponent } from '@/components/PageBaseComponent';
import $ from 'jquery';
import { Component } from 'vue-property-decorator';
import axios from 'axios';

@Component({})
export default class SaveTagGroupModal extends PageBaseComponent {
	
	groupName: string;
	
	constructor() {
		super();
		this.groupName = '';
	}
	
	show() {
		($(this.$el) as any).modal('show');
	}
	
	/**
	 * 確認儲存
	 */
	saveTagGroup() {
		
		const tags: any = {};
		const keys = Object.keys(this.$store.state.conditions);
		for (let i = 0; i < keys.length; i++) {
			if (keys[i] == 'snapYYYYMM') {
				continue;
			}
			
			tags[keys[i]] = [];
			for (let j = 0; j < this.$store.state.conditions[keys[i]].length; j++) {
				tags[keys[i]].push({
					type: this.$store.state.conditions[keys[i]][j].type,
					op: this.$store.state.conditions[keys[i]][j].op,
					value: this.$store.state.conditions[keys[i]][j].value,
					value2: this.$store.state.conditions[keys[i]][j].value2
				});
			}
			
		}
		
		const modal = $(this.$el) as any;
		axios.post('/home/saveAsTagGroup', {
			groupName: this.groupName,
			tags: tags
		})
		.then((rs: any) => {
				this.groupName = '';
				
				// 更新選項
				this.updateTagGroups();
				modal.modal('hide');
			})
			.catch((err) => {
				console.log(err);
			});
	}
	
	updateTagGroups() {
		axios.post('/home/getTagGroups')
		.then((rs: any) => {
				this.$store.state.tagGroups = rs.data.tagGroups;
			})
			.catch((err) => {
				console.log(err);
			});
	}
}