<template>
	<div class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">登出</h5>
					<button type="button" class="close" @click="logout()" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					您已經登出
				</div>
				<div class="modal-footer">
					<!-- 關閉 -->
					<button type="button" class="btn btn-secondary" @click="logout()">{{ $t('button.close') }}</button>
				</div>
			</div>
		</div>
	</div>
</template>

<style scoped>
@import '@/assets/css/style.css';

</style>
<script type="ts" src="./LogoutModal.ts"></script>