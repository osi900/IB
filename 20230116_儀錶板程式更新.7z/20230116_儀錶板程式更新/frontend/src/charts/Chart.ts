import { Component, Vue } from 'vue-property-decorator';

@Component({})
export default class Chart extends Vue {
	
	/**
	 * 建構子
	 */
	constructor() {
		super();
	}
}