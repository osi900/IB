<template>
	<ChartTabs @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<!-- 頁簽 -->
		<ul slot="tabs" class="nav nav-tabs card-header-tabs pull-right" role="tablist">
			<li class="nav-item">
				<a class="nav-link active" data-toggle="tab" href="#prodContributionTab1" role="tab" aria-controls="cusincome" aria-selected="true">圖</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#prodContributionTab2" role="tab" aria-controls="cusunincome" aria-selected="false">表</a>
			</li>
		</ul>
		<template slot="chart">
			<!-- 圖 -->
			<div id="prodContributionTab1" style="height: 100%" class="tab-pane fade show active" role="tabpanel" aria-labelledby="tab1-tab">
				<div ref="prodContributionChart" style="height: 100%"></div>
			</div>
			<!-- 表 -->
			<div id="prodContributionTab2" class="tab-pane fade" role="tabpanel" aria-labelledby="tab2-tab" style="height: 100%;width: 100%;">
				<a @click="exportExcel" class="sidebar-brand d-flex align-items-end justify-content-end mb-2">
					<div class="sidebar-brand-icon">
						<img class="img-fluid" src="@/assets/img/excel.png" width="25" />
					</div>
				</a>
				<div slot="chart" style="height: 90%;width: 100%;overflow-y: auto;">
					<div class="table-responsive-sm" ref="prodContributionTable">
						<table style="height: 400px;" class="table table-bordered table-sm table-hover">
							<thead class="text-center">
								<tr>
									<th></th>
									<th>產品</th>
									<th>全體戶數</th>
									<th>受眾戶數</th>
									<th>全體滲透率(%)</th>
									<th>受眾滲透率(%)</th>
									<th>年累貢獻度(新台幣/千元)/口數</th>
									<th v-show="!hasFilter">全體貢獻度佔比(%)</th>
									<th v-show="hasFilter">受眾貢獻度佔比(%)</th>
									<th>年累交易量<br/>(新台幣/百萬)</th>
								</tr>
							</thead>
							<tbody>
								<template v-for="(data_main, main_idx) in data" >
									<tr v-for="(data_, i) in data_main.datas" v-bind:key="'prod_contri_main_'+main_idx+'_'+i">
										<th v-if="i == 0" :rowspan="data_main.rowSpan" :class="data_main.cateBgColor" >
											<div class="cate_name">{{ data_main.cateName }}</div>
										</th>
										<th :class="data_main.prodBgColor">{{updateProdName(data_.product)}}</th>
										<td :class="data_main.prodBgColor">{{formatNumber(data_.accountCnt)}}</td>
										<td :class="data_main.prodBgColor">{{formatNumber(data_main.targetData[i].accountCnt)}}</td>
										<td :class="data_main.prodBgColor">{{formatFloat(data_.participationRate, 1)}}</td>
										<td :class="data_main.prodBgColor">{{formatFloat(data_main.targetData[i].participationRate, 1)}}</td>
										<td :class="data_main.prodBgColor">{{formatNumber(data_.contributionYearly)}}</td>
										<td v-show="!hasFilter" :class="data_main.prodBgColor">{{formatFloat(data_.contributionProportion, 2)}}</td>
										<td v-show="hasFilter" :class="data_main.prodBgColor">{{formatFloat(data_main.targetData[i].contributionProportion, 2)}}</td>
										<td :class="data_main.prodBgColor">{{formatNumber(data_.tradeVolumeYearly)}}</td>
									</tr>
								</template>
							</tbody>
						</table>
						註：滲透率為該產品戶數／篩選後戶數		
					</div>
				</div>
			</div>
		</template>
		
		
	</ChartTabs>
</template>

<script type="ts" src="./ProdContributionChart.ts"></script>
<style scoped>
table {
	height: 400px;
}
.cate_name {
	display:flex;
	justify-content:center;
	align-items:center;
	writing-mode: vertical-lr;
	min-height: 10em;
	line-height: 2em;
}
tbody td {
	text-align: right;
}
</style>