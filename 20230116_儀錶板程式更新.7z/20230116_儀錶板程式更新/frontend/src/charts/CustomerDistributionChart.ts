import Chart from "@/charts/Chart.vue";
import { DataUtils } from "@/commons/DataUtils";
import * as echarts from "echarts";
import { Component } from "vue-property-decorator";
@Component({
	components: {
		Chart,
	},
})
export default class CustomerDistributionChart extends Chart {
	chartSpan: number;

	title: string;

	chart: any;

	option: any;

	/**
	 * 建構子
	 */
	constructor() {
		super();
		this.chartSpan = 2;
		this.title = "客群分布";
		this.chart = null;
	}

	/**
	 * 顯示圖表modal
	 */
	showModal() {
		this.$store.commit("showChartModal", {
			title: this.title,
			option: this.option,
		});
	}

	hasFilter(): boolean {
		const conditions = this.$store.state.conditions;
		const allConditionKeys = Object.keys(conditions);

		allConditionKeys.splice(
			allConditionKeys.findIndex((ack) => ack == "snapYYYYMM"),
			1
		);
		console.info("allConditionKeys: ", allConditionKeys);
		return allConditionKeys.length > 0 || this.$store.state.uploaded;
	}

	/**
	 * 開始繪圖
	 */
	draw() {
		new DataUtils(this).getData("/customer_distribution/", (data: any) => {
			if (data && data.data) {
				const formatUtil = echarts.format;

				if (!this.chart) {
					const el = this.$refs.customerDistributionChart as HTMLElement;
					this.chart = echarts.init(el);
				}

				const size = [
					{name: '富裕', size: 40, key: '富裕客戶'},
					{name: '價值', size: 60, key: '價值客戶'},
					{name: '潛力', size: 80, key: '潛力客戶'}
				];
				const legendDatas = [];
				const baseDatas = [];
				
				for (let i = 0; i < 3; i++) {
					const _data = data.data.find((d:any) => d['custType'] === size[i].key);
					legendDatas.push(size[i].name);
					if (_data) {
						baseDatas.push({
							value: size[i].size,
							name: size[i].name,
							percent: _data['allProportion'],
							acct: _data["allCount"],
						});
					} else {
						baseDatas.push({
							value: size[i].size,
							name: size[i].name,
							percent: 0,
							acct: 0,
						});
					}
				}

				const _series = [];
				const baseSeries = {
					name: "全體",
					type: "funnel",
					width: "40%",
					height: "90%",
					left: "5%",
					top: "5%",
					sort: "ascending",
					label: {
						show: true,
						position: "inside",
						formatter: (params: any) => {
							const _data = params.data;
							return `${_data['name']}: ${_data['percent']}%`;
						}
					},
					data: baseDatas,
				};

				_series.push(baseSeries);

				if (this.hasFilter()) {
					const targetDatas = [];
					for (let i = 0; i < 3; i++) {
						const _data = data.data.find((d:any) => d['custType'] === size[i].key);
						if (_data) {
							targetDatas.push({
								value: size[i].size,
								name: size[i].name,
								percent: _data['targetProportion'],
								acct: _data["targetCount"],
							});
						} else {
							targetDatas.push({
								value: size[i].size,
								name: size[i].name,
								percent: 0,
								acct: 0,
							});
						}
					}

					const targetSeries = {
						name: "受眾",
						type: "funnel",
						width: "40%",
						height: "90%",
						left: "55%",
						top: "5%",
						sort: "ascending",
						label: {
							show: true,
							position: "inside",
							formatter: (params: any) => {
								const _data = params.data;
								return `${_data['name']}: ${_data['percent']}%`;
							}
						},
						data: targetDatas,
					};

					_series.push(targetSeries);
				}

				this.option = {
					tooltip: {
						trigger: "item",
						formatter: function(params: any) {
							let res = "";
							const isBase = params.seriesName == "全體";
							const title =
								`<span class="${isBase ? 'tooltip_icon_base' : 'tooltip_icon_target'}"></span><strong>${(isBase ? "全體戶數" : "受眾戶數")}(${params.data.name})</strong>
              <br>`;
							const acct = `戶數: <strong>${formatUtil.addCommas(params.data.acct)}</strong> 戶`;
							res = title + acct;
							return res;
						},
					},
					legend: {
						orient: "horizontal",
						align: "auto",
						data: legendDatas,
					},
					series: _series,
				};

				this.chart.setOption(this.option, true);

				window.addEventListener("resize", this.resizeTheChart);
			}
		});
	}

	resizeTheChart() {
		if (this.chart) {
			this.chart.resize();
		}
	}
}

/* 
{
  "data": [{"custType":"潛力","allCount":20,"allProportion":100,"targetCount":20,"targetProportion":100}]}
}
*/
