<template>
	<ChartTabs @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<!-- 頁簽 -->
		<ul slot="tabs" class="nav nav-tabs card-header-tabs pull-right" role="tablist">
			<li class="nav-item">
				<a class="nav-link active" data-toggle="tab" href="#taiexUnrealizedProfitLossTab1" role="tab" aria-controls="cusincome" aria-selected="true">圖</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#taiexUnrealizedProfitLossTab2" role="tab" aria-controls="cusunincome" aria-selected="false">表</a>
			</li>
		</ul>
		<template slot="chart">
			<!-- 圖 -->
			<div id="taiexUnrealizedProfitLossTab1" style="height: 100%" class="tab-pane fade show active" role="tabpanel" aria-labelledby="tab1-tab">
				<div ref="taiexUnrealizedProfitLossChart" style="height: 100%"></div>
			</div>
			<!-- 表 -->
			<div id="taiexUnrealizedProfitLossTab2" class="tab-pane fade" role="tabpanel" aria-labelledby="tab2-tab" style="height: 100%;width: 100%;">
				<a @click="exportExcel" class="sidebar-brand d-flex align-items-end justify-content-end mb-2">
					<div class="sidebar-brand-icon">
						<img class="img-fluid" src="@/assets/img/excel.png" width="25" />
					</div>
				</a>
				<div slot="chart" style="height: 100%;width: 100%">
					<div class="table-responsive-sm" ref="taiexUnrealizedProfitLossTable">
						<table class="table table-bordered table-sm table-striped table-hover">
							<thead class="text-center">
								<tr>
									<th></th>
									<th colspan="2" class="bg-info2">賺錢</th>
									<th colspan="2" class="bg-warning2">賠錢</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th class="center">級距</th>
									<th class="table-info2 center">戶數</th>
									<th class="table-info2 center">戶均獲利<br>(新台幣/元)</th>
									<th class="table-warning2 center">戶數</th>
									<th class="table-warning2 center">戶均虧損<br>(新台幣/元)</th>
								</tr>
								<tr v-for="(data_, i) in data" v-bind:key="'taiex_unrealizedpl_'+i">
									<td class="center">{{data_.scale}}</td>
									<td class="table-info2" :class="{'txt-bold' :i == data.length - 1}" style="text-align: right;">{{data_.benefitAcct}}</td>
									<td class="table-info2" :class="{'txt-bold' :i == data.length - 1}" style="text-align: right;">{{data_.benefitPerCapita}}</td>
									<td class="table-warning2" :class="{'txt-bold' :i == data.length - 1}" style="text-align: right;">{{data_.lossAcct}}</td>
									<td class="table-warning2" :style="i == data.length - 1 ? 'text-align: right;color:red;font-weight: bold;' : 'text-align: right;color:red;'">{{data_.lossPerCapita}}</td>
								</tr>
							</tbody>
						</table>		
					</div>
				</div>
			</div>
		</template>
		
	</ChartTabs>
</template>

<script type="ts" src="./TaiexUnrealizedProfitLossChart.ts"></script>
<style scoped>
	th.center, td.center {
		text-align: center;
	}

	.txt-bold {
		font-weight: bold;
	}
</style>