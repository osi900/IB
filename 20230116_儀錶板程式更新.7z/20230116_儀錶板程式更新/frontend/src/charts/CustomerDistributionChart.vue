<template>
	<Chart @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<template slot="chart">
			<table style="width:100%;text-align: center;font-size: 15pt;">
				<tr>
					<td>全體</td>
					<td>受眾</td>
				</tr>
			</table>
			<div ref="customerDistributionChart" style="height: 100%"></div>
		</template>
	</Chart>
</template>

<script type="ts" src="./CustomerDistributionChart.ts"></script>