import Chart from "@/charts/Chart.vue";
import { DataUtils } from "@/commons/DataUtils";
import { NumberUtils } from "@/commons/utilities/number.utils";
import * as echarts from "echarts";
import { Component } from "vue-property-decorator";

@Component({
  components: {
    Chart,
  },
})
export default class AccountOpenSourceChart extends Chart {
  title: string;

  chart: any;

  option: any;

  data: unknown[];
  /**
   * 建構子
   */
  constructor() {
    super();
    this.title = "開戶進件來源";
    this.chart = null;
    this.data = [];
  }

  /**
   * 顯示圖表modal
   */
  showModal() {
    this.$store.commit("showChartModal", {
      title: this.title,
      table: this.$refs.acctOpenSourceTable,
    });
  }

  /**
   * 開始繪圖
   */
  draw() {
    new DataUtils(this).getData("/account_open_source/", (data: any) => {
      if (data && data.data) {
        const formatUtil = echarts.format;

        for (const data_ of data.data) {
          data_["acctOpenThisMonth"] = formatUtil.addCommas(data_["acctOpenThisMonth"]);
          data_["acctOpenThisYear"] = formatUtil.addCommas(
            data_["acctOpenThisYear"]
          );
          data_["acctOpenThisMonthPropo"] = NumberUtils.roundOff(data_["acctOpenThisMonthPropo"], 1);
          data_["acctOpenThisYearPropo"] = NumberUtils.roundOff(data_["acctOpenThisYearPropo"], 1);
        }

        this.data = data.data;
      }
    });
  }
}
