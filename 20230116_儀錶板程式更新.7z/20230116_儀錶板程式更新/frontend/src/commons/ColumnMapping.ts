
/**
 * 欄位中文名稱
 */
export class ColumnMapping {

	private static mapper: any = {
		
	};

	static initTags(allTags: any) {
		for (const tagMain of allTags) {
			const levelTwos = tagMain.children;
			for (const tagSecond of levelTwos) {
				for (const levelThrids of tagSecond.children) {
					if (levelThrids.type == 'MCHECKBOX') {
						for (const opt of levelThrids.options) {
							ColumnMapping.mapper[opt.colName] = opt.name;
							if (opt.options) {
								for (const subOpt of opt.options) {
									ColumnMapping.mapper[subOpt.colName] = subOpt.name;
								}
							}
						}
						
					} else {
						ColumnMapping.mapper[levelThrids.nameEN] = levelThrids.nameCH;
					}
					
				}
				
			}
		}
	}

	/**
	 * 查詢欄位名稱
	 */
	static getName(key: string) {
		return this.mapper[key];
	}
}