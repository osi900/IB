
/**
 * (undefined) // true
 * (null)      // true
 * ('')        // true
 * (' ')       // true
 * (0)         // false
 * ({})        // false
 */
export function isBlank(val: unknown): boolean {
  if (val == null) return true;
  if (isString(val)) return (<string>val).trim() === '';
  console.warn('isBlank()只處理字串', 'val:', val);
  return false;
}

export function isString(val: unknown): boolean {
  return typeof val === 'string';
}