export class NumberUtils {
  static commafy(value: string) {
    value = value + "";
    const result = value
      .replace(/\D/g, "")
      .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return result;
  }

  static roundOff(val: number, scale: number): number {
    if (val == null || scale == null) return val;
    const token = Math.pow(10, scale);
    const negative = val < 0;
    if (negative) {
      return 0 - Math.round(0 - val * token) / token;
    }
    return Math.round(val * token) / token;
  }
}
