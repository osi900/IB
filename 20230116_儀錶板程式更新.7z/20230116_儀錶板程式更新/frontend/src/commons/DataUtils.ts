import { Vue } from 'vue-property-decorator';
import axios from 'axios';

export class DataUtils {
	
	private component: Vue;
	
	constructor(comp: Vue) {
		this.component = comp;
	}
	
	// eslint-disable-next-line @typescript-eslint/ban-types
	getData(url: string, callback: Function) {
		axios.post(url, {conditions: (this.component as any).$store.state.conditions})
				.then((rs: any) => {
					callback(rs.data);
				})
				.catch((err) => {
					console.log(err);
				});
	}
	
	/**
	 * 下載檔案
	 */
	download(url: string, data: any, filename: string) {
		axios({
			method: 'post',
			url: url,
			responseType: 'blob',
			data: data
		})
		.then((rs: any) => {
			let link = document.getElementById('exportExcelLink') as any;
			if (!link) {
				link = document.createElement('a');
			}
			
			const url = window.URL.createObjectURL(rs);
			link.href = url;
			link.setAttribute('download', filename);
			document.body.appendChild(link);
			link.click();
			
		})
		.catch((err) => {
			console.log(err);
		});
	}
}