import { Component } from 'vue-property-decorator';
import { PageBaseComponent } from '@/components/PageBaseComponent';
import { ColumnMapping } from '@/commons/ColumnMapping';
import axios from 'axios';

@Component({})
export default class Login extends PageBaseComponent {
	
	form: {
		email: string;
		password: string;
		ck: boolean;
	};
	
	message: string;
	
	embedded: boolean;
	
	/**
	 * 建構子
	 */
	constructor() {
		super();
		
		this.form = {
			email: '',
			password: '',
			ck: false
		};
		this.message = '啟動富邦證券客群觀測站...';
		this.embedded = false;
	}
	
	created() {
		// 外部傳入token，直接登入
		if (this.$route.query.token) {
			this.embedded = true;
			// 驗證token
			axios.post('/login/verifyToken', {token: this.$route.query.token})
				.then((rs: any) => {
					
					this.$store.state.conditions = {
						'snapYYYYMM': [{value: ''}],
					};
					
					this.$store.state.token = this.$route.query.token;
					this.$store.state.logedIn = true;
					
					// 取得所有標籤
					axios.post('/home/getAllTags')
					.then((rs: any) => {
							this.$store.state.allTags = rs.data.allTags;
							ColumnMapping.initTags(rs.data.allTags);
							this.$router.push('/home');
						})
						.catch((err) => {
							console.log(err);
						});
					
				})
				.catch((err) => {
					console.log(err);
					console.log('登入失敗');
					this.message = '無使用權限，如需使用請提金控需求單';
				});
		}
		
		if (this.$store.state.token == 'timeout') {
			console.log('token逾時');
			this.embedded = true;
			this.message = '逾時，請重新登入';
		}
	}
	
	/**
	 * 登入
	 */
	public doLogin() {
		if (this.form.email == '' || this.form.password == '') {
			alert('請輸入帳號密碼');
			return;
		}
		
		this.$store.state.conditions = {
			'snapYYYYMM': [{value: ''}],
		};
		
		// 登入
		axios.post('/login/auth', this.form)
			.then((rs: any) => {
				this.$store.state.logedIn = true;
				
				// 取得所有標籤
				axios.post('/home/getAllTags')
				.then((rs: any) => {
						this.$store.state.allTags = rs.data.allTags;
						ColumnMapping.initTags(rs.data.allTags);
						this.$router.push('/home');
					})
					.catch((err) => {
						console.log(err);
					});
				
				
			})
			.catch((err) => {
				console.log(err);
				// 登入失敗
				console.log('登入失敗');
			});
	}
}