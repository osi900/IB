import { ColumnMapping } from '@/commons/ColumnMapping';
import { NumberUtils } from '@/commons/utilities/number.utils';
import ChartModal from '@/components/ChartModal.vue';
import LeftMenu from '@/components/LeftMenu.vue';
import SaveTagGroupModal from '@/components/SaveTagGroupModal.vue';
import ExportSQLModal from '@/components/ExportSQLModal.vue';
import LogoutModal from '@/components/LogoutModal.vue';
import { PageBaseComponent } from '@/components/PageBaseComponent';
import axios from 'axios';
import { Component } from 'vue-property-decorator';

@Component({
	components: {
		LeftMenu,
		ChartModal,
		SaveTagGroupModal,
		ExportSQLModal,
		LogoutModal
	}
})
export default class Home extends PageBaseComponent {
	
	
	currTagGroup: any;
	
	/** 已上傳 */
	uploaded: boolean;
	
	filename: string;
	
	fileSize: number;
	
	fileContent: string;
	
	/**
	 * 建構子
	 */
	constructor() {
		super();
		this.uploaded = false;
		this.filename = this.$t('button.upload.custids') as string;
		this.fileSize = 0;
		this.fileContent = '';
		this.currTagGroup = {};
	}
	
	/**
	 * 初始化
	 */
	beforeCreate() {
		//
	}
	
	beforeDestroy() {
		document.removeEventListener('click', this.resetCountdown);
        document.removeEventListener('keydown', this.resetCountdown);
	}
	
	mounted() {
		/**
		 * 更新基本資訊
		 */
		axios.post('/home/basic', {})
		.then((rs: any) => {
				this.$store.commit('updateBasicInfo', {rs});
				this.uploaded = rs.data.uploaded;
				this.$store.state.uploaded = rs.data.uploaded;
				this.$store.commit('refreshHomeInfo');
				
				this.$store.state.chartModal = this.$refs.chartModal;
				for (let i = 0; i < this.$store.state.chartClasses.length; i++) {
					const chart = new this.$store.state.chartClasses[i]();
					chart.$store = this.$store;
					chart.$mount();
					(this.$refs.charts as any).appendChild(chart.$el);
					this.$store.state.charts.push(chart);
					
					if (chart.chartSpan == 2) {
						chart.$el.classList.add('col-sm-12');
					} else {
						chart.$el.classList.add('col-sm-6');
					}
					
					chart.draw();
				}
				
				// 若非token登入，啟動倒數
				if (!this.$store.state.token) {
					setTimeout(() => {
						this.$store.commit('resetCountdown');
						this.logoutCountdown();
						document.addEventListener('mousemove', this.resetCountdown);
                        document.addEventListener('keydown', this.resetCountdown);
					}, 1000);
				}
				
				
			})
			.catch((err) => {
				console.log(err);
			});

	}
	
	/**
	 * 格式化日期選項
	 */
	formatDt(dt: string) {
		return dt.substr(0, 4) + '年' + dt.substr(4) + '月';
	}
	
	formatNumber(num: string) {
		if (!num) {
			return '0';
		}
		return NumberUtils.commafy(num);
	}
	
	/**
	 * 登出
	 */
	logout() {
		this.$store.state.logedIn = false;
		this.$router.push('/login');
	}
	
	/**
	 * 點選查看其他年月資料
	 */
	changeSnapDt(dt: string) {
		if (this.$store.state.conditions['snapYYYYMM'][0].value != dt) {
			this.$store.state.conditions['snapYYYYMM'][0].value = dt;
			this.$store.commit('refreshHomeInfo');
		}
	}
	
	/**
	 * 組出按鈕名稱
	 */
	getButtonName(filterKey: string) {
		const values = this.$store.state.conditions[filterKey];
		const pair: any[] = [];
		values.forEach((v: any) => {
			if (v.op) {
				if (v.type == 'TIME' && v.op == 'between') {
					pair.push(`"${ColumnMapping.getName(filterKey)}" ${v.op} ${v.value} and ${v.value2}`);
				} else {
					pair.push(`"${ColumnMapping.getName(filterKey)}" ${v.op} ${v.value}`);
				}
				
			} else {
				pair.push(`"${ColumnMapping.getName(filterKey)}" = '${v.value}'`);
			}
			
		});
		return '(' + pair.join(' OR ') + ')';
	}
	
	/**
	 * 移除條件
	 */
	onClickFilter(filterKey: string) {
		//this.$store.dispatch('deleteFilter', {filterKey});
		//console.dir(this.$refs.leftMenu);
		if( this.$refs.leftMenu ){
			(this.$refs.leftMenu as any).showOptionFromFilterBtn(filterKey);
		}
		this.$forceUpdate();
	}
	
	/**
	 * 清除所有條件
	 */
	clearFilters() {
		const keys = Object.keys(this.$store.state.conditions);
		for (let i = 0; i < keys.length; i++) {
			if (keys[i] == 'snapYYYYMM') {
				continue;
			}
			delete this.$store.state.conditions[keys[i]];
		}
		this.currTagGroup = null;
		this.$forceUpdate();
		this.$store.commit('refreshHomeInfo');
	}
	
	/**
	 * 儲存為標籤群組
	 */
	popTagGroup() {
		const ks = Object.keys(this.$store.state.conditions).filter((k:any) => k != 'snapYYYYMM');
		if (this.$store.state.tagGroups.length < 50 && ks.length > 0) {
			(this.$refs.saveTagGroupModal as any).show();
		}
	}

	/**
	 * 選擇標籤群組
	 */
	selectTagGroup(g: any) {
		axios.post('/home/getTagGroup', {groupId: g.id})
		.then((rs: any) => {
				const ks = Object.keys(this.$store.state.conditions);
				for (let i = 0; i < ks.length; i++) {
					if (ks[i] == 'snapYYYYMM') {
						continue;
					}
					delete this.$store.state.conditions[ks[i]];
				}
		
				const keys = Object.keys(rs.data.filters);
				for (let i = 0; i < keys.length; i++) {
					this.$store.state.conditions[keys[i]] = rs.data.filters[keys[i]];
				}
				
				this.currTagGroup = g;
				this.$forceUpdate();
				this.$store.commit('refreshHomeInfo');
			})
			.catch((err) => {
				console.log(err);
			});
	}
	
	/**
	 * 匯出SQL指令
	 */
	exportSQL() {
		(this.$refs.exportSQLModal as any).show();
	}
	
	/**
	 * 選擇上傳檔案
	 */
	selectFile() {
		if (this.uploaded) {
			axios.post('/file/removeAccts')
				.then((rs: any) => {
					this.uploaded = false;
					this.$store.state.uploaded = false;
					this.filename = this.$t('button.upload.custids') as string;
					this.$store.commit('refreshHomeInfo');
					this.$forceUpdate();
				})
				.catch((err) => {
					alert(err.code + '-' + err.message);
				});
		} else {
			const fileEl: any = this.$refs.file;
			fileEl.value = '';
			fileEl.click();
		}
		
	}
	
	/**
	 * 選擇檔案
	 */
	fileChanged() {
		
		const fileEl: any = this.$refs.file;
		const fileInput: any = this.$refs.fileInput;
		
		// 讀取檔案內容
		const fileReader: FileReader = new FileReader();
		fileReader.onloadend = (e: any) => {
			
			this.filename = fileEl.files![0].name;
			this.fileContent = e.target.result;
			this.fileSize = e.total;
			
			this.startUpload();
		};
		fileReader.readAsDataURL(fileEl.files![0]);
		
	}
	
	/**
	 * 開始上傳
	 */
	startUpload() {
		const rq = {
			filename: this.filename,
			fileSize: this.fileSize,
			accts: this.fileContent
		};
		axios.post('/file/uploadAccts', rq)
				.then((rs: any) => {
					// 更新target資訊
					this.$store.commit('refreshTarget');
					console.log('上傳檔案成功');
					
					this.uploaded = true;
					this.$store.state.uploaded = true;
					this.$store.commit('refreshHomeInfo');
					this.$forceUpdate();
				})
				.catch((err) => {
					this.uploaded = false;
					this.$store.state.uploaded = false;
					this.filename = this.$t('button.upload.custids') as string;
					if (err.code == '9992') {
						// 因個資保護因素，上傳名單必須至少要有20筆，請重新上傳。
						const msg = this.$t('error.file.upload') as string;
						alert(msg);
					} else {
						alert(err.code + '-' + err.message);
					}
					this.removeFile();
				});
	}
	
	/**
	 * 移除檔案
	 */
	removeFile() {
		console.log('remove');
	}
	
	logoutCountdown() {
		setTimeout(() => {
			this.$store.state.logoutCountdown = this.$store.state.logoutCountdown - 1;
			const remain = this.$store.state.logoutCountdown;
			console.log('登出倒數'+remain);
			if (remain <= 0) {
				(this.$refs.logoutModal as any).show();
			} else if (this.$store.state.logedIn) {
				this.logoutCountdown();
			}
		}, 1000)
	}
	
	resetCountdown() {
		this.$store.commit('resetCountdown');
	}
}

export function hasFilter(conditions: any): boolean {
  const allConditionKeys = Object.keys(conditions);
  allConditionKeys.splice(
    allConditionKeys.findIndex((ack) => ack == "snapYYYYMM"),
    1
  );
  return allConditionKeys.length > 0;
}