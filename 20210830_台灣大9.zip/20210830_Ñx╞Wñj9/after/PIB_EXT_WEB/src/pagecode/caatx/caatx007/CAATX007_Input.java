package pagecode.caatx.caatx007;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.faces.bean.ManagedBean;

import org.apache.commons.lang.StringUtils;
import org.apache.xmlbeans.XmlException;

import pagecode.caatx.caatx001.CAATX001_Upload;
import pagecode.caatx.caatx006.CAATX006_Rule;
import pagecode.caatx.caatx007.caatx007_choose_card.CAATX007_Choose_Card_View;
import pagecode.caatx.caatx007.caatx007_input.CAATX007_Input_View;
import pagecode.caatx.caatx007.caatx007_upload_id.CAATX007_Upload_Id_View;
import pagecode.caatx.caatx007.caatx007_upload_other.CAATX007_Upload_Other_View;
import pagecode.caatx.caatx007.common.CAATX007ViewForm;
import pagecode.common.helper.ValidEaiCustInfoHelper;
import pagecode.momo.MomoVo.LoginType;
import tw.com.ibm.mf.eai.TxRepeatType;
import tw.com.ibm.mf.eb.CEW302RRepeatType;
import tw.com.ibm.mf.eb.CEW302RSvcRqType;
import tw.com.ibm.mf.eb.CEW309RSvcRqType;
import tw.com.ibm.mf.eb.CEW309RSvcRsType;
import tw.com.ibm.mf.eb.EB032151SvcRqType;
import tw.com.ibm.mf.eb.EB032151SvcRsType;
import tw.com.ibm.mf.eb.EB032168SvcRqType;
import tw.com.ibm.mf.eb.EB032168SvcRsType;

import com.fubon.tw.commons.util.ValidatorUtils;
import com.fubon.tw.pib.biz.b2c.uaa.B2CPibUserExtend;
import com.fubon.tw.pib.common.util.ValidateUtils;
import com.fubon.tw.pib.persistence.b2c.dao.ICaaApplyDataDAO;
import com.fubon.tw.pib.persistence.b2c.dao.ICareerDAO;
import com.fubon.tw.pib.persistence.b2c.dao.ICityDAO;
import com.fubon.tw.pib.persistence.b2c.dao.IZipcodeDAO;
import com.fubon.tw.pib.persistence.b2c.entity.CaaApplyDataEntity;
import com.fubon.tw.pib.persistence.b2c.entity.CareerEntity;
import com.fubon.tw.pib.persistence.b2c.entity.CifCityCodeEntity;
import com.fubon.tw.pib.persistence.b2c.entity.ZipcodeEntity;
import com.fubon.tw.pib.system.TFBPibSystem;
import com.fubon.tw.pib.tr.message.CEW302RRQ;
import com.fubon.tw.pib.tr.message.CEW302RRS;
import com.fubon.tw.pib.tr.message.CEW309RRQ;
import com.fubon.tw.pib.tr.message.CEW309RRS;
import com.fubon.tw.pib.tr.message.EB032151RQ;
import com.fubon.tw.pib.tr.message.EB032151RS;
import com.fubon.tw.pib.tr.message.EB032168RQ;
import com.fubon.tw.pib.tr.message.EB032168RS;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.tw.commons.error.SeverityType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.persistence.dao.DataAccessObjectFactory;
import com.ibm.tw.commons.persistence.entity.GenericEntity;
import com.ibm.tw.commons.persistence.exception.DatabaseException;
import com.ibm.tw.jsf.custom.combo.Combo;
import com.ibm.tw.jsf.custom.combo.ComboItem;
import com.ibm.tw.pib.b2cweb.j2ee.mvc.CAALoginPageCodeBase;
import com.ibm.tw.pib.b2cweb.util.B2CWebUtils;
import com.ibm.tw.pib.integration.eai.EAI;
import com.ibm.tw.pib.integration.eai.EAIChannel;
import com.ibm.tw.pib.integration.eai.EAIException;
import com.ibm.tw.pib.integration.eai.EAIResponse;
import com.ibm.tw.pib.integration.eai.EAIResponseException;
import com.ibm.tw.pib.system.PibSystemId;
import com.ibm.tw.pib.type.BundleType;
import com.ibm.tw.pib.util.ExceptionUtils;
import com.ibm.tw.pib.util.b2c.B2CUtils;

/**
 * PLDC輸入資料
 * 
 * @author Bill
 *
 */
@ManagedBean
public class CAATX007_Input extends CAALoginPageCodeBase<CAATX007_Input_View> {

	public static Map<String, String> MARRIAGE_TYPE = new LinkedHashMap<String, String>();
	public static Map<String, String> EDUCATION_TYPE = new LinkedHashMap<String, String>();
	public static Map<String, String> ASSETS_TYPE = new LinkedHashMap<String, String>();
	static {
		MARRIAGE_TYPE.put("1", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.marriage1")); // 未婚
		MARRIAGE_TYPE.put("2", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.marriage2")); // 已婚

		EDUCATION_TYPE.put("01", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.education1")); // 博士
		EDUCATION_TYPE.put("02", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.education2")); // 碩士
		EDUCATION_TYPE.put("03", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.education3")); // 大專/大學
		EDUCATION_TYPE.put("04", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.education4")); // 高中職
		EDUCATION_TYPE.put("05", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.education5")); // 國中以下
		EDUCATION_TYPE.put("06", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.education6")); // 國小
		// 不識字
		EDUCATION_TYPE.put("08", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.education8"));//其他
		EDUCATION_TYPE.put("07", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.education7")); // 不識字

		ASSETS_TYPE.put("1", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.assets1"));// 100萬元以下
		ASSETS_TYPE.put("2", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.assets2"));// 100萬元（含）~500萬元以下
		ASSETS_TYPE.put("3", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.assets3"));// 500萬元（含）~1,000萬元以下
		ASSETS_TYPE.put("4", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.assets4"));// 1,000萬元（含）~1,500萬元以下
		ASSETS_TYPE.put("5", B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.input.assets5"));// 1,500萬元（含）以上
	}

	@Override
	protected void initViewForm(CAATX007_Input_View viewForm) throws ActionException {
		viewForm.restoreViewFromApplyData();
		getUserData();
		// 名稱若為390帶入則不能更改
//		boolean isNameReadOnly = false;
//		if (StringUtils.isNotBlank(applyData.getCustName())) {
//			isNameReadOnly = applyData.getCustName().equals(getViewForm().getMomoVo().getCustName());
//			isNameReadOnly = true;
//		}
//		viewForm.setNameReadOnly(isNameReadOnly);
		
		Set<String> keys = null;
		// 出生地
		Combo cityItem = new Combo();
		// 將選項送至前端檢驗
		JSONArray cifCityArray = new JSONArray();
		Set<Map.Entry<String, CifCityCodeEntity>> cityMap = TFBPibSystem.getCifCityCodeMap().entrySet();
		addComboValue(cityMap , cityItem , cifCityArray);
		viewForm.setCityItem(cityItem);
		viewForm.setCityArray(cifCityArray);
		
		for (ComboItem item : cityItem.getItems()) {
			if (viewForm.getOcrAddr() != null && item.getLabel().equals(viewForm.getOcrAddr().get("cityName"))) {
				viewForm.setHomeRegistAddrCity(item.getValue());
				viewForm.setHomeplace(item.getValue());
				break;
			}
		}
		
		if (viewForm.getOcrAddr() != null) {
			viewForm.setHomeRegistAddrName(viewForm.getOcrAddr().get("address"));
		}
		
		try {
			Combo zip = new Combo();// 郵遞區號下拉

			ICityDAO cityDao = DataAccessObjectFactory.getDAO(ICityDAO.class);
			List<GenericEntity> cityList = cityDao.getCityList(getLocale().toString());

			Map<String, Integer> zipIndex = new HashMap<String, Integer>();
			for (GenericEntity entity : cityList) {
				String cityCode = entity.getString("CITY_CODE_1");
				String cityName = entity.getString("CITY_NAME");
				String zipCode = entity.getString("ZIPCODE");
				String areaName = entity.getString("AREA_NAME");

				// 因為新竹與嘉義內的地區郵遞區號皆相同，所以加上cifCityCode
				if ("05".equals(cityCode)) { // 新竹市
					if (zipIndex.get(cityCode) == null) {
						zipIndex.put(cityCode, 0);
					}
					zipCode += "_" + zipIndex.get(cityCode);
					zipIndex.put(cityCode, zipIndex.get(cityCode) + 1);
				} else if ("13".equals(cityCode)) { // 嘉義市
					if (zipIndex.get(cityCode) == null) {
						zipIndex.put(cityCode, 0);
					}
					zipCode += "_" + zipIndex.get(cityCode);
					zipIndex.put(cityCode, zipIndex.get(cityCode) + 1);
				}

				// 找到對應的cifCityCode
				String cifCityCode = "";
				for (int index1 = 0; index1 < cifCityArray.size(); index1++) {
					cityName = cityName.replace('台', '臺');
					JSONObject cifCityObj = (JSONObject) cifCityArray.get(index1);
					if (cityName.equals((String) cifCityObj.get("cityName"))) {
						cifCityCode = (String) cifCityObj.get("cityCode");
						break;
					}
				}
				zip.add(areaName, zipCode, cifCityCode);
				
				if (viewForm.getOcrAddr() != null && areaName.equals(viewForm.getOcrAddr().get("townName"))) {
					viewForm.setHomeRegistAddrZip(zipCode);
				}
				
			}
			viewForm.setZipItem(zip);
		} catch (DatabaseException e) {
			logger.error("", e);
			throw ExceptionUtils.getActionException(e);
		}

		// 婚姻
		Combo marriageItem = new Combo();
		keys = MARRIAGE_TYPE.keySet();
		for (String key : keys) {
			marriageItem.add(MARRIAGE_TYPE.get(key), key);
		}
		viewForm.setMarriageItem(marriageItem);

		// 學歷
		Combo educationItem = new Combo();
		keys = EDUCATION_TYPE.keySet();
		for (String key : keys) {
			educationItem.add(EDUCATION_TYPE.get(key), key);
		}
		viewForm.setEducationItem(educationItem);

		// 職業別
		Combo jobItem = new Combo();
		try {
			ICareerDAO careerDao = DataAccessObjectFactory.getDAO(ICareerDAO.class);
			List<CareerEntity> careerList = careerDao.findByLocaleSortByOrder(getLocale());
			JSONArray careerArray = new JSONArray();
			for (CareerEntity entity : careerList) {
				String careerCode = entity.getCareerCode();
				String careerName = entity.getCareerName();
				String careerRiskLvl = entity.getRiskLvl();
				JSONObject careerObj = new JSONObject();
				careerObj.put("careerCode", careerCode);
				careerObj.put("careerName", careerName);
				careerObj.put("careerRiskLvl", careerRiskLvl);
				careerArray.add(careerObj);
				jobItem.add(careerName, careerCode);
			}
			viewForm.setCareerArray(careerArray);
			viewForm.setJobItem(jobItem);
		} catch (DatabaseException e) {
			logger.error("", e);
			throw ExceptionUtils.getActionException(e);
		}

		// 上述資產評估總值
		Combo assetsItem = new Combo();
		keys = ASSETS_TYPE.keySet();
		for (String key : keys) {
			assetsItem.add(ASSETS_TYPE.get(key), key);
		}
		viewForm.setAssetsItem(assetsItem);
		
		// 開戶目的
		Combo purposeItem = new Combo();
		purposeItem.add("信用卡/費用扣繳", "04");
		purposeItem.add("投資理財", "05");
		purposeItem.add("一般存款", "03");
		purposeItem.add("薪資撥入", "01");
		purposeItem.add("貸款需要", "06");
		purposeItem.add("行動支付收單", "98");
		viewForm.setPurposeItem(purposeItem);
		
		// 
		Combo txnfItem = new Combo();
		txnfItem.add("每日", "1");
		txnfItem.add("每周", "2");
		txnfItem.add("每月", "3");
		txnfItem.add("每年", "4");
		viewForm.setTxnfItem(txnfItem);
		
		if (StringUtils.isNotBlank(getLoginUser().getEmail390())) {
			viewForm.setEmail(getLoginUser().getEmail390());
			viewForm.setEmailReadOnly(true);
		} else if (StringUtils.isNotBlank(getLoginUser().getEmail400())) {
			viewForm.setEmail(getLoginUser().getEmail400());
			viewForm.setEmailReadOnly(true);
		}
		
		viewForm.setCCDFlag(checkCCDFlag(getLoginUser().getCompanyUid()));
		
		// 有5G卡?
		// 非約定他行扣繳?
		viewForm.setShowDiscount(check5G() && checkAppoint());
	}
	
	private boolean check5G() {
		EAI<CEW302RRQ, CEW302RRS> cew302rEaiAdaptor = EAI.newInstance(EAIChannel.CBS_AS400, CEW302RRQ.class, CEW302RRS.class);
		CEW302RSvcRqType cew302rRq = cew302rEaiAdaptor.getRequest().getBody();
		cew302rRq.setID(getLoginUser().getCompanyUid());
		try {
			CEW302RRS cew302rRs = cew302rEaiAdaptor.sendAndReceive(B2CUtils.getAccessLogKeyFromRequestScope(), "CAA數存預帶資料檢查信用卡狀態");
			for (TxRepeatType repeat : cew302rRs.getBody().getTxRepeatArray()) {
				CEW302RRepeatType cardInfo = (CEW302RRepeatType) repeat.changeType(CEW302RRepeatType.type);
				if ("0".equals(cardInfo.getCARDSTATUS()) && 
						Arrays.asList("3483", "3583", "34A8").contains(cardInfo.getCARDTYPE())) {
					// 有效卡才放入, 不須判斷是不是正卡
					return true;
				}
			}
			
			return false;
			
		} catch (XmlException | EAIException | EAIResponseException e) {
			logger.error(e);
			logger.info("CEW302R電文取得有誤");
			return false;
		}
	}
	
	private boolean checkAppoint() {
		EAI<CEW309RRQ, CEW309RRS> eai = EAI.newInstance(EAIChannel.CBS_AS400, CEW309RRQ.class, CEW309RRS.class);
    	CEW309RSvcRqType rqBody = eai.getRequest().getBody();
        EAIResponse<CEW309RSvcRqType, CEW309RSvcRsType> rs = null;
        rqBody.setCustACID(getLoginUser().getCompanyUid());//歸戶ID
        rqBody.setCustTYPE("Q");//交易類別

        try {
        	rs = eai.sendAndReceive(B2CWebUtils.getAccessLogKeyFromRequestScope(), "查詢富邦信用卡代扣繳");
        	//AbndCode<>0000、V803、A125表示失敗，顯示「錯誤代碼 + 錯誤訊息
        	if(StringUtils.equals("0000", rs.getBody().getAbndCode())) {
        		if (StringUtils.isBlank(rs.getBody().getCustCurBnk()) || "012".equals(rs.getBody().getCustCurBnk())) {
        			return true;
        		}
        		
        	}

 		} catch(Exception ex) {
 			logger.error("error sending CEW309R", ex);
 		}
        return false;
	}
	
	/**
	 * 寫入指定縣市至ComboItem
	 * @param cityMap
	 * @param cityItem
	 * @param field
	 */
	public void addComboValue(Set<Map.Entry<String, CifCityCodeEntity>> cityMap , Combo cityItem , JSONArray cifCityArray){
		Map<Integer,ComboItem> map = new TreeMap<Integer, ComboItem>();
		Integer count = 7; /* 從六都之後開始計算 */
		for (Map.Entry<String, CifCityCodeEntity> entry : cityMap) {
			String cifCityCode = entry.getKey();
			String cifCityName = entry.getValue().getCityName();
			switch(cifCityName){
				case "臺北市":
					map.put(1, new ComboItem(cifCityName,cifCityCode));
					break;
				case "台北市":
					map.put(1, new ComboItem("臺北市",cifCityCode));
					break;
				case "新北市":
					map.put(2, new ComboItem(cifCityName,cifCityCode));
					break;
				case "桃園市":
					map.put(3, new ComboItem(cifCityName,cifCityCode));
					break;
				case "臺中市":
					map.put(4, new ComboItem(cifCityName,cifCityCode));
					break;
				case "台中市":
					map.put(4, new ComboItem("臺中市",cifCityCode));
					break;
				case "臺南市":
					map.put(5, new ComboItem(cifCityName,cifCityCode));
					break;
				case "台南市":
					map.put(5, new ComboItem("臺南市",cifCityCode));
					break;
				case "高雄市":
					map.put(6, new ComboItem(cifCityName,cifCityCode));
					break;
				case "台東縣":
					map.put(count, new ComboItem("臺東縣",cifCityCode));
					count ++;
					break;
				default:
					map.put(count, new ComboItem(cifCityName,cifCityCode));
					count ++;
					break;
			}
		}
		
		for(Entry<Integer, ComboItem> e : map.entrySet()){
			ComboItem c = e.getValue();
			JSONObject cifCityObj = new JSONObject();
			cifCityObj.put("cityName", c.getLabel());
			cifCityObj.put("cityCode", c.getValue());
			cifCityArray.add(cifCityObj);
			cityItem.add(c);
		}
	}

	/**
	 * 上一步
	 * 
	 * @return
	 */
	public String doPrevAction() {
		CAATX007ViewForm viewForm;
		CaaApplyDataEntity applyData = getViewForm().getSavedApplyData();
		if (StringUtils.isNotEmpty(applyData.getIdFileName1()) && StringUtils.isNotEmpty(applyData.getIdFileName2())) {
			viewForm = new CAATX007_Upload_Other_View();
		} else {
			viewForm = new CAATX007_Upload_Id_View();
		}
		viewForm.copy(getViewForm());
		return getOutcome(viewForm);
	}

	/**
	 * 下一步
	 * 
	 * @return
	 * @throws ActionException
	 */
	public String doNextAction() throws ActionException {
		if (!validate()) {
			return getOutcome(getViewForm());
		}

		ICaaApplyDataDAO dao = DataAccessObjectFactory.getDAO(ICaaApplyDataDAO.class);
		CAATX007_Input_View thisView = getViewForm();
		CAATX007_Choose_Card_View nextView = new CAATX007_Choose_Card_View();
		CaaApplyDataEntity applyData = getViewForm().getSavedApplyData();

		applyData.setApplyStep(CAATX007Helper.STEP_INPUT);
		// 姓名
		applyData.setMobileNo(getViewForm().getMobile());
		// 行動電話
		applyData.setCustName(getViewForm().getName());
		// 連絡電話
		applyData.setHomeTel(getViewForm().getTelPhone());
		// 連絡電話區碼
		applyData.setHomeTelArea(getViewForm().getTelCode());
		// 信箱
		applyData.setEmail(getViewForm().getEmail());
		// 出生地
		applyData.setHomeplace(getViewForm().getHomeplace());
		// 婚姻狀況
		applyData.setMarriage(getViewForm().getMarriage());
		// 學歷
		applyData.setEducation(getViewForm().getEducation());
		// 職業
		applyData.setCareer(getViewForm().getJob());

		// 若職業為學生、家管、退休、無，任職公司、職稱不檢查
		if (!"12".equals(getViewForm().getJob()) && !"17".equals(getViewForm().getJob())
				&& !"21".equals(getViewForm().getJob()) && !"22".equals(getViewForm().getJob())) {
			// 任職公司
			applyData.setCompanyName(getViewForm().getCompany());
			// 職稱
			applyData.setTitle(getViewForm().getJobTitle());
		} else {
			// 任職公司
			applyData.setCompanyName("無");
			// 職稱
			applyData.setTitle("無");
		}
		// 年收入
		applyData.setAnnualIncome(getViewForm().getIncome());
		applyData.setOpenAcctPurpose(getViewForm().getPurpose());
		// 戶籍地址-郵遞區號
		String homeRegistZip = getViewForm().getHomeRegistAddrZip();
		if (StringUtils.isNotBlank(homeRegistZip)) {
			homeRegistZip = homeRegistZip.indexOf("_") == -1 ? homeRegistZip
					: homeRegistZip.substring(0, homeRegistZip.indexOf("_"));
		}
		applyData.setHomeRegistAddrZip(homeRegistZip);
		String homeRegistAddrCityCode = getViewForm().getHomeRegistAddrCity();
		// 戶籍地址-縣市代碼
		applyData.setHomeRegistAddrCityCode(homeRegistAddrCityCode);
		// 戶籍地址-縣市名稱
		applyData.setHomeRegistAddrCityName(getCityNameByCifCityCode(homeRegistAddrCityCode));
		// 戶籍地址-鄉鎮市區代碼
		applyData.setHomeRegistAddrTownCode(homeRegistZip);
		// 戶籍地址-鄉鎮市區代碼
		applyData.setHomeRegistAddrTownName(getTownNameByZip(getViewForm().getHomeRegistAddrZip()));
		// 戶籍地址
		applyData.setHomeRegistAddrName(getViewForm().getHomeRegistAddrName());

		// 若同戶籍選項勾選，將戶籍資訊複製到現住資訊
		if (getViewForm().getSameHomeRegistAddr2()) {
			applyData.setHomeAddrFlag("1");
			applyData.setResZipCode(applyData.getHomeRegistAddrZip());
			// 現住地址
			String addr = applyData.getHomeRegistAddrCityName() + applyData.getHomeRegistAddrTownName()
					+ applyData.getHomeRegistAddrName();
			applyData.setResAddr(addr);
		} else {
			applyData.setHomeAddrFlag("");
			// 現住地址-郵遞區號
			String currentZip = getViewForm().getCurrentZip();
			if (StringUtils.isNotBlank(currentZip)) {
				currentZip = currentZip.indexOf("_") == -1 ? currentZip
						: currentZip.substring(0, currentZip.indexOf("_"));
			}
			applyData.setResZipCode(currentZip);
			// 現住地址
			String addr = getCityNameByCifCityCode(getViewForm().getCurrentCity())
					+ getTownNameByZip(getViewForm().getCurrentZip()) + getViewForm().getCurrentAddrName();
			applyData.setResAddr(addr);
		}

		// 若同戶籍選項勾選，將戶籍資訊複製到通訊資訊
		if (getViewForm().getSameHomeRegistAddr()) {
			// 通訊地址-同戶籍地址
			applyData.setSameCusaddrFlag("1");
			// 通訊地址-同現居地址
			applyData.setSameResaddrFlag("");
			// 通訊地址-郵遞區號
			applyData.setHomeAddrZip(applyData.getHomeRegistAddrZip());
			// 通訊地址-縣市代碼
			applyData.setHomeAddrCityCode(applyData.getHomeRegistAddrCityCode());
			// 通訊地址-縣市名稱
			applyData.setHomeAddrCityName(applyData.getHomeRegistAddrCityName());
			// 通訊地址-鄉鎮市區代碼
			applyData.setHomeAddrTownCode(applyData.getHomeRegistAddrTownCode());
			// 通訊地址-鄉鎮市區名稱
			applyData.setHomeAddrTownName(applyData.getHomeRegistAddrTownName());
			// 通訊地址
			applyData.setHomeAddrName(applyData.getHomeRegistAddrName());
		} else if (getViewForm().getSameCurrentAddr()) {
			// 若同現居選項勾選，將現居資訊複製到通訊資訊

			// 通訊地址-同戶籍地址
			applyData.setSameCusaddrFlag("");
			// 通訊地址-同現居地址
			applyData.setSameResaddrFlag("1");

			Map<String, String> currentAddrMap = CAATX007_Rule.getFormatAddress(applyData.getResAddr(),
					getLocale().toString());
			if (currentAddrMap != null) {
				// 通訊地址-縣市代碼
				applyData.setHomeAddrCityCode(currentAddrMap.get(CAATX007_Rule.CITY_CODE));
				// 通訊地址-縣市名稱
				applyData.setHomeAddrCityName(currentAddrMap.get(CAATX007_Rule.CITY_NAME));
				// 通訊地址-鄉鎮市區代碼
				applyData.setHomeAddrTownCode(getViewForm().getZipCodeByTownName(
						currentAddrMap.get(CAATX007_Rule.CITY_NAME), currentAddrMap.get(CAATX007_Rule.TOWN_NAME)));
				// 通訊地址-鄉鎮市區名稱
				applyData.setHomeAddrTownName(getTownNameByZip(getViewForm().getCurrentZip()));
				// 通訊地址
				applyData.setHomeAddrName(currentAddrMap.get(CAATX007_Rule.ADDRESS));
				applyData.setHomeAddrZip(applyData.getResZipCode());
			}
		} else {
			// 通訊地址-同戶籍地址
			applyData.setSameCusaddrFlag("");
			// 通訊地址-同現居地址
			applyData.setSameResaddrFlag("");
			// 通訊地址-郵遞區號
			String homeZip = getViewForm().getContactZip();
			if (StringUtils.isNotBlank(homeZip)) {
				homeZip = homeZip.indexOf("_") == -1 ? homeZip : homeZip.substring(0, homeZip.indexOf("_"));
			}
			applyData.setHomeAddrZip(homeZip);
			String homeAddrCityCode = getViewForm().getContactCity();
			// 通訊地址-縣市代碼
			applyData.setHomeAddrCityCode(homeAddrCityCode);
			// 通訊地址-縣市名稱
			applyData.setHomeAddrCityName(getCityNameByCifCityCode(homeAddrCityCode));
			// 通訊地址-鄉鎮市區代碼
			applyData.setHomeAddrTownCode(homeZip);
			// 通訊地址-鄉鎮市區名稱
			applyData.setHomeAddrTownName(getTownNameByZip(getViewForm().getContactZip()));
			// 通訊地址
			applyData.setHomeAddrName(getViewForm().getContactAddrName());
		}

		if (!getViewForm().isShowDiscount()) {
			// 資產及收入之主要來源
			Boolean[] assetsSrcArray = getViewForm().getAssetsSrc();
			ArrayList<String> assetsSrcs = new ArrayList<String>();
			for (int index = 0; index < assetsSrcArray.length; index++) {
				if (assetsSrcArray[index]) {
					assetsSrcs.add(String.valueOf(index));
				}
			}
			applyData.setAssetSource(StringUtils.join(assetsSrcs.toArray(new String[assetsSrcs.size()]), ","));

			// 資產及收入之主要來源其他項目輸入
			applyData.setAssetsText(getViewForm().getAssetsSrcInput());
			// 資產總值
			applyData.setAssetsTotal(getViewForm().getAssets());
			
			// 預期往來業務
			List<String> buf = new ArrayList<>();
			for (int i = 0; i < getViewForm().getBiz().length; i++) {
				if (getViewForm().getBiz()[i]) {
					buf.add(i + "");
				}
			}
			applyData.setBizType(StringUtils.join(buf, ","));
			applyData.setBizMemo(getViewForm().getBizOther());
			applyData.setExpectedRate(getViewForm().getTxnf());
			applyData.setExpectedAmt(getViewForm().getTxnAmt());
		}
		
		
		try {
			applyData.setUpdateTime(new Date()); /* 資料更新時間 */
			dao.update(applyData);
			getViewForm().setSavedApplyData(applyData);
		} catch (DatabaseException ex) {
			throw ExceptionUtils.getActionException(ex);
		}
		nextView.copy(thisView);
		nextView.setShowDiscount(getViewForm().isShowDiscount());
		return getOutcome(nextView);
	}

	public String getCityNameByCifCityCode(String cifCityCode) throws ActionException {
		if (StringUtils.isBlank(cifCityCode))
			return "";

		JSONArray cifCityArray = getViewForm().getCityArray();
		if (!cifCityArray.isEmpty()) {
			for (int index = 0; index < cifCityArray.size(); index++) {
				JSONObject cifCityObj = (JSONObject) cifCityArray.get(index);
				if (cifCityCode.equals((String) cifCityObj.get("cityCode"))) {
					return (String) cifCityObj.get("cityName");
				}
			}
		} else {
			cifCityArray = new JSONArray();
			for (Map.Entry<String, CifCityCodeEntity> entry : TFBPibSystem.getCifCityCodeMap().entrySet()) {
				if (cifCityCode.equals(entry.getKey())) {
					return entry.getValue().getCityName();
				}
			}
		}
		return "";
	}

	public String getTownNameByZip(String zip) {
		if (StringUtils.isBlank(zip)) {
			return "";
		}
		int index = zip.indexOf("_") == -1 ? 0 : Integer.valueOf(zip.substring(zip.indexOf("_") + 1));
		zip = zip.indexOf("_") == -1 ? zip : zip.substring(0, zip.indexOf("_"));

		IZipcodeDAO dao = DataAccessObjectFactory.getDAO(IZipcodeDAO.class);
		try {
			List<ZipcodeEntity> zips = dao.getByZipCode(zip, getLocale().toString());
			if (zips.isEmpty()) {
				return "";
			}
			return zips.get(index).getAreaName();
		} catch (DatabaseException e) {
			logger.error(e.getMessage(), e);
			return "";
		}
	}

	private boolean validate() {

		boolean result = true;

		// 姓名
		if (StringUtils.isBlank(getViewForm().getName())) {
			addFacesMessage(getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.name"));
			result = false;
		}

		// 行動電話
		if (StringUtils.isBlank(getViewForm().getMobile())) {
			addFacesMessage(getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.mobile"));
			result = false;
		} else {
			// 行動電話限輸入10位數字
			if (StringUtils.trimToEmpty(getViewForm().getMobile()).length() != 10) {
				addFacesMessage(getBundleString("caatx006.input.mobileFormatError"));
				result = false;
			} else {
				// 行動電話前2碼須為09開頭
				if (!StringUtils.trimToEmpty(getViewForm().getMobile()).startsWith("09")) {
					addFacesMessage(getBundleString("caatx006.input.mobileLengthError"));
					result = false;
				}
			}
		}

		// 連絡電話
		if (StringUtils.isNotBlank(getViewForm().getTelCode()) || StringUtils.isNotBlank(getViewForm().getTelPhone())) {
			if (StringUtils.isBlank(getViewForm().getTelCode()) || StringUtils.isBlank(getViewForm().getTelPhone())) {
				addFacesMessage(getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.telPhone"));
				result = false;
			} else {
				try {
					Integer.parseInt(getViewForm().getTelCode());
				} catch (NumberFormatException ex) {
					addFacesMessage(getBundleString("caatx006.input.phoneAreaCodeError"));
					result = false;
				}

				try {
					Integer.parseInt(getViewForm().getTelPhone());

					if (StringUtils.trimToEmpty(getViewForm().getTelPhone()).length() < 7
							|| StringUtils.trimToEmpty(getViewForm().getTelPhone()).length() > 8) {
						addFacesMessage(getBundleString("caatx006.input.phoneNumberError"));
						result = false;
					}

				} catch (NumberFormatException ex) {
					addFacesMessage(getBundleString("caatx006.input.phoneNumberError"));
					result = false;
				}
			}
		}
		

		// Email信箱
		if (StringUtils.isBlank(getViewForm().getEmail())) {
			addFacesMessage(getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.email1"));
			result = false;
		} else {
			if (!ValidatorUtils.isValidEmailFormat(getViewForm().getEmail())) {
				addFacesMessage(getBundleString("caatx006.input.emailFormatError"));
				result = false;
			}
		}

		// 出生地
		if ("none".equals(getViewForm().getHomeplace())) {
			addFacesMessage(getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.email1"));
			result = false;
		}

		// 戶籍地址
		if (StringUtils.isBlank(getViewForm().getHomeRegistAddrName())) {
			/* 請輸入戶籍地址 */
			addFacesMessage(getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.homeAddr"));
			result = false;
		} else {
			if (StringUtils.trimToEmpty(getViewForm().getHomeRegistAddrName()).length() < 5) {
				/* 請輸入完整戶籍地址 */
				addFacesMessage(getBundleString("caatx006.chooseCard.pleaseInput")
						+ getBundleString("caatx006.input.validate.full") + getBundleString("caatx006.input.homeAddr"));
				result = false;
			} else if (StringUtils.trimToEmpty(getViewForm().getHomeRegistAddrName()).length() > 30) {
				/* 戶籍地址長度不可以大於30位! */
				addFacesMessage(
						getBundleString("caatx006.input.homeAddr") + getBundleString("caatx006.input.maxAddrLeng"));
				result = false;
			}
		}

		if (StringUtils.isBlank(getViewForm().getHomeRegistAddrCity())
				|| "none".equals(getViewForm().getHomeRegistAddrCity())) {
			/* 請選擇戶籍地址縣市 */
			addFacesMessage(getBundleString("caatx006.chooseCard.pleaseSelect")
					+ getBundleString("caatx006.input.homeAddr") + getBundleString("caatx006.input.city"));
			result = false;
		}

		if (StringUtils.isBlank(getViewForm().getHomeRegistAddrZip())
				|| "none".equals(getViewForm().getHomeRegistAddrZip())) {
			/* 請選擇戶籍地址鄉/鎮/市/區 */
			addFacesMessage(getBundleString("caatx006.chooseCard.pleaseSelect")
					+ getBundleString("caatx006.input.homeAddr") + getBundleString("caatx006.input.area"));
			result = false;
		}

		if (!getViewForm().getSameHomeRegistAddr2()) {
			// 現住地址
			if (StringUtils.isBlank(getViewForm().getCurrentAddrName())) {
				/* 請輸入現住地址 */
				addFacesMessage(
						getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.currentAddr"));
				result = false;
			} else {
				if (StringUtils.trimToEmpty(getViewForm().getCurrentAddrName()).length() < 5) {
					/* 請輸入完整現住地址 */
					addFacesMessage(getBundleString("caatx006.chooseCard.pleaseInput")
							+ getBundleString("caatx006.input.validate.full")
							+ getBundleString("caatx006.input.currentAddr"));
					result = false;
				} else if (StringUtils.trimToEmpty(getViewForm().getCurrentAddrName()).length() > 30) {
					/* 現住地址長度不可以大於30位! */
					addFacesMessage(getBundleString("caatx006.input.currentAddr")
							+ getBundleString("caatx006.input.maxAddrLeng"));
					result = false;
				}

			}
			if (StringUtils.isBlank(getViewForm().getCurrentCity())
					|| "none".equals(getViewForm().getCurrentCity())) {
				/* 請選擇現住地址縣市 */
				addFacesMessage(getBundleString("caatx006.chooseCard.pleaseSelect")
						+ getBundleString("caatx006.input.currentAddr") + getBundleString("caatx006.input.city"));
				result = false;
			}
			if (StringUtils.isBlank(getViewForm().getCurrentZip())
					|| "none".equals(getViewForm().getCurrentZip())) {
				/* 請選擇現住地址鄉/鎮/市/區 */
				addFacesMessage(getBundleString("caatx006.chooseCard.pleaseSelect")
						+ getBundleString("caatx006.input.currentAddr") + getBundleString("caatx006.input.area"));
				result = false;
			}
		}

		if (!getViewForm().getSameHomeRegistAddr() && !getViewForm().getSameCurrentAddr()) {
			// 通訊地址
			if (StringUtils.isBlank(getViewForm().getContactAddrName())) {
				/* 請輸入通訊地址 */
				addFacesMessage(
						getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.contactAddr"));
				result = false;
			} else {
				if (StringUtils.trimToEmpty(getViewForm().getContactAddrName()).length() < 5) {
					/* 請輸入完整通訊地址 */
					addFacesMessage(getBundleString("caatx006.chooseCard.pleaseInput")
							+ getBundleString("caatx006.input.validate.full")
							+ getBundleString("caatx006.input.contactAddr"));
					result = false;
				} else if (StringUtils.trimToEmpty(getViewForm().getContactAddrName()).length() > 30) {
					/* 通訊地址長度不可以大於30位! */
					addFacesMessage(getBundleString("caatx006.input.contactAddr")
							+ getBundleString("caatx006.input.maxAddrLeng"));
					result = false;
				}

			}
			if (StringUtils.isBlank(getViewForm().getContactCity())
					|| "none".equals(getViewForm().getContactCity())) {
				/* 請選擇通訊地址縣市 */
				addFacesMessage(getBundleString("caatx006.chooseCard.pleaseSelect")
						+ getBundleString("caatx006.input.contactAddr") + getBundleString("caatx006.input.city"));
				result = false;
			}
			if (StringUtils.isBlank(getViewForm().getContactZip()) || "none".equals(getViewForm().getContactZip())) {
				/* 請選擇通訊地址鄉/鎮/市/區 */
				addFacesMessage(getBundleString("caatx006.chooseCard.pleaseSelect")
						+ getBundleString("caatx006.input.contactAddr") + getBundleString("caatx006.input.area"));
				result = false;
			}
		}

		// 婚姻狀況
		if ("none".equals(getViewForm().getMarriage())) {
			addFacesMessage(getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.marriage"));
			result = false;
		}

		// 學歷
		if ("none".equals(getViewForm().getEducation())) {
			addFacesMessage(
					getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.education"));
			result = false;
		}

		// 職業
		if ("none".equals(getViewForm().getJob())) {
			addFacesMessage(getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.job"));
			result = false;
		} else {
			JSONArray careerArray = getViewForm().getCareerArray();
			for (int index = 0; index < careerArray.size(); index++) {
				JSONObject career = (JSONObject) careerArray.get(index);
				if (getViewForm().getJob().equals(career.get("careerCode"))) {
					if ("5".equals(career.get("careerRiskLvl"))) {
						addFacesMessage(getBundleString("caatx006.input.contactClient"));
						result = false;
					}
					break;
				}
			}
		}

		// 若職業為學生、家管、退休、無，任職公司、職稱不檢查
		if (!"12".equals(getViewForm().getJob()) && !"17".equals(getViewForm().getJob())
				&& !"21".equals(getViewForm().getJob()) && !"22".equals(getViewForm().getJob())) {
			// 任職公司
			if (StringUtils.isBlank(getViewForm().getCompany())) {
				addFacesMessage(
						getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.company"));
				result = false;
			} else {
				// 12字內
				if (getViewForm().getCompany().length() > 12) {
					addFacesMessage(getBundleString("caatx001.input.company.errorMessage"));
					result = false;
				}
			}
			// 職稱
			if (StringUtils.isBlank(getViewForm().getJobTitle())) {
				addFacesMessage(
						getBundleString("caatx006.input.pleaseInput") + getBundleString("caatx006.input.jobTitle"));
				result = false;
			}
			// 職稱不可超過10bytes
			// int count = 0;
			// char[] chs = getViewForm().getJobTitle().toCharArray();
			// for(int i = 0; i < chs.length; i++) {
			// count += (chs[i] > 0xff) ? 2 : 1;
			// }
			// if(count > 10){
			// 中文僅限輸入五個字
			// addFacesMessage(getBundleString("caatx006.input.jobTitle.errorMessage"));
			// result = false;
			// }

			if (getViewForm().getJobTitle().length() > 5) {
				addFacesMessage(getBundleString("caatx006.input.jobTitle.errorMessage"));
				result = false;
			}
		}

		// 年收入(萬元)
		if (StringUtils.isBlank(getViewForm().getIncome())) {
			addFacesMessage(
					getBundleString("caatx006.input.pleaseSelect") + getBundleString("caatx006.input.incomeNullError"));
			result = false;
		} else {
			try {
				Integer.parseInt(getViewForm().getIncome());
			} catch (NumberFormatException ex) {
				addFacesMessage(getBundleString("caatx006.input.incomeMustBeNumber"));
				result = false;
			}
		}

		if (!getViewForm().isShowDiscount()) {
			// 資產及收入之主要來源
			result = false;
			Boolean[] assetsSrcArray = getViewForm().getAssetsSrc();
			for (int index = 0; index < assetsSrcArray.length - 1; index++) {
				if (assetsSrcArray[index]) {
					result = true;
					break;
				}
			}

			if (assetsSrcArray[11]) {
				if ("".equals(StringUtils.trimToEmpty(getViewForm().getAssetsSrcInput())))
					result = false;
				else
					result = true;
			}

			// 上述資產評估總值
			if (getViewForm().getMomoVo().getLoginType() == LoginType.MOMO_CAA_OSV && !getViewForm().isCCDFlag()) {
				if (StringUtils.isBlank(getViewForm().getAssets())) {
					addFacesMessage(getBundleString("caatx006.input.pleaseSelect") + getBundleString("caatx006.input.assets"));
					result = false;
				}
			}
		}
		
		
		return result;
	}
	
	private void getUserData() {
		if (StringUtils.isNotBlank(getViewForm().getMomoVo().getCustEmail())) {
			getViewForm().setEmail(getViewForm().getMomoVo().getCustEmail());
			getViewForm().setEmailReadOnly(true);
		}
		
//		if ("TWM".equals(getSessionScope().get(CAATX007Helper.PRJ_CODE))) {
			CaaApplyDataEntity applyData = getViewForm().getSavedApplyData();
			if (applyData != null) {
				getViewForm().setName(applyData.getCustName());
				getViewForm().setNameReadOnly(true);
				getViewForm().setTelCode(applyData.getHomeTelArea());
				getViewForm().setTelPhone(applyData.getHomeTel());
				getViewForm().setEmail(applyData.getEmail());
				getViewForm().setEmailReadOnly(true);
				getViewForm().setEducation(applyData.getEducation());
				getViewForm().setHomeRegistAddrCity(applyData.getHomeRegistAddrCityCode());
				getViewForm().setHomeRegistAddrZip(applyData.getHomeRegistAddrTownCode());
				getViewForm().setHomeRegistAddrName(applyData.getHomeRegistAddrName());
				if ("1".equals(applyData.getHomeAddrFlag())) {
					getViewForm().setSameHomeRegistAddr2(true);
					getViewForm().setCurrentCity(applyData.getHomeRegistAddrCityCode());
					getViewForm().setCurrentZip(applyData.getHomeRegistAddrTownCode());
					getViewForm().setCurrentAddrName(applyData.getHomeRegistAddrName());
				} else {
					getViewForm().setSameHomeRegistAddr2(false);
					Map<String, String> currentAddrMap = CAATX006_Rule.getFormatAddress(applyData.getResAddr(), getLocale().toString());
					if (currentAddrMap != null) {
						getViewForm().setCurrentCity(currentAddrMap.get(CAATX006_Rule.CITY_CODE));
						getViewForm().setCurrentZip(applyData.getResZipCode());
						getViewForm().setCurrentAddrName(applyData.getResAddr());
					}
					
				}
				getViewForm().setJob(applyData.getCareer());
				getViewForm().setCompany(applyData.getCompanyName());
				getViewForm().setJobTitle(applyData.getTitle());
				getViewForm().setIncome(applyData.getAnnualIncome());
			}
			
			EAI<EB032151RQ, EB032151RS> eaiAdaptor2 = EAI.newInstance(EAIChannel.CBS, EB032151RQ.class, EB032151RS.class);
			EB032151SvcRqType rq = eaiAdaptor2.getRequest().getBody();
			eaiAdaptor2.getRequest().getHeader().setHTLID("2004115");
			rq.setFUNC("0");
			rq.setCUSTNO(getLoginUser().getUserUuid());
			rq.setIDTYPE(B2CPibUserExtend.getIDTYPE(getLoginUser().getCompanyUid()));/* Wing 20200319 CBS新增  */
			try {
				EB032151RS rs = eaiAdaptor2.sendAndReceive(B2CUtils.getAccessLogKeyFromRequestScope(),"CAATX001存貸戶發查資料");
				EB032151SvcRsType rsBody = rs.getBody();
				
				String accountName = StringUtils.trimToEmpty(rsBody.getCUSTNAME());
				getViewForm().setName(StringUtils.isBlank(getViewForm().getName()) ? accountName : getViewForm().getName());
				getViewForm().setNameReadOnly(true);
				
				String[] telNo1 = formatTel(rsBody.getCONTEL());
				String telArea = telNo1[0];
				String tel = telNo1[1];
				getViewForm().setTelCode(StringUtils.isBlank(getViewForm().getTelCode()) ? telArea : getViewForm().getTelCode());
				getViewForm().setTelPhone(StringUtils.isBlank(getViewForm().getTelPhone()) ? tel : getViewForm().getTelPhone());
				getViewForm().setEducation(StringUtils.isBlank(getViewForm().getEducation()) ? StringUtils.trimToEmpty(rsBody.getEDUCATION()) : getViewForm().getEducation());

				String homeRegistAddr = ValidateUtils.trimFWToEmpty(rsBody.getBUSADDR1())
						+ ValidateUtils.trimFWToEmpty(rsBody.getBUSADDR2());
				Map<String, String> homeRegistAddrMap = CAATX001_Upload.getFormatAddress(getLoginUser(), homeRegistAddr);
				if (homeRegistAddrMap != null) {
					getViewForm().setHomeRegistAddrCity(StringUtils.isBlank(getViewForm().getHomeRegistAddrCity()) ? homeRegistAddrMap.get(CAATX001_Upload.CITY_CODE) : getViewForm().getHomeRegistAddrCity());
					getViewForm().setHomeRegistAddrZip(StringUtils.isBlank(getViewForm().getHomeRegistAddrZip()) ? homeRegistAddrMap.get(CAATX001_Upload.TOWN_CODE) : getViewForm().getHomeRegistAddrZip());
					getViewForm().setHomeRegistAddrName(StringUtils.isBlank(getViewForm().getHomeRegistAddrName()) ? homeRegistAddrMap.get(CAATX001_Upload.ADDRESS) : getViewForm().getHomeRegistAddrName());
				}

				String homeAddr = ValidateUtils.trimFWToEmpty(rsBody.getCTTADDR1())
						+ ValidateUtils.trimFWToEmpty(rsBody.getCTTADDR2());
				Map<String, String> homeAddrMap = CAATX001_Upload.getFormatAddress(getLoginUser(), homeAddr);
				if (homeAddrMap != null) {
					getViewForm().setCurrentCity(StringUtils.isBlank(getViewForm().getCurrentCity()) ? homeAddrMap.get(CAATX001_Upload.CITY_CODE) : getViewForm().getCurrentCity());
					getViewForm().setCurrentZip(StringUtils.isBlank(getViewForm().getCurrentZip()) ? homeAddrMap.get(CAATX001_Upload.TOWN_CODE) : getViewForm().getCurrentZip());
					getViewForm().setCurrentAddrName(StringUtils.isBlank(getViewForm().getCurrentAddrName()) ? homeAddrMap.get(CAATX001_Upload.ADDRESS) : getViewForm().getCurrentAddrName());
				}
			} catch (XmlException ex) {
				logger.error("預帶390資料錯誤", ex);
			} catch (EAIException ex) {
				logger.error("預帶390資料錯誤", ex);
			} catch (EAIResponseException ex) {
				logger.error("預帶390資料錯誤", ex);
			}
			
			
			
//		}
		
	}
	
	/**
	 * 電話拆分
	 * @param tel
	 * @return
	 */
	private static String[] formatTel(String tel) {
		tel = tel.replace(" ", "");
		String [] format = new String[2];
		Integer i = 2;
		List<String> areaCode = Arrays.asList("037","049","082","089","0836");
		for (String s : areaCode) {
			if(tel.startsWith(s)) {i = s.length();}
		}
		format[0] = tel.substring(0,i);
		format[1] = tel.substring(i);
		return format;
	}
	
	/**
    * 檢核洗錢風險
    * 
     * @return boolean : true(高風險 ，需送上 往來資金資訊) false(中低風險)
    * @throws ActionException
    */
    protected boolean checkCCDFlag(String idNo) throws ActionException {
        String flagIvsVal = "高";
        // String[] flagVal = {"中","低"};
        boolean result = false;
        String step1 = "";
        try {
            step1 = sendEB032151(idNo);
        } catch (ActionException aEx) {
            // 資料不存在，要看EB032168確認是否為全新戶
            if (!aEx.getErrorCode().contains("2214")) {
                throw aEx;
            }
        }

        if ("".equals(step1)) {
            String step2 = flagIvsVal;
            step2 = sendEB032168(idNo);
            if (!"".equals(step2)) {
                if (flagIvsVal.equals(step2)) {
                    result = true;
                }
            }
        } else {
            if (flagIvsVal.equals(step1)) {
                result = true;
            }
        }
        return result;
    }

    /**
	 * AML 洗錢風險 EB032151
	 * 
	 * @return
	 * @throws ActionException
	 */
	protected String sendEB032151(String idNo) throws ActionException {
		String rst = "";
		try {
			EB032151SvcRsType eb032151RsBody = ValidEaiCustInfoHelper.getInstance().sendEB032151(PibSystemId.CAA.getSystemId(), idNo) ;
			if (StringUtils.isNotBlank(eb032151RsBody.getCCDFLG())) {
				rst = eb032151RsBody.getCCDFLG().trim();
			}
		}
        catch (ActionException ex) {
        	throw new ActionException(PibSystemId.CAA.getSystemId(),ex.getErrorCode(), SeverityType.ERROR, ex.getMessage());
        }
		return rst;
	}

	/**
	 * AML 洗錢風險 EB032168
	 * 
	 * @return
	 * @throws ActionException
	 */
	protected String sendEB032168(String idNo) {
		String rst = "";
		EAI<EB032168RQ, EB032168RS> eaiAdaptor = EAI.newInstance(EAIChannel.CBS, EB032168RQ.class, EB032168RS.class);
		EB032168SvcRqType rq = eaiAdaptor.getRequest().getBody();
		// eaiAdaptor.getRequest().getHeader().setHTLID("2004115");
		rq.setFUNC("0");
		rq.setFUNC01("0");
		rq.setCUSTNO(idNo);
		rq.setIDTYPE(B2CPibUserExtend.getIDTYPE(idNo));
		
		try {
			EB032168RS rs = eaiAdaptor.sendAndReceive(B2CUtils.getAccessLogKeyFromRequestScope(), "數位存款申請查詢洗錢資恐");
			EB032168SvcRsType rsBody = rs.getBody();
			if (StringUtils.isNotBlank(rsBody.getCCDFLG())) {
				rst = rsBody.getCCDFLG().trim();
			}
		} catch (Exception ex) {
			logger.error("數位存款申請發送EB032168電文查客戶資料失敗", ex);
		}
		return rst;
	}
}
