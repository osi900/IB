import { PageBaseComponent } from '@/components/PageBaseComponent';
import $ from 'jquery';
import { Component } from 'vue-property-decorator';
import 'jquery-ui-dist/jquery-ui';
import 'jquery-ui-dist/jquery-ui.min.css';
import axios from 'axios';

@Component({})
export default class FilterModal extends PageBaseComponent {
	
	tag: any;
	
	temp: any;
	
	/** 比較運算子 */
	op: string;
	
	/** 輸入數量 */
	quantity: string;
	
	selectAll: boolean;
	
	constructor() {
		super();
		this.tag = {};
		this.temp = {};
		this.op = '';
		this.quantity = '';
		this.selectAll = false;
	}
	
	show(tag: any) {
		$('.form-check-input').prop('checked', false);
		this.tag = {};
		this.selectAll = false;
		
		this.tag = tag;

		($(this.$el) as any).on('shown.bs.modal', () => {
			this.temp = {};
			this.op = '';
			this.quantity = '';
			if (this.tag) {
				if (this.tag.type == 'RANGE') {
					const colName = tag.options[0].colName;
					this.op = this.$store.state.conditions[colName][0].op;
					this.quantity = this.$store.state.conditions[colName][0].value;
					
				} else if (this.tag.type == 'TIME') {
					($ as any).datepicker.regional[ "zh-TW" ] = {
						closeText: "關閉",
						prevText: "上個月",
						nextText: "下個月",
						currentText: "今天",
						monthNames: [ "一月", "二月", "三月", "四月", "五月", "六月",
						"七月", "八月", "九月", "十月", "十一月", "十二月" ],
						monthNamesShort: [ "一月", "二月", "三月", "四月", "五月", "六月",
						"七月", "八月", "九月", "十月", "十一月", "十二月" ],
						dayNames: [ "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" ],
						dayNamesShort: [ "週日", "週一", "週二", "週三", "週四", "週五", "週六" ],
						dayNamesMin: [ "日", "一", "二", "三", "四", "五", "六" ],
						weekHeader: "週",
						dateFormat: "yy/mm/dd",
						firstDay: 1,
						isRTL: false,
						showMonthAfterYear: true,
						yearSuffix: "年" };
					
					if (this.$store.state.conditions[this.tag.nameEN]) {
						this.op = this.$store.state.conditions[this.tag.nameEN][0].op;
						$('#dateInput').val(this.$store.state.conditions[this.tag.nameEN][0].value);
						$('#dateInput2').val(this.$store.state.conditions[this.tag.nameEN][0].value2);
					} else {
						$('#dateInput').val('');
						$('#dateInput2').val('');
					}
					
					($('#dateInput') as any).datepicker(($ as any).datepicker.regional[ "zh-TW" ]);
					($('#dateInput2') as any).datepicker(($ as any).datepicker.regional[ "zh-TW" ]);
					
				} else {
					for (let i = 0; i < tag.options.length; i++) {
						const colName = tag.options[i].colName;
						const value = tag.options[i].value;
						const values = this.$store.state.conditions[colName];
						if (values && values.findIndex((val: any) => val.value == value) > -1) {
							$(`#${colName}_${i}`).prop('checked', true);
							this.addConditionToTemp(colName, value);
						}
						
						if (this.tag.type == 'MCHECKBOX') {
							if (tag.options[i].options) {
								for (let j = 0; j < tag.options[i].options.length; j++) {
									const colName2 = tag.options[i].options[j].colName;
									const value2 = tag.options[i].options[j].value;
									const values2 = this.$store.state.conditions[colName2];
									if (values2 && values2.findIndex((val: any) => val.value == value2) > -1) {
										$(`#${colName2}_${i}_${j}`).prop('checked', true);
										this.addConditionToTemp(colName2, value2);
									}
								}
							}
						}
					}
				}
				
			}
		});
		($(this.$el) as any).modal('show');
	}
	
	/**
	 * 全選 / 全部不選
	 */
	doSelectAll() {
		if (this.selectAll) {
			$('.lv1Check, .form-check-input').prop('checked', false);
			this.temp = {};
		} else {
			$('.lv1Check, .form-check-input').prop('checked', true);
			this.temp = {};
			const opts:[] = this.tag.options;
			
			if (this.tag.type == 'CHECKBOX') {
				// 一層選項
				opts.forEach(opt => {
					this.addConditionToTemp(opt['colName'], opt['value']);
				});
				
			} else if (this.tag.type == 'MCHECKBOX') {
				// 兩層選項
				opts.forEach(lv1 => {
					this.addConditionToTemp(lv1['colName'], lv1['value']);
					
					const lv2Opts: any = lv1['options'];
					lv2Opts.forEach((lv2: any) => {
						this.addConditionToTemp(lv2['colName'], lv2['value']);
					})
				});
				
			}
			
		}
	}
	
	/**
	 * 選擇第一層
	 */
	checkLv1Options(lv1opt: any, i: number) {
		if (!$('.lv1Check_'+i).prop('checked')) {
			if (lv1opt.options) {
				for (let j = 0; j < lv1opt.options.length; j++) {
					$(`.${lv1opt.colName}_${i}_${j}`).prop('checked', false);
					const lv2Opt = lv1opt.options[j];
					if (this.temp[lv2Opt['colName']]) {
						this.removeConditionFromTemp(lv2Opt['colName']);
					}
				}
			}
			
			if (this.temp[lv1opt['colName']]) {
				this.removeConditionFromTemp(lv1opt['colName']);
			}
			
		} else {
			if (lv1opt.options) {
				for (let j = 0; j < lv1opt.options.length; j++) {
					$(`.${lv1opt.colName}_${i}_${j}`).prop('checked', true);
					const lv2Opt = lv1opt.options[j];
					this.addConditionToTemp(lv2Opt['colName'], lv2Opt['value']);
				}
			}
			
			this.addConditionToTemp(lv1opt['colName'], lv1opt['value']);
		}
		
	}
	
	/**
	 * 選擇選項
	 */
	checkOptions(opt: any, i: number) {
		this.selectAll = false;
		const check = $('#'+opt.colName + '_' + i).prop('checked');
		if (this.tag.type == 'CHECKBOX') {
			if (check) {
				this.addConditionToTemp(opt.colName, opt.value);
			} else {
				this.removeConditionFromTemp(opt.colName, opt.value);
			}
			
		} else if (this.tag.type == 'MCHECKBOX') {
			if (check) {
				this.addConditionToTemp(opt.colName, opt.value);
			} else {
				this.removeConditionFromTemp(opt.colName, opt.value);
			}
		}
	}
	
	/**
	 * 確認選取
	 */
	confirm() {
		
		if (this.tag.type == 'RANGE') {
			// 數字
			const colName = this.tag.options[0].colName;
			this.replaceConditionInTemp(colName, this.quantity, this.op);
			this.$store.state.conditions[colName] = this.temp[colName];
			
		} else if (this.tag.type == 'TIME') {
			// 日期
			const colName = this.tag.nameEN;
			const dateVal: any = $('#dateInput').val();
			const dateVal2: any = $('#dateInput2').val();
			this.replaceConditionInTemp(colName, dateVal, this.op, dateVal2);
			this.$store.state.conditions[colName] = this.temp[colName];
			
		} else {
			// checkbox選項
			for (let i = 0; i < this.tag.options.length; i++) {
				const colName = this.tag.options[i]['colName'];
				if (!this.temp[colName] || this.temp[colName].length == 0) {
					delete this.$store.state.conditions[colName];
				} else {
					this.$store.state.conditions[colName] = this.temp[colName];
				}
				
				// lv2
				if (this.tag.options[i].options) {
					for (let j = 0; j < this.tag.options[i].options.length; j++) {
						const lv2ColName = this.tag.options[i].options[j]['colName'];
						if (!this.temp[lv2ColName] || this.temp[lv2ColName].length == 0) {
							delete this.$store.state.conditions[lv2ColName];
						} else {
							this.$store.state.conditions[lv2ColName] = this.temp[lv2ColName];
						}
					}
				}
			}
		}
		
		// 紀錄LOG
		const logMsg = {
			tagName: this.tag.name,
			srcCol: this.tag.nameEN
		};
		axios.post('/log/logTagUsage', logMsg)
		.then((rs: any) => {
				console.log('ok');
			})
			.catch((err) => {
				console.log(err);
			});
		
		this.$store.commit('refreshHomeInfo');
		($(this.$el) as any).modal('hide');
		
	}
	
	/**
	 * 暫存選項值
	 */
	private addConditionToTemp(colName: string, value: string) {
		if (!this.temp[colName]) {
			this.temp[colName] = [];
		}
		this.temp[colName].push({value: value});
	}
	
	/**
	 * 移除選項值
	 */
	private removeConditionFromTemp(colName: string, value?: string) {
		if (!this.temp[colName]) {
			return;
		}
		
		if (value) {
			const idx = this.temp[colName].findIndex((val: any) => val.value == value);
			this.temp[colName].splice(idx, 1);
			if (this.temp[colName].length == 0) {
				delete this.temp[colName];
			}
		} else {
			delete this.temp[colName];
		}
	}
	
	/**
	 * 設定標籤
	 */
	private replaceConditionInTemp(colName: string, value: string, op: string, value2?: string) {
		if (this.temp[colName]) {
			delete this.temp[colName];
		}
		this.temp[colName] = [];
		if (op == 'between') {
			this.temp[colName].push({value: value, value2: value2, op: op, type: this.tag.type});
		} else {
			this.temp[colName].push({value: value, op: op, type: this.tag.type});
		}
	}
}