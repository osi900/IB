import AccountOpenSourceChart from '@/charts/AccountOpenSourceChart.vue';
import AgeChart from '@/charts/AgeChart.vue';
import BranchChart from '@/charts/BranchChart.vue';
import ElectronicAcctAmtChart from '@/charts/ElectronicAcctAmtChart.vue';
import OverseasTradeVolChart from '@/charts/OverseasTradeVolChart.vue';
import ProdContributionChart from '@/charts/ProdContributionChart.vue';
import TaiexRealizedProfitLossChart from '@/charts/TaiexRealizedProfitLossChart.vue';
import TaiexTradeVolChart from '@/charts/TaiexTradeVolChart.vue';
import TaiexUnrealizedProfitLossChart from '@/charts/TaiexUnrealizedProfitLossChart.vue';
import Top10Chart from '@/charts/Top10Chart.vue';
import EffectiveSignAcctChart from '@/charts/EffectiveSignAcctChart.vue';
import axios from 'axios';
import Vue from 'vue';
import Vuex from 'vuex';


Vue.use(Vuex)

export default new Vuex.Store({
	state: {
		logedIn: false,
		token: '',
		username: '',
		snapDates: [],
		showLoading: false,
		/** 原始戶數 */
		total: 0,
		/** 篩選後戶數 */
		filteredCount: 0,
		/** 佔原始戶數 */
		percentage: '0',
		/** 所有標籤 */
		allTags: [],
		/** 標籤群組 */
		tagGroups: [],
		/** 查詢條件 */
		conditions: {
			/** 轉檔年月 */
			'snapYYYYMM': [{value: ''}],
		},
		chartClasses: [
			AgeChart, // 年齡層分布圖
			BranchChart, // 分公司分布	
			TaiexTradeVolChart, // 台股月均交易量
			OverseasTradeVolChart, // 海外股月均交易量
			ProdContributionChart, // 產品貢獻度分布
			TaiexRealizedProfitLossChart, // 客戶賺錢/賠錢-台股已實現損益
			TaiexUnrealizedProfitLossChart, // 客戶賺錢/賠錢-台股未實現損益
			ElectronicAcctAmtChart, // 電子戶數及金額自佔率
			AccountOpenSourceChart, // 開戶進件來源
			Top10Chart, // 台股交易類股TOP 10
			EffectiveSignAcctChart, // 各項業務有效簽署戶數
		],
		charts: [],
		chartModal: null,
		logoutModal: null,
		logoutCountdown: 10 * 60,
	},
	getters: {
	},
	mutations: {
		updateBasicInfo(state, basicInfoRs){
			state.username = basicInfoRs.rs.data.clientIp;
			state.total = basicInfoRs.rs.data.total; // 原始戶數
			
			state.snapDates = basicInfoRs.rs.data.snapDates;
			if (!state.conditions.snapYYYYMM[0].value) {
				state.conditions.snapYYYYMM[0].value = basicInfoRs.rs.data.snapDates[0];
			}
			
			state.tagGroups = basicInfoRs.rs.data.tagGroups;
		},
		/**
		 * 更新首頁訊息
		 */
		refreshHomeInfo(state) {
			state.showLoading = true;
			axios.post('/home/', {conditions: state.conditions})
				.then((rs: any) => {
					state.username = rs.data.clientIp;
					state.total = rs.data.total; // 原始戶數

					//if(hasFilter(state.conditions)){
						state.filteredCount = rs.data.filteredCount; // 篩選後戶數
						state.percentage = ((state.filteredCount / state.total) * 100).toFixed(2); // 佔原始戶數
					//}else{
						//state.filteredCount = 0;
						//state.percentage = '0';
					//}

					
					state.snapDates = rs.data.snapDates;
					if (!state.conditions.snapYYYYMM[0].value) {
						state.conditions.snapYYYYMM[0].value = rs.data.snapDates[0];
					}
					
					// 重畫圖表
					for (let i = 0; i < state.charts.length; i++) {
						(state.charts[i] as any).draw();
					}
					
					state.showLoading = false;
				})
				.catch((err) => {
					console.log(err);
					state.showLoading = false;
				});
			
		},
		
		/**
		 * 移除條件
		 */
		deleteFilter(state, val) {
			delete (state.conditions as any)[val.filterKey];
		},
		
		/**
		 * 顯示圖表Modal
		 */
		showChartModal(state, info) {
			if (state.chartModal) {
				(state.chartModal as any).show(info['title'], info);
			}
		},
		
		resetCountdown(state) {
			// 十分鐘
			state.logoutCountdown = 10 * 60;
		}
	},
	actions: {
		/**
		 * 移除條件
		 */
		deleteFilter({commit}, { filterKey }) {
			commit('deleteFilter', { filterKey });
			commit('refreshHomeInfo')
		}
	},
	modules: {
	}
})
export function hasFilter(conditions: any): boolean {
  const allConditionKeys = Object.keys(conditions);
  allConditionKeys.splice(
    allConditionKeys.findIndex((ack) => ack == "snapYYYYMM"),
    1
  );
  return allConditionKeys.length > 0;
}