import ChartTabs from "@/charts/ChartTabs.vue";
import { DataUtils } from "@/commons/DataUtils";
import * as echarts from "echarts";
import { Component } from "vue-property-decorator";

@Component({
  components: {
    ChartTabs,
  },
})
export default class TaiexRealizedProfitLossChart extends ChartTabs {
  chartSpan: number;

  title: string;

  chart: any;

  option: any;

  data: unknown[];
  /**
   * 建構子
   */
  constructor() {
    super();
    this.chartSpan = 2;
    this.title = "客戶賺錢/賠錢-台股已實現損益";
    this.chart = null;
    this.data = [];
  }

  /**
   * 顯示圖表modal
   */
  showModal() {
    this.$store.commit("showChartModal", {
      title: this.title,
      tabs: [
        { name: "圖", option: this.option },
        { name: "表", html: this.$refs.taiexRealizedProfitLossTable },
      ],
    });
  }

  /**
   * 開始繪圖
   */
  draw() {
    new DataUtils(this).getData("/taiex_realized_profitloss/", (data: any) => {
      if (data && data.data) {
        this.drawChart(data);

        const formatUtil = echarts.format;

        const subTotal = {
          scale: "小計",
          benefitAcct: 0,
          benefitPerCapita: 0,
          lossAcct: 0,
          lossPerCapita: 0,
        };
        for (const data_ of data.data) {
          subTotal["benefitAcct"] += data_["benefitAcct"] || 0;
          subTotal["benefitPerCapita"] +=
            data_["benefitAcct"] * (data_["benefitPerCapita"] || 0);
          subTotal["lossAcct"] += data_["lossAcct"] || 0;
          subTotal["lossPerCapita"] +=
            data_["lossAcct"] * (data_["lossPerCapita"] || 0);
        }
        subTotal["benefitPerCapita"] = parseFloat(
          (subTotal["benefitPerCapita"] / subTotal["benefitAcct"]).toFixed(0)
        );
        subTotal["lossPerCapita"] = parseFloat(
          (subTotal["lossPerCapita"] / subTotal["lossAcct"]).toFixed(0)
        );
        data.data.push(subTotal);

        for (const data_ of data.data) {
          data_["benefitAcct"] = formatUtil.addCommas(data_["benefitAcct"]);
          data_["benefitPerCapita"] = formatUtil.addCommas(
            data_["benefitPerCapita"]
          );
          data_["lossAcct"] = formatUtil.addCommas(data_["lossAcct"]);
          data_["lossPerCapita"] = !isNaN(data_["lossPerCapita"])
            ? `(${formatUtil.addCommas(Math.abs(data_["lossPerCapita"]))})`
            : "-";
        }

        this.data = data.data;
        window.addEventListener("resize", this.resizeTheChart);
      }
    });
  }


  drawChart(data: any) {
    // 戶數總和
    let benefitAcctTotal = 0;
    let lossAcctTotal = 0;
    let benefitAcctTotalTarget = 0;
    let lossAcctTotalTarget = 0;

    for (let i = data.data.length - 1; i >= 0; i--) {
      const data_ = data.data[i];
      benefitAcctTotal += data_["benefitAcct"] || 0;
      lossAcctTotal += data_["lossAcct"] || 0;
    }
    for (let i = data.target.length - 1; i >= 0; i--) {
      const data_ = data.target[i];
      benefitAcctTotalTarget += data_["benefitAcct"] || 0;
      lossAcctTotalTarget += data_["lossAcct"] || 0;
    }

    const yLabel: any[] = [];
    const benefitAcct: any[] = [];
    const benefitAcctRatio: any[] = [];
    const benefitPerCapita: any[] = [];
    const lossAcct: any[] = [];
    const lossAcctRatio: any[] = [];
    const lossPerCapita: any[] = [];

    const benefitAcctTarget: any[] = [];
    const benefitAcctRatioTarget: any[] = [];
    const benefitPerCapitaTarget: any[] = [];
    const lossAcctTarget: any[] = [];
    const lossAcctRatioTarget: any[] = [];
    const lossPerCapitaTarget: any[] = [];

    for (let i = data.data.length - 1; i >= 0; i--) {
      const data_ = data.data[i];
      yLabel.push(data_["scale"]);
      benefitPerCapita.push(data_["benefitPerCapita"] || 0);
      lossPerCapita.push(data_["lossPerCapita"] || 0);

      const temp = data_["benefitAcct"] || 0;
      benefitAcct.push(temp);
      if (benefitAcctTotal) {
        benefitAcctRatio.push(temp / benefitAcctTotal);
      } else {
        benefitAcctRatio.push(0);
      }

      const temp2 = data_["lossAcct"] || 0;
      lossAcct.push(temp2);
      if (lossAcctTotal) {
        lossAcctRatio.push(-temp2 / lossAcctTotal);
      } else {
        lossAcctRatio.push(0);
      }
    }

    for (let i = data.target.length - 1; i >= 0; i--) {
      const data_ = data.target[i];

      const temp = data_["benefitAcct"] || 0;
      benefitAcctTarget.push(temp);

      if (benefitAcctTotalTarget) {
        benefitAcctRatioTarget.push(temp / benefitAcctTotalTarget);
      } else {
        benefitAcctRatioTarget.push(0);
      }

      const temp2 = data_["lossAcct"] || 0;
      lossAcctTarget.push(temp2);
      if (lossAcctTotalTarget) {
        lossAcctRatioTarget.push(-temp2 / lossAcctTotalTarget);
      } else {
        lossAcctRatioTarget.push(0);
      }

      benefitPerCapitaTarget.push(data_["benefitPerCapita"] || 0);
      lossPerCapitaTarget.push(data_["lossPerCapita"] || 0);
    }

    if (!this.chart) {
      const el = this.$refs.taiexRealizedProfitLossChart as HTMLElement;
      this.chart = echarts.init(el);
    }

    const labelOption = {
      show: true,
      position: "right",
      formatter: function (params: any) {
        let res = "";
        if (0 == params.value) {
          res = "";
        } else {
          const p = Math.abs(params.value) * 100;
          res = `${p.toFixed(2)}%`;
        }
        return res;
      },
    };

    const labelOptionLeft = {
      ...labelOption,
      position: "left",
    };

    const legendData = ["全體"];

    const _series = [{
      name: "全體",
      stack: "Total",
      type: "bar",
      label: labelOption,
      emphasis: {
        focus: "series",
      },
      data: benefitAcctRatio,
    },
    {
      name: "全體",
      stack: "Total",
      type: "bar",
      label: labelOptionLeft,
      emphasis: {
        focus: "series",
      },
      data: lossAcctRatio,
    }];

    if (this.hasFilter()) {
      legendData.push("受眾");
      _series.push({
        name: "受眾",
        stack: "target",
        type: "bar",
        label: labelOption,
        emphasis: {
          focus: "series",
        },
        data: benefitAcctRatioTarget,
      });
      _series.push({
        name: "受眾",
        stack: "target",
        type: "bar",
        label: labelOptionLeft,
        emphasis: {
          focus: "series",
        },
        data: lossAcctRatioTarget,
      });
    }

    this.option = {
      title: {
        text: "客戶賠錢                                                                    客戶賺錢",
        left: "center",
        top: "2%",
        textStyle: {
          color: '#888888',
          fontSize: 16
        }
      },
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "shadow",
        },
        formatter: function (params: any) {
          const formatUtil = echarts.format;

          let res = "";
          for (let i = 0; i < params.length; i++) {
            const dataIdx = yLabel.findIndex(
              (l: any) => l == params[i].axisValue
            );

            let bAcct = "";
            let bCapita = "";
            if (i == 0) {
              bAcct = benefitAcct[dataIdx];
              bCapita = benefitPerCapita[dataIdx];
            } else if (i == 1) {
              bAcct = lossAcct[dataIdx];
              bCapita = lossPerCapita[dataIdx];
            } else if (i == 2) {
              bAcct = benefitAcctTarget[dataIdx];
              bCapita = benefitPerCapitaTarget[dataIdx];
            } else if (i == 3) {
              bAcct = lossAcctTarget[dataIdx];
              bCapita = lossPerCapitaTarget[dataIdx];
            }

            res += `<div style="color: #000;font-size: 10px; padding:0 6px;line-height: 20px">`;

            if (params[i].seriesName == "全體") {
              if (res.indexOf("全體") == -1) {
                res += `<span class="tooltip_icon_base"></span>全體(${params[i].axisValue})<br>`;
              }
              if (res.indexOf("戶數") == -1) {
                res += `戶數: ${formatUtil.addCommas(bAcct)}戶<br>`;
              }
            }

            if (params[i].seriesName == "受眾") {
              if (res.indexOf("受眾") == -1) {
                res += `<span class="tooltip_icon_target"></span>受眾(${params[i].axisValue})<br>`;
              }
              if (res.indexOf("戶數") == -1) {
                res += `戶數: ${formatUtil.addCommas(bAcct)}戶<br>`;
              }
            }

            res +=
              (params[i].data <= 0 ? "戶均賠錢" : "戶均獲利") +
              ": " +
              formatUtil.addCommas(bCapita) +
              "(新台幣/元)";
            res += `</div>`;
          }
          return res;
        },
      },
      legend: {
        data: legendData,
      },
      grid: {
        left: 0,
        right: "3%",
        bottom: 0,
        containLabel: true,
      },
      xAxis: [
        {
          type: "value",
          axisTick: {
            show: true,
          },
          show: true,
          axisLabel: {
            formatter: function (val: any) {
              const p = Math.abs(val) * 100;
              return `${p}%`;
            },
          },
        },
      ],
      yAxis: [
        {
          type: "category",
          axisTick: {
            show: false,
          },
          data: yLabel,
          name: "交易戶數占比(%)",
        },
        {
          type: "category",
          axisTick: {
            show: false,
          },
          data: yLabel,
        },
      ],
      series: _series
    };
    this.chart.setOption(this.option, true);
  }

  resizeTheChart() {
    if (this.chart) {
      this.chart.resize();
    }
  }

  hasFilter(): boolean {
    const conditions = this.$store.state.conditions;
    const allConditionKeys = Object.keys(conditions);

    allConditionKeys.splice(
      allConditionKeys.findIndex((ack) => ack == "snapYYYYMM"),
      1
    );
    console.info("allConditionKeys: ", allConditionKeys);
    return allConditionKeys.length > 0;
  }

  /**
   * 匯出Excel
   */
  exportExcel() {
    new DataUtils(this).download(
      "/taiex_realized_profitloss/exportExcel",
      this.data,
      this.title + ".xlsx"
    );
  }
}
