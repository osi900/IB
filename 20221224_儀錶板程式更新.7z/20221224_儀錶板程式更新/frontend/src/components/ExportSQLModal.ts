import { PageBaseComponent } from '@/components/PageBaseComponent';
import $ from 'jquery';
import { Component } from 'vue-property-decorator';

@Component({})
export default class ExportSQLModal extends PageBaseComponent {
  sql: string;

  constructor() {
    super();
    this.sql = "";
  }

  show() {
    const whereConditions = [];
    const keys = Object.keys(this.$store.state.conditions);
    for (let i = 0; i < keys.length; i++) {
      

      const filters = this.$store.state.conditions[keys[i]];
      const oneKey = [];
      for (let j = 0; j < filters.length; j++) {
        const filter = filters[j];
        if (filter.op) {
          if (filter.type == "TIME") {
            if (filter.op == "between") {
              oneKey.push(
                `${keys[i]} BETWEEN TO_DATE('${filter.value}', 'YYYY/MM/DD') AND TO_DATE('${filter.value2}', 'YYYY/MM/DD')`
              );
            } else {
              oneKey.push(
                `${keys[i]} ${filter.op} TO_DATE('${filter.value}', 'YYYY/MM/DD')`
              );
            }
          } else {
            oneKey.push(`${keys[i]} ${filter.op} ${filter.value}`);
          }
        } else {
          oneKey.push(`${keys[i]} = '${this.convertYNValue(filter.value)}'`);
        }
      }
      whereConditions.push(` ( ${oneKey.join(" or ")} ) `);
    }

    this.sql =
      "SELECT ACCT_NBR, PARTY_ID FROM DM_S_VIEW.T_DR_ACCT ";
    if (whereConditions.length > 0) {
      this.sql += ' WHERE ' + whereConditions.join(" and ")
    }
    ($(this.$el) as any).modal("show");
  }

  convertYNValue(value: string): string {
	if( '是' == value ) return 'Y';
	if( '否' == value ) return 'N';

	return value;
  }

  copySQL() {
    navigator.clipboard
      .writeText(this.sql)
      .then(() => {
        alert("複製成功");
      })
      .catch((reject) => {
		//reject reason
      });
  }
}