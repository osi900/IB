package tw.com.fubon.dashboard.api.home;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.dao.bean.Options;
import tw.com.fubon.dashboard.dao.bean.TagGroupVals;
import tw.com.fubon.dashboard.dao.bean.TagGroups;
import tw.com.fubon.dashboard.dao.bean.Tags;
import tw.com.fubon.dashboard.service.DashboardService;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.StringUtil;
import tw.com.fubon.dashboard.vo.Filter;
import tw.com.fubon.dashboard.vo.OptionData;
import tw.com.fubon.dashboard.vo.TagData;

@RestController
@RequestMapping(path = "/home")
public class HomeController extends ControllerBase {
	
	@Autowired
	private DmsService dao;
	
	@Autowired
	private DashboardService dashboardDao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public HomeResponse getInitInfo(@RequestBody HomeRequest rq) {
		HomeResponse rs = new HomeResponse();
		rs.setClientIp(getClientIp());
		rs.setSnapDates(dao.getSnapDateList());
		
		String snapMonth = rq.getSnapDate();
		String snapYYYYMM = rs.getSnapDates().get(0);
		if (StringUtils.isNotBlank(snapMonth)) {
			snapYYYYMM = snapMonth;
		}
		
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		// 原始戶數
		rs.setTotal(dao.getTotalCount(snapYYYYMM));
		
		// 篩選後戶數
		rs.setFilteredCount(dao.getFilteredCount(snapYYYYMM, whereCondition));
		
		return rs;
	}
	
	@PostMapping(path = "/basic",  produces = MediaType.APPLICATION_JSON_VALUE)
    public HomeResponse getBasicInfo(@RequestBody HomeRequest rq) {
        HomeResponse rs = new HomeResponse();
        rs.setClientIp(getClientIp());
        rs.setSnapDates(dao.getSnapDateList());
        
        // 原始戶數
        String snapYYYYMM = rs.getSnapDates().get(0);
     	rs.setTotal(dao.getTotalCount(snapYYYYMM));
        
     	// 標籤群組
     	List<TagGroups> groups = dashboardDao.getTagGroups(getLoginUser().getUserAccount());
     	List<Map<String, String>> resultGroups = new ArrayList<>();
     	for (TagGroups g : groups) {
     		Map<String, String> map = new HashMap<>();
     		map.put("id", g.getGroupId().toString());
     		map.put("name", g.getGroupName());
     		resultGroups.add(map);
     	}
     	rs.setTagGroups(resultGroups);
     	rs.setUploaded(StringUtils.isNotBlank(getLoginUser().getJoinAccts()));
     	
        return rs;
    }
	
	/**
	 * 儲存為標籤群組
	 * @param rq
	 * @return
	 */
	@PostMapping(path = "/saveAsTagGroup",  produces = MediaType.APPLICATION_JSON_VALUE)
	public HomeResponse saveAsTagGroup(@RequestBody HomeRequest rq) {
		
		TagGroups group = new TagGroups();
		group.setGroupName(rq.getGroupName());
		group.setUserAcct(getLoginUser().getUserAccount());
		
		List<TagGroupVals> vals = new ArrayList<>();
		for (String key : rq.getTags().keySet()) {
			List<Filter> filters = rq.getTags().get(key);
			for (Filter filter : filters) {
				TagGroupVals v = new TagGroupVals();
				v.setTagName(key);
				v.setOptType(filter.getType());
				v.setTagOp(filter.getOp());
				v.setTagVal(filter.getValue());
				v.setTagVal2(filter.getValue2());
				vals.add(v);
			}
		}
		
		dashboardDao.saveTagGroup(group, vals);
		
		return new HomeResponse();
	}
	
	/**
	 * 取得標籤群組
	 * @return
	 */
	@PostMapping(path = "/getTagGroups",  produces = MediaType.APPLICATION_JSON_VALUE)
	public HomeResponse getTagGroups() {
		// 標籤群組
     	List<TagGroups> groups = dashboardDao.getTagGroups(getLoginUser().getUserAccount());
     	List<Map<String, String>> resultGroups = new ArrayList<>();
     	for (TagGroups g : groups) {
     		Map<String, String> map = new HashMap<>();
     		map.put("id", g.getGroupId().toString());
     		map.put("name", g.getGroupName());
     		resultGroups.add(map);
     	}
     	
     	HomeResponse rs = new HomeResponse();
     	rs.setTagGroups(resultGroups);
     	return rs;
	}
	
	/**
	 * 設定標籤群組
	 * @param groupId
	 */
	@PostMapping(path = "/getTagGroup",  produces = MediaType.APPLICATION_JSON_VALUE)
	public HomeResponse getTagGroup(@RequestBody HomeRequest rq) {
		List<TagGroupVals> vals = dashboardDao.getTagGroupVals(rq.getGroupId());
		Map<String, List<TagGroupVals>> grouped = vals.stream().collect(Collectors.groupingBy(TagGroupVals::getTagName));
		Map<String, List<Filter>> result = new LinkedHashMap<>();
		for (String name : grouped.keySet()) {
			List<Filter> valList = new ArrayList<>();
			for (TagGroupVals val : grouped.get(name)) {
				Filter filter = new Filter();
				filter.setOp(val.getTagOp());
				filter.setType(val.getOptType());
				filter.setValue(val.getTagVal());
				filter.setValue2(val.getTagVal2());
				valList.add(filter);
			}
			result.put(name, valList);
		}
		
		HomeResponse rs = new HomeResponse();
		rs.setFilters(result);
		return rs;
	}
	
	/**
	 * 取得所有標籤
	 * @return
	 */
	@PostMapping(path = "/getAllTags",  produces = MediaType.APPLICATION_JSON_VALUE)
	public HomeResponse getAllTags() {
		List<TagData> allTags = new ArrayList<>();
		
		// 第一層
		List<Tags> lv1 = dashboardDao.getLv1Tags();
		for (Tags lv1Tag : lv1) {
			TagData tmp1 = new TagData();
			tmp1.setId(lv1Tag.getTagId().toString());
			tmp1.setName(lv1Tag.getName());
			tmp1.setIcon(lv1Tag.getIcon());
			tmp1.setChildren(new ArrayList<>());
			allTags.add(tmp1);
			
			// 第二層
			List<Tags> lv2 = dashboardDao.getTagsByParentId(lv1Tag.getTagId());
			for (Tags lv2Tag : lv2) {
				TagData tmp2 = new TagData();
				tmp2.setId(lv2Tag.getTagId().toString());
				tmp2.setName(lv2Tag.getName());
				tmp2.setChildren(new ArrayList<>());
				tmp1.getChildren().add(tmp2);
				
				// 第三層
				List<Tags> lv3 = dashboardDao.getTagsByParentId(lv2Tag.getTagId());
				for (Tags lv3Tag : lv3) {
					TagData tmp3 = new TagData();
					tmp3.setId(lv3Tag.getTagId().toString());
					tmp3.setType(lv3Tag.getOptType());
					tmp3.setName(lv3Tag.getName());
					tmp3.setNameEN(lv3Tag.getSrcCol());
					tmp3.setNameCH(lv3Tag.getName());
					tmp3.setDesc(lv3Tag.getMemo());
					tmp3.setOptions(new ArrayList<>());
					tmp2.getChildren().add(tmp3);
					
					if ("CHECKBOX".equals(tmp3.getType()) || "RANGE".equals(tmp3.getType())) {
						List<Options> opts = dashboardDao.getOptionsByTagId(lv3Tag.getTagId(), null);
						for (Options opt : opts) {
							OptionData tmpo = new OptionData();
							tmpo.setLabel(opt.getLabel());
							tmpo.setValue(opt.getOptValue());
							tmpo.setColName(lv3Tag.getSrcCol());
							tmp3.getOptions().add(tmpo);
						}
						
					} else if ("MCHECKBOX".equals(tmp3.getType())) {
						List<Options> opts = dashboardDao.getOptionsByTagId(lv3Tag.getTagId(), null);
						for (Options opt : opts) {
							OptionData tmpo = new OptionData();
							tmpo.setLabel(opt.getLabel());
							tmpo.setValue(opt.getOptValue());
							tmpo.setName(opt.getName());
							tmpo.setColName(opt.getSrcCol());
							tmpo.setOptions(new ArrayList<>());
							tmp3.getOptions().add(tmpo);
							
							List<Options> subOpts = dashboardDao.getOptionsByTagId(lv3Tag.getTagId(), opt.getOptId());
							for (Options subOpt : subOpts) {
								OptionData tmpso = new OptionData();
								tmpso.setLabel(subOpt.getLabel());
								tmpso.setValue(subOpt.getOptValue());
								tmpso.setName(subOpt.getName());
								tmpso.setColName(subOpt.getSrcCol());
								tmpo.getOptions().add(tmpso);
							}
						}
						
					}
				}
			}
			
		}
		
		HomeResponse rs = new HomeResponse();
		rs.setAllTags(allTags);
		return rs;
	}
}
