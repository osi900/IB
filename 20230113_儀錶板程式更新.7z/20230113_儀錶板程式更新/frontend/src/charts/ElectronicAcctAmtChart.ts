import ChartTabs from "@/charts/ChartTabs.vue";
import { DataUtils } from "@/commons/DataUtils";
import * as echarts from "echarts";
import $ from "jquery";
import { Component } from "vue-property-decorator";

@Component({
	components: {
		ChartTabs,
	},
})
export default class ElectronicAcctAmtChart extends ChartTabs {
	chartSpan: number;

	title: string;

	chartAcctAmt: any;
	chartAmt: any;
	chartAcct: any;

	optionAcctAmt: any;
	optionAmt: any;
	optionAcct: any;

	data: unknown[];

	/**
	 * 建構子
	 */
	constructor() {
		super();
		this.chartSpan = 2;
		this.title = "電子戶數及金額自佔率";
		//this.chart = null;
		this.data = [];
	}

	/**
	 * 顯示圖表modal
	 */
	showModal() {
		this.$store.commit("showChartModal", {
			title: this.title,
			tabs: [
				{ name: "年累佔比", option: this.optionAcctAmt },
				{ name: "年累金額", option: this.optionAmt },
				{ name: "年累戶數", option: this.optionAcct },
			],
		});
	}

	/**
	 * 開始繪圖
	 */
	draw() {
		//console.log($(this.$el))
		$(this.$el)
			.find('a[data-toggle="tab"]')
			.on("shown.bs.tab", (event) => {
				//event.target // newly activated tab
				const currentTabId = $(event.target).attr("id");
				console.log(`currentTabId: ${currentTabId}`);
				if (currentTabId == "elecAcctAmtTab2-tab") {
					$('#elecAcctAmtTab2').show();
					this.drawAmt(this.data);
				} else if (currentTabId == "elecAcctAmtTab3-tab") {
					$('#elecAcctAmtTab2').hide();
					this.drawAcct(this.data);
				}
				
				//event.relatedTarget // previous active tab
			});
		new DataUtils(this).getData("/electronic_acct_amt/", (data: any) => {
			//console.log(data);
			if (data && data.data) {
				this.data = data.data;
				//console.log(data);
				this.createAcctAmt(data.data);
				this.drawAcctAmt(data.data);
				this.createAmt(data.data);
				this.createAcct(data.data);
				window.addEventListener('resize', this.resizeTheChart);
			}
		});
	}

	/** 年累戶數 */
	createAcct(data: any) {
		if (!data) return false;

		const xLabel = [];
		const electronicAccounts: number[] = [];
		const artificialAccounts: number[] = [];
		let maxY = 0;
		//const yValue = [];
		for (let i = 0; i < data.length; i++) {
			const label = data[i]["product"];
			const electronicAccount = data[i]["electronicAccount"];
			const artificialAccount = data[i]["artificialAccount"];
			xLabel.push(label);
			electronicAccounts.push(electronicAccount);
			artificialAccounts.push(artificialAccount);
		}

		maxY = Math.max(...electronicAccounts.concat(artificialAccounts));

		if (!this.chartAcct) {
			const el = this.$refs.elecAcctChart as HTMLElement;
			this.chartAcct = echarts.init(el);
		}

		this.optionAcct = {
			title: {},
			tooltip: {
				trigger: "axis",
			},
			legend: {
				data: ["電子戶數", "人工戶數"],
			},
			xAxis: {
				type: "category",
				data: xLabel,
			},
			yAxis: {
				type: "value",
				min: 0,
				max: maxY,
			},
			series: [
				{
					name: "電子戶數",
					data: electronicAccounts,
					type: "bar",
					label: {
						show: true,
						position: "top"
					},
					itemStyle: {
						color: "#5470c6",
					},
				},
				{
					name: "人工戶數",
					data: artificialAccounts,
					type: "bar",
					label: {
						show: true,
						position: "top"

					},
					itemStyle: {
						color: "#91cc74",
					},
				},
			],
		};
	}

	drawAcct(data: any) {
		if (!data) return false;
		this.chartAcct.setOption(this.optionAcct);
	}

	/** 年累金額 */
	createAmt(data: any) {
		if (!data) return false;

		const xLabel = [];
		const electronicAmounts: number[] = [];
		const artificialAmounts: number[] = [];
		let maxY = 0;
		//const yValue = [];
		for (let i = 0; i < data.length; i++) {
			const label = data[i]["product"];
			const electronicAmount = data[i]["electronicAmount"];
			const artificialAmount = data[i]["artificialAmount"];
			xLabel.push(label);
			electronicAmounts.push(electronicAmount);
			artificialAmounts.push(artificialAmount);
		}

		maxY = Math.max(...electronicAmounts.concat(artificialAmounts));

		if (!this.chartAmt) {
			const el = this.$refs.elecAmtChart as HTMLElement;
			this.chartAmt = echarts.init(el);
		}

		const labelOption = {
			show: true,
			position: "top",
			formatter: function(params: any) {
				let res = "";

				//console.log('params.value: ', params.value);
				if (null == params.value) {
					res = "0.00";
				} else {
					res = (params.value).toFixed(2);
				}
				//console.log('res: ', res);
				return res;
			},
		};

		this.optionAmt = {
			title: {},
			tooltip: {
				trigger: "axis",
				axisPointer: {
					type: "shadow",
				},
				valueFormatter: function(value: number) {
					//console.log("value: ", value);
					let res = "";
					if (null == value) {
						res = "0.00";
					} else {
						res = value.toFixed(2);
					}
					return res;
				},
			},
			legend: {
				data: ["電子金額", "人工金額"],
			},
			xAxis: {
				type: "category",
				data: xLabel,
			},
			yAxis: {
				type: "value",
				min: 0,
				max: maxY,
				name: '百萬',
				nameTextStyle: {
					align: 'right'
				}
			},
			series: [
				{
					name: "電子金額",
					data: electronicAmounts,
					type: "bar",
					label: labelOption,
					itemStyle: {
						color: "#5470c6",
					},
				},
				{
					name: "人工金額",
					data: artificialAmounts,
					type: "bar",
					label: labelOption,
					itemStyle: {
						color: "#91cc74",
					},
				},
			],
		};
	}

	/** 年累金額 */
	drawAmt(data: any) {
		if (!data) return false;
		this.chartAmt.setOption(this.optionAmt);
	}

	createAcctAmt(data: any) {
		if (!data) return false;

		const xLabel = [];
		const elecAcctProportions: number[] = [];
		const artiAcctProportions: number[] = [];
		const elecAmountProportions = [];
		const artiAmountProportions: number[] = [];
		//const yValue = [];
		for (let i = 0; i < data.length; i++) {
			const label = data[i]["product"];
			const elecAcctProportion = data[i]["elecAcctProportion"];
			const artiAcctProportion = data[i]["artiAcctProportion"];
			const elecAmountProportion = data[i]["elecAmountProportion"];
			const artiAmountProportion = data[i]["artiAmountProportion"];
			xLabel.push(label);
			elecAcctProportions.push(elecAcctProportion);
			artiAcctProportions.push(artiAcctProportion);
			elecAmountProportions.push(elecAmountProportion);
			artiAmountProportions.push(artiAmountProportion);
		}

		const labelOption = {
			show: true,
			formatter: function(params: any) {
				let res = "";
				if (null == params.value) {
					res = "0.00%";
				} else {
					//console.log('params.value: ', params.value);
					let p = params.value.toFixed(2);
					if (p.length >= 5) {
						p = p.substring(0, 5);
					}
					res = `${p}%`;
				}

				return res;
			},
		};

		this.optionAcctAmt = {
			title: {},
			tooltip: {
				trigger: "axis",
				axisPointer: {
					type: "shadow",
				},
				valueFormatter: function(value: number) {
					//console.log("value: ", value);
					let p = !value ? '0.00' : value.toFixed(2);
					if (p.length >= 5) {
						p = p.substring(0, 5);
					}
					let res = "";
					res = null == value ? "0%" : `${p}%`;
					return res;
				},
			},
			legend: {},
			grid: {
				left: "3%",
				right: "4%",
				bottom: "3%",
				containLabel: true,
			},
			xAxis: {
				type: "category",
				data: xLabel,
			},
			yAxis: [
				{
					type: "value",
				},
			],
			series: [
				{
					name: "電子戶佔比",
					type: "bar",
					stack: "Account",
					label: labelOption,
					emphasis: {
						focus: "series",
					},
					itemStyle: {
						color: "#5470c6",
					},
					data: elecAcctProportions,
				},
				{
					name: "人工戶佔比",
					type: "bar",
					stack: "Account",
					label: labelOption,
					emphasis: {
						focus: "series",
					},
					itemStyle: {
						color: "#d8def3",
					},
					data: artiAcctProportions,
				},
				{
					name: "電子戶金額佔比",
					type: "bar",
					stack: "Amount",
					label: labelOption,
					emphasis: {
						focus: "series",
					},
					itemStyle: {
						color: "#059d9b",
					},
					data: elecAmountProportions,
				},
				{
					name: "人工戶金額佔比",
					type: "bar",
					stack: "Amount",
					label: labelOption,
					emphasis: {
						focus: "series",
					},
					itemStyle: {
						color: "#cbfdfd",
					},
					data: artiAmountProportions,
				},
			],
		};
	}

	drawAcctAmt(data: any) {
		if (!data) return false;

		if (!this.chartAcctAmt) {
			const el = this.$refs.elecAcctAmtChart as HTMLElement;
			this.chartAcctAmt = echarts.init(el);
		}

		this.chartAcctAmt.setOption(this.optionAcctAmt);
	}

	resizeTheChart() {
		if (this.chartAcctAmt) {
			this.chartAcctAmt.resize()
		}
		if (this.chartAmt) {
			this.chartAmt.resize()
		}
		if (this.chartAcct) {
			this.chartAcct.resize()
		}
	}
}
