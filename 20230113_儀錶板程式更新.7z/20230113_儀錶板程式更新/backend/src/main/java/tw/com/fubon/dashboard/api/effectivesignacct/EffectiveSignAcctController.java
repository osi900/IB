package tw.com.fubon.dashboard.api.effectivesignacct;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.ExcelGenerator;
import tw.com.fubon.dashboard.utils.StringUtil;

@RestController
@RequestMapping(path = "/effectiveSignAcct")
public class EffectiveSignAcctController extends ControllerBase {

	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public EffectiveSignAcctResponse getData(@RequestBody EffectiveSignAcctRequest rq) {
		String snapMonth = rq.getSnapDate();
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		
		EffectiveSignAcctResponse rs = new EffectiveSignAcctResponse();
		rs.setData(dao.getEffectiveSignAcctData(snapMonth, whereCondition));
		
		if (rq.getConditions().size() == 1 && StringUtils.isBlank(getLoginUser().getJoinAccts())) {
			// 清除受眾
			EffectiveSignAcctData target = new EffectiveSignAcctData();
			target.setGroupName("受眾");
			rs.getData().set(0, target);
		}
		
		return rs;
	}
	
	/**
	 * 匯出Excel
	 * @param data
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/exportExcel", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Resource> exportExcel(@RequestBody List<Map<String, String>> data) throws Exception {
		
		return ExcelGenerator.generate((workbook) -> {
			Sheet sheet = workbook.createSheet();
			
			Row headRow = sheet.createRow(0);
			headRow.setHeight((short) 700);
			headRow.createCell(0).setCellValue("分群");
			headRow.createCell(1).setCellValue("已有\n電子戶");
			headRow.createCell(2).setCellValue("已有\n現股當沖簽屬");
			headRow.createCell(3).setCellValue("已有\n出借簽署");
			headRow.createCell(4).setCellValue("已有\n不限用途簽屬");
			headRow.createCell(5).setCellValue("已有\n定期定額簽屬");
			headRow.createCell(6).setCellValue("已有\n複委託帳戶");
			headRow.createCell(7).setCellValue("已有\n期貨IB");
			headRow.createCell(8).setCellValue("已有\n信用戶註記");
			headRow.createCell(9).setCellValue("已有\n財管信託帳戶");
			
			CellStyle cs = workbook.createCellStyle();
			cs.setWrapText(true);
			headRow.getCell(1).setCellStyle(cs);
			headRow.getCell(2).setCellStyle(cs);
			headRow.getCell(3).setCellStyle(cs);
			headRow.getCell(4).setCellStyle(cs);
			headRow.getCell(5).setCellStyle(cs);
			headRow.getCell(6).setCellStyle(cs);
			headRow.getCell(7).setCellStyle(cs);
			headRow.getCell(8).setCellStyle(cs);
			headRow.getCell(9).setCellStyle(cs);
			
			DecimalFormat numFormat = new DecimalFormat("#,##0");
			for (int i = 0; i < data.size(); i++) {
				Map<String, String> rcd = data.get(i);
				
				double ecAcct = Double.parseDouble(rcd.get("ecAcct"));
				double dtSign = Double.parseDouble(rcd.get("dtSign"));
				double bsblSign = Double.parseDouble(rcd.get("bsblSign"));
				double urulSign = Double.parseDouble(rcd.get("urulSign"));
				double dcSign = Double.parseDouble(rcd.get("dcSign"));
				double sbkAcct = Double.parseDouble(rcd.get("sbkAcct"));
				double futIbAcc = Double.parseDouble(rcd.get("futIbAcc"));
				double cdAcct = Double.parseDouble(rcd.get("cdAcct"));
				double wtFund = Double.parseDouble(rcd.get("wtFund"));
				
				Row rcdRow = sheet.createRow(i + 1);
				rcdRow.createCell(0).setCellValue(rcd.get("groupName"));
				if (i < data.size() - 1) {
					rcdRow.createCell(1).setCellValue(numFormat.format(ecAcct));
					rcdRow.createCell(2).setCellValue(numFormat.format(dtSign));
					rcdRow.createCell(3).setCellValue(numFormat.format(bsblSign));
					rcdRow.createCell(4).setCellValue(numFormat.format(urulSign));
					rcdRow.createCell(5).setCellValue(numFormat.format(dcSign));
					rcdRow.createCell(6).setCellValue(numFormat.format(sbkAcct));
					rcdRow.createCell(7).setCellValue(numFormat.format(futIbAcc));
					rcdRow.createCell(8).setCellValue(numFormat.format(cdAcct));
					rcdRow.createCell(9).setCellValue(numFormat.format(wtFund));
				} else {
					rcdRow.createCell(1).setCellValue(formatRatio(ecAcct));
					rcdRow.createCell(2).setCellValue(formatRatio(dtSign));
					rcdRow.createCell(3).setCellValue(formatRatio(bsblSign));
					rcdRow.createCell(4).setCellValue(formatRatio(urulSign));
					rcdRow.createCell(5).setCellValue(formatRatio(dcSign));
					rcdRow.createCell(6).setCellValue(formatRatio(sbkAcct));
					rcdRow.createCell(7).setCellValue(formatRatio(futIbAcc));
					rcdRow.createCell(8).setCellValue(formatRatio(cdAcct));
					rcdRow.createCell(9).setCellValue(formatRatio(wtFund));
				}
				
				
			}
			
		});
		
	}
	
	private String formatRatio(double num) {
		DecimalFormat f = new DecimalFormat("0.00");
		return f.format(num * 100) + "%";
	}
}
