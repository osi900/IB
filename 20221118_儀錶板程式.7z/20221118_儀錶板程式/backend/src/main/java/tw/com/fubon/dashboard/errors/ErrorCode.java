package tw.com.fubon.dashboard.errors;

import tw.com.fubon.dashboard.api.ResponseBase;

public enum ErrorCode {

	OK("0000", "成功"),
	
	LOGIN_FAIL("1000", "登入失敗"),
	
	NOT_LOGIN("9990", "尚未登入"),
	FILE_ACCT_NUM_ERROR("9992", "上傳帳號筆數錯誤"),
	NOT_AUTH("9993", "無權限"),
	VALIDATE_FAILED("9994", "欄位檢核失敗"),
	UNKNOWN_ERROR("9999", "未知錯誤");;
	
	private String code;
	
	private String message;
	
	ErrorCode(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public ResponseBase createResponse() {
		ResponseBase rs = new ResponseBase();
		rs.setCode(this.code);
		rs.setMessage(this.message);
		return rs;
	}
}
