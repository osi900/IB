package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.fubon.dashboard.dao.bean.TagGroups;
import tw.com.fubon.dashboard.dao.bean.TagGroupsExample;

public interface TagGroupsMapper {
    long countByExample(TagGroupsExample example);

    int deleteByExample(TagGroupsExample example);

    int deleteByPrimaryKey(Integer groupId);

    int insert(TagGroups record);

    int insertSelective(TagGroups record);

    List<TagGroups> selectByExample(TagGroupsExample example);

    TagGroups selectByPrimaryKey(Integer groupId);

    int updateByExampleSelective(@Param("record") TagGroups record, @Param("example") TagGroupsExample example);

    int updateByExample(@Param("record") TagGroups record, @Param("example") TagGroupsExample example);

    int updateByPrimaryKeySelective(TagGroups record);

    int updateByPrimaryKey(TagGroups record);
}