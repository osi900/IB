package tw.com.fubon.dashboard.api.taiextradevol;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.ExcelGenerator;
import tw.com.fubon.dashboard.utils.StringUtil;

/**
 * 台股月均交易量
 */
@RestController
@RequestMapping(path = "/taiexTradeVolme")
public class TaiexTradeVolumeController extends ControllerBase {

	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public TaiexTradeVolumeResponse getData(@RequestBody TaiexTradeVolumeRequest rq) {
	    String snapMonth = rq.getSnapDate();
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		
		logger.info("snapMonth: {}, whereCondition: {}", snapMonth, whereCondition);
		
		TaiexTradeVolumeResponse rs = new TaiexTradeVolumeResponse();
		
		List<TaiexTradeData> datas = dao.getTaiexTradeVolume(snapMonth, whereCondition);
		if (StringUtils.isBlank(whereCondition)) {
			for (TaiexTradeData data : datas) {
				data.setTargetAcct(0L);
				data.setTargetActRatio(BigDecimal.ZERO);
				data.setTargetTxRatio(0L);
			}
		}
		
		if(!CollectionUtils.isEmpty(datas)) {
		    for (TaiexTradeData data : datas) {
                data.setSeq(StringUtils.substringBefore(data.getAvgMonthlyTradVolCI(), "_"));
                data.setAvgMonthlyTradVolCI(StringUtils.substringAfter(data.getAvgMonthlyTradVolCI(), "_"));
            }
		}
		rs.setData(datas);
		return rs;
	}
	
	/**
	 * 匯出Excel
	 * @param data
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/exportExcel", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Resource> exportExcel(@RequestBody List<Map<String, String>> data) throws Exception {
		
		return ExcelGenerator.generate((workbook) -> {
			Sheet sheet = workbook.createSheet();
			
			Row headRow = sheet.createRow(0);
			headRow.setHeight((short) 700);
			headRow.createCell(0).setCellValue("月均交易量級距\n(新台幣/元)");
			headRow.createCell(1).setCellValue("全體戶數");
			headRow.createCell(2).setCellValue("受眾戶數");
			headRow.createCell(3).setCellValue("受眾戶數佔比(%)");
			headRow.createCell(4).setCellValue("全體戶數佔比(%)");
			headRow.createCell(5).setCellValue("受眾交易量佔比(%)");
			
			CellStyle cs = workbook.createCellStyle();
			cs.setWrapText(true);
			headRow.getCell(0).setCellStyle(cs);
			
			for (int i = 0; i < data.size(); i++) {
				Map<String, String> rcd = data.get(i);
				
				Row rcdRow = sheet.createRow(i + 1);
				rcdRow.createCell(0).setCellValue(rcd.get("avgMonthlyTradVolCI"));
				rcdRow.createCell(1).setCellValue(rcd.get("sampleAcct"));
				rcdRow.createCell(2).setCellValue(rcd.get("targetAcct"));
				rcdRow.createCell(3).setCellValue(rcd.get("targetActRatio"));
				rcdRow.createCell(4).setCellValue(rcd.get("sampleActRatio"));
				rcdRow.createCell(5).setCellValue(rcd.get("targetTxRatio"));
				
			}
			
			sheet.setColumnWidth(0, 6000);
			
		});
		
	}
}
