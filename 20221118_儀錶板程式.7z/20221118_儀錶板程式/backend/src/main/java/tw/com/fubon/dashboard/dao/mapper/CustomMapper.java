package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.age.AgeData;
import tw.com.fubon.dashboard.api.top10.Top10Data;

public interface CustomMapper {

	
	/**
	 * 取得轉檔年月
	 * @return
	 */
	public List<String> getSnapDates();
	
	/**
	 * 取得原始戶數
	 * @param snapDate
	 * @return
	 */
	public long getTotalCount(@Param("snapDate") String snapDate);
	
	/**
	 * 取得篩選後戶數 
	 * @param conditions
	 * @return
	 */
	public long getFilteredCount(
			@Param("snapDate") String snapDate,
			@Param("conditions") String conditions);
	
	/**
     * 查詢年齡層分布資料
     * @param snapDate
     * @param conditions
     * @return
     */
    public List<AgeData> getAgeDataDistrb(
            @Param("snapDate") String snapDate,
            @Param("conditions") String conditions);
    
    
	
    /**
     * 查詢台股交易類股TOP 10
     * @param snapDate
     * @param conditions
     * @return
     */
    public List<Top10Data> getTop10Data(
            @Param("snapDate") String snapDate,
            @Param("conditions") String conditions);
}
