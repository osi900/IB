package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.fubon.dashboard.dao.bean.TagGroupVals;
import tw.com.fubon.dashboard.dao.bean.TagGroupValsExample;

public interface TagGroupValsMapper {
    long countByExample(TagGroupValsExample example);

    int deleteByExample(TagGroupValsExample example);

    int deleteByPrimaryKey(Integer tagGroupValsId);

    int insert(TagGroupVals record);

    int insertSelective(TagGroupVals record);

    List<TagGroupVals> selectByExample(TagGroupValsExample example);

    TagGroupVals selectByPrimaryKey(Integer tagGroupValsId);

    int updateByExampleSelective(@Param("record") TagGroupVals record, @Param("example") TagGroupValsExample example);

    int updateByExample(@Param("record") TagGroupVals record, @Param("example") TagGroupValsExample example);

    int updateByPrimaryKeySelective(TagGroupVals record);

    int updateByPrimaryKey(TagGroupVals record);
}