package tw.com.fubon.dashboard.api.accountopensource;

import java.math.BigDecimal;

public class AccountOpenSourceData {
    
    /**  */
    private String seq;
    /** 進件來源 */
    private String source;
    /** 當月開戶數 */
    private Long acctOpenThisMonth;
    /** 當月開戶數佔比 */
    private BigDecimal acctOpenThisMonthPropo;
    /** 年累開戶數 */
    private Long acctOpenThisYear;
    /** 年累開戶數佔比 */
    private BigDecimal acctOpenThisYearPropo;
    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }
    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }
    /**
     * @return the source
     */
    public String getSource() {
        return source;
    }
    /**
     * @param source the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }
    /**
     * @return the acctOpenThisMonth
     */
    public Long getAcctOpenThisMonth() {
        return acctOpenThisMonth;
    }
    /**
     * @param acctOpenThisMonth the acctOpenThisMonth to set
     */
    public void setAcctOpenThisMonth(Long acctOpenThisMonth) {
        this.acctOpenThisMonth = acctOpenThisMonth;
    }
    /**
     * @return the acctOpenThisMonthPropo
     */
    public BigDecimal getAcctOpenThisMonthPropo() {
        return acctOpenThisMonthPropo;
    }
    /**
     * @param acctOpenThisMonthPropo the acctOpenThisMonthPropo to set
     */
    public void setAcctOpenThisMonthPropo(BigDecimal acctOpenThisMonthPropo) {
        this.acctOpenThisMonthPropo = acctOpenThisMonthPropo;
    }
    /**
     * @return the acctOpenThisYear
     */
    public Long getAcctOpenThisYear() {
        return acctOpenThisYear;
    }
    /**
     * @param acctOpenThisYear the acctOpenThisYear to set
     */
    public void setAcctOpenThisYear(Long acctOpenThisYear) {
        this.acctOpenThisYear = acctOpenThisYear;
    }
    /**
     * @return the acctOpenThisYearPropo
     */
    public BigDecimal getAcctOpenThisYearPropo() {
        return acctOpenThisYearPropo;
    }
    /**
     * @param acctOpenThisYearPropo the acctOpenThisYearPropo to set
     */
    public void setAcctOpenThisYearPropo(BigDecimal acctOpenThisYearPropo) {
        this.acctOpenThisYearPropo = acctOpenThisYearPropo;
    }
    
}
