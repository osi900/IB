package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.branch.BranchData;

public interface BranchDistributionMapper {

	
    /**
     * 查詢分公司分布資料
     * @param snapDate
     * @return
     */
    public List<BranchData> getBranchDistribution(
    		@Param("snapDate") String snapDate,
            @Param("conditions") String conditions);
    
	
}
