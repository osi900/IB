package tw.com.fubon.dashboard.api.accountopensource;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.StringUtil;

/**
 * 開戶進件來源
 */
@RestController
@RequestMapping(path = "/account_open_source")
public class AccountOpenSourceController extends ControllerBase {

	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountOpenSourceResponse getData(@RequestBody AccountOpenSourceRequest rq) {
	    String snapMonth = rq.getSnapDate();
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		
		logger.info("snapMonth: {}, whereCondition: {}", snapMonth, whereCondition);
		
		AccountOpenSourceResponse rs = new AccountOpenSourceResponse();
		
		List<AccountOpenSourceData> datas = dao.getAccountOpenSource(snapMonth, whereCondition);
		
		if(!CollectionUtils.isEmpty(datas)) {
		    for (AccountOpenSourceData data : datas) {
                data.setSeq(StringUtils.substringBefore(data.getSource(), "_"));
                data.setSource(StringUtils.substringAfter(data.getSource(), "_"));
            }
		}
		rs.setData(datas);
		return rs;
	}
}
