package tw.com.fubon.dashboard.api.taiextradevol;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class TaiexTradeVolumeResponse extends ResponseBase {

	private List<TaiexTradeData> data;

	public List<TaiexTradeData> getData() {
		return data;
	}

	public void setData(List<TaiexTradeData> data) {
		this.data = data;
	}
	
}
