package tw.com.fubon.dashboard.api.home;

import java.util.List;
import java.util.Map;

import tw.com.fubon.dashboard.api.ResponseBase;
import tw.com.fubon.dashboard.vo.Filter;
import tw.com.fubon.dashboard.vo.TagData;

public class HomeResponse extends ResponseBase {

	private String clientIp;
	
	/** 轉檔年月 */
	private List<String> snapDates;
	
	/** 原始戶數 */
	private long total;
	
	/** 篩選後戶數 */
	private long filteredCount;
	
	/** 標籤群組 */
	private List<Map<String, String>> tagGroups;
	
	/** 標籤群組設定 */
	private Map<String, List<Filter>> filters;
	
	/** 標籤資料 */
	private List<TagData> allTags;
	
	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public List<String> getSnapDates() {
		return snapDates;
	}

	public void setSnapDates(List<String> snapDates) {
		this.snapDates = snapDates;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public long getFilteredCount() {
		return filteredCount;
	}

	public void setFilteredCount(long filteredCount) {
		this.filteredCount = filteredCount;
	}

	public List<Map<String, String>> getTagGroups() {
		return tagGroups;
	}

	public void setTagGroups(List<Map<String, String>> tagGroups) {
		this.tagGroups = tagGroups;
	}

	public Map<String, List<Filter>> getFilters() {
		return filters;
	}

	public void setFilters(Map<String, List<Filter>> filters) {
		this.filters = filters;
	}

	public List<TagData> getAllTags() {
		return allTags;
	}

	public void setAllTags(List<TagData> allTags) {
		this.allTags = allTags;
	}

}
