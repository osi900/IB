package tw.com.fubon.dashboard.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.databind.ObjectMapper;

import tw.com.fubon.dashboard.api.ResponseBase;
import tw.com.fubon.dashboard.errors.ErrorCode;
import tw.com.fubon.dashboard.exceptions.ValidateException;
import tw.com.fubon.dashboard.utils.AuthUtil;
import tw.com.fubon.dashboard.utils.RequestWrapper;
import tw.com.fubon.dashboard.utils.ResponseWrapper;
import tw.com.fubon.dashboard.utils.SystemUtils;
import tw.com.fubon.dashboard.vo.BdpUserInfo;
import tw.com.fubon.dashboard.vo.UserProfile;

public class AuthFilter extends OncePerRequestFilter {

	private static Logger _logger = LoggerFactory.getLogger(AuthFilter.class);
	
	private static final List<String> BYPASS = new ArrayList<String>();
	static {
		BYPASS.add("/login/auth");
		BYPASS.add("/login/verifyToken");
	}
	
	private AuthUtil authUtil;
	private NativeWebRequest webRequest;
	
	public AuthFilter(AuthUtil authUtil, NativeWebRequest webRequest) {
		this.authUtil = authUtil;
		this.webRequest = webRequest;
	}
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setHeader("Cache-Control", "no-cache");
		try {
			String url = request.getRequestURL().toString();
			if (!byPass(url)) {
				boolean logedIn = false;
				
				// 驗證Session
				HttpSession session = request.getSession();
				UserProfile userProfile = (UserProfile) session.getAttribute(UserProfile.SESSION_USER_PROFILE);
				String token = StringUtils.trimToEmpty(request.getHeader("Authorization")).replace("Bearer ", "");
				if (StringUtils.isNotBlank(token)) {
					// 使用token登入，每次request要驗一次token
					ErrorCode code = authUtil.checkToken(token);
					if (ErrorCode.OK == code) {
						logedIn = true;
						
						// Session內尚未有資料，建立Session資料
						if (userProfile == null) {
							BdpUserInfo userInfo = authUtil.getUserInfo(token);
							
							UserProfile user = new UserProfile();
							user.setClientIp(SystemUtils.detectClientIp(webRequest));
							user.setLoginType("token");
							user.setUserName(userInfo.getUserName());
							user.setUserAccount(userInfo.getUserAccount());
							user.setBdpUserInfo(userInfo);
							session.setAttribute(UserProfile.SESSION_USER_PROFILE, user);
						}
					}
				}
				
				
				if (!logedIn && userProfile != null && "pwd".equals(userProfile.getLoginType())) {
					// 之前用密碼登入
					logedIn = true;
				}
				
				if (!logedIn) {
					// (9990)尚未登入
					response.getWriter().append(createResponse(ErrorCode.NOT_LOGIN, "", null));
				}
			}
			
			RequestWrapper requestWrapper = new RequestWrapper(request);
			ResponseWrapper responseWrapper = new ResponseWrapper(response);
			filterChain.doFilter(requestWrapper, responseWrapper);
			
		} catch (Exception ex) {
			
			Throwable rootEx = ExceptionUtils.getRootCause(ex);
			_logger.error(ex.getMessage(), ex);
			try {
				if (rootEx instanceof ValidateException) {
					// (9994)欄位檢核錯誤
					ValidateException ve = (ValidateException) rootEx;
					_logger.error("檢核失敗欄位: " + ve.getErrors());
					response.getWriter().append(createResponse(ErrorCode.VALIDATE_FAILED, ExceptionUtils.getRootCause(ex).getClass().getName(), ve.getErrors()));
				} else {
					// (9999)未知錯誤
					response.getWriter().append(createResponse(ErrorCode.UNKNOWN_ERROR, rootEx.getClass().getName() + "-" + rootEx.getMessage(), null));
				}
				
			} catch (Exception e) {
				_logger.error(ex.getMessage(), ex);
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			}
			
		}
		
	}

	/**
	 * 建立錯誤訊息
	 * @param errorCode
	 * @return
	 * @throws Exception
	 */
	private String createResponse(ErrorCode errorCode, String message, Map<String, String> errFields) throws Exception {
		ResponseBase rs = new ResponseBase();
		rs.setCode(errorCode.getCode());
		rs.setMessage(message);
		if (errFields != null) {
			rs.getPayloads().putAll(errFields);
		}
		rs.getPayloads().put("cause", message);
		
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(rs);
	}

	private boolean byPass(String url) {
		for (String byPass : BYPASS) {
			if (url.endsWith(byPass)) {
				return true;
			}
		}
		return false;
	}
	
}
