package tw.com.fubon.dashboard.api.log;

import tw.com.fubon.dashboard.api.RequestBase;

public class LogRequest extends RequestBase {

	private String tagName;
	
	private String srcCol;

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public String getSrcCol() {
		return srcCol;
	}

	public void setSrcCol(String srcCol) {
		this.srcCol = srcCol;
	}
	
}
