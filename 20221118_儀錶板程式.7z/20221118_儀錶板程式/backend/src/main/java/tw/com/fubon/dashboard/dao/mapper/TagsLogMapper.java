package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.fubon.dashboard.dao.bean.TagsLog;
import tw.com.fubon.dashboard.dao.bean.TagsLogExample;

public interface TagsLogMapper {
    long countByExample(TagsLogExample example);

    int deleteByExample(TagsLogExample example);

    int insert(TagsLog record);

    int insertSelective(TagsLog record);

    List<TagsLog> selectByExample(TagsLogExample example);

    int updateByExampleSelective(@Param("record") TagsLog record, @Param("example") TagsLogExample example);

    int updateByExample(@Param("record") TagsLog record, @Param("example") TagsLogExample example);
}