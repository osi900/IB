package tw.com.fubon.dashboard.dao.bean;

import java.io.Serializable;
import java.util.Date;

public class TagsLog implements Serializable {
    private String userAcct;

    private String tagName;

    private String srcCol;

    private Date createTime;

    private static final long serialVersionUID = 1L;

    public String getUserAcct() {
        return userAcct;
    }

    public void setUserAcct(String userAcct) {
        this.userAcct = userAcct == null ? null : userAcct.trim();
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName == null ? null : tagName.trim();
    }

    public String getSrcCol() {
        return srcCol;
    }

    public void setSrcCol(String srcCol) {
        this.srcCol = srcCol == null ? null : srcCol.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}