package tw.com.fubon.dashboard.dao.bean;

import java.io.Serializable;

public class Tags implements Serializable {
    private Long tagId;

    private String name;

    private String icon;

    private Long parentTag;

    private String srcCol;

    private String memo;

    private String optType;

    private static final long serialVersionUID = 1L;

    public Long getTagId() {
        return tagId;
    }

    public void setTagId(Long tagId) {
        this.tagId = tagId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon == null ? null : icon.trim();
    }

    public Long getParentTag() {
        return parentTag;
    }

    public void setParentTag(Long parentTag) {
        this.parentTag = parentTag;
    }

    public String getSrcCol() {
        return srcCol;
    }

    public void setSrcCol(String srcCol) {
        this.srcCol = srcCol == null ? null : srcCol.trim();
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo == null ? null : memo.trim();
    }

    public String getOptType() {
        return optType;
    }

    public void setOptType(String optType) {
        this.optType = optType == null ? null : optType.trim();
    }
}