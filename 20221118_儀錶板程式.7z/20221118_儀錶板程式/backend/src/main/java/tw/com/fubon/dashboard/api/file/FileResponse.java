package tw.com.fubon.dashboard.api.file;

import tw.com.fubon.dashboard.api.ResponseBase;

public class FileResponse extends ResponseBase {

}
