package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.prodcontribution.ProductContributionDistributionData;

public interface ProductContributionDistributionMapper {

    /**
     * 產品貢獻度分布
     * @param snapDate
     * @return
     */
    public List<ProductContributionDistributionData> getProdContributionDistrib(
    		@Param("snapDate") String snapDate,
            @Param("conditions") String conditions);
	
}
