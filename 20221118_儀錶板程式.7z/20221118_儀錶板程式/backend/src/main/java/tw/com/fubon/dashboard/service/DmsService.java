package tw.com.fubon.dashboard.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import tw.com.fubon.dashboard.api.accountopensource.AccountOpenSourceData;
import tw.com.fubon.dashboard.api.age.AgeData;
import tw.com.fubon.dashboard.api.branch.BranchData;
import tw.com.fubon.dashboard.api.effectivesignacct.EffectiveSignAcctData;
import tw.com.fubon.dashboard.api.electronicacctamt.ElectronicAcctAmtData;
import tw.com.fubon.dashboard.api.overseastradevol.OverseasTradeData;
import tw.com.fubon.dashboard.api.prodcontribution.ProductContributionDistributionData;
import tw.com.fubon.dashboard.api.taiexrealizedprofitloss.TaiexRealizedProfitLossData;
import tw.com.fubon.dashboard.api.taiextradevol.TaiexTradeData;
import tw.com.fubon.dashboard.api.taiexunrealizedprofitloss.TaiexUnrealizedProfitLossData;
import tw.com.fubon.dashboard.api.top10.Top10Data;
import tw.com.fubon.dashboard.dao.mapper.AccountOpenSourceMapper;
import tw.com.fubon.dashboard.dao.mapper.BranchDistributionMapper;
import tw.com.fubon.dashboard.dao.mapper.CustomMapper;
import tw.com.fubon.dashboard.dao.mapper.EffectiveSignAcctMapper;
import tw.com.fubon.dashboard.dao.mapper.ElectronicAcctAmtProportionMapper;
import tw.com.fubon.dashboard.dao.mapper.OverseasTradeVolumeMapper;
import tw.com.fubon.dashboard.dao.mapper.ProductContributionDistributionMapper;
import tw.com.fubon.dashboard.dao.mapper.TaiexRealizedProfitLossMapper;
import tw.com.fubon.dashboard.dao.mapper.TaiexTradeVolumeMapper;
import tw.com.fubon.dashboard.dao.mapper.TaiexUnrealizedProfitLossMapper;
import tw.com.fubon.dashboard.dao.mapper.UserTempDashboardMapper;
import tw.com.fubon.dashboard.vo.UserTempDashboard;

@Component
public class DmsService {

    @Autowired
    @Qualifier("dmsSqlSessionTemplate")
    private SqlSessionTemplate dmsSqlTemplate;

    /**
     * 取得轉檔年月
     * 
     * @return
     */
    public List<String> getSnapDateList() {
        CustomMapper mapper = dmsSqlTemplate.getMapper(CustomMapper.class);
        return mapper.getSnapDates();
    }

    /**
     * 取得原始戶數
     * 
     * @param snapDate
     * @return
     */
    public long getTotalCount(String snapDate) {
        CustomMapper mapper = dmsSqlTemplate.getMapper(CustomMapper.class);
        return mapper.getTotalCount(snapDate);
    }

    /**
     * 取得篩選後戶數
     * 
     * @param snapDate
     * @return
     */
    public long getFilteredCount(String snapDate, String conditions) {
        CustomMapper mapper = dmsSqlTemplate.getMapper(CustomMapper.class);
        return mapper.getFilteredCount(snapDate, conditions);
    }

    /**
     * 查詢年齡層分布資料
     * 
     * @param snapDate
     * @param conditions
     * @return
     */
    public List<AgeData> getAgeDataDistrb(String snapDate, String conditions) {
        CustomMapper mapper = dmsSqlTemplate.getMapper(CustomMapper.class);
        return mapper.getAgeDataDistrb(snapDate, conditions);
    }

    /**
     * 查詢分公司分布資料
     * 
     * @param snapDate
     * @return
     */
    public List<BranchData> getBranchDistribution(String snapDate, String conditions) {
        BranchDistributionMapper mapper = dmsSqlTemplate.getMapper(BranchDistributionMapper.class);
        return mapper.getBranchDistribution(snapDate, conditions);
    }

    /**
     * 查詢台股月均交易量
     * 
     * @param snapDate
     * @return
     */
    public List<TaiexTradeData> getTaiexTradeVolume(String snapDate, String conditions) {
        TaiexTradeVolumeMapper mapper = dmsSqlTemplate.getMapper(TaiexTradeVolumeMapper.class);
        return mapper.getTaiexTradeVolume(snapDate, conditions);
    }

    /**
     * 查詢台股交易類股TOP 10
     * 
     * @param snapDate
     * @param conditions
     * @return
     */
    public List<Top10Data> getTop10Data(String snapDate, String conditions) {
        CustomMapper mapper = dmsSqlTemplate.getMapper(CustomMapper.class);
        return mapper.getTop10Data(snapDate, conditions);
    }

    /**
     * 查詢台股月均交易量
     * 
     * @param snapDate
     * @return
     */
    public List<OverseasTradeData> getOverseasTradeVolume(String snapDate, String conditions) {
        OverseasTradeVolumeMapper mapper = dmsSqlTemplate.getMapper(OverseasTradeVolumeMapper.class);
        return mapper.getOverseasTradeVolume(snapDate, conditions);
    }
    
    
    /**
     * 產品貢獻度分布
     * @param snapDate
     * @return
     */
    public List<ProductContributionDistributionData> getProductContributionDistribution(String snapDate, String conditions) {
        ProductContributionDistributionMapper mapper = dmsSqlTemplate.getMapper(ProductContributionDistributionMapper.class);
        return mapper.getProdContributionDistrib(snapDate, conditions);
    }
    
    /**
     * 【客戶賺錢/賠錢】-台股已實現損益
     * @param snapDate
     * @return
     */
    public List<TaiexRealizedProfitLossData> getTaiexRealizedProfitLoss(String snapDate, String conditions){
        TaiexRealizedProfitLossMapper mapper = dmsSqlTemplate.getMapper(TaiexRealizedProfitLossMapper.class);
        return mapper.getTaiexRealizedProfitLoss(snapDate, conditions);
    }
    
    /**
     * 【客戶賺錢/賠錢】-台股未實現損益
     * @param snapDate
     * @return
     */
    public List<TaiexUnrealizedProfitLossData> getTaiexUnrealizedProfitLoss(String snapDate, String conditions){
        TaiexUnrealizedProfitLossMapper mapper = dmsSqlTemplate.getMapper(TaiexUnrealizedProfitLossMapper.class);
        return mapper.getTaiexUnrealizedProfitLoss(snapDate, conditions);
    }
    
    /**
     * 電子戶數及金額自佔率
     * @param snapDate
     * @return
     */
    public List<ElectronicAcctAmtData> getElectronicAcctAmtProportion(String snapDate, String conditions){
        ElectronicAcctAmtProportionMapper mapper = dmsSqlTemplate.getMapper(ElectronicAcctAmtProportionMapper.class);
        return mapper.getElectronicAcctAmtProportion(snapDate, conditions);
    }
    
    /**
     * 開戶進件來源
     * @param snapDate
     * @return
     */
    public List<AccountOpenSourceData> getAccountOpenSource(String snapDate, String conditions){
        AccountOpenSourceMapper mapper = dmsSqlTemplate.getMapper(AccountOpenSourceMapper.class);
        return mapper.getAccountOpenSource(snapDate, conditions);
    }
    
    /**
     * 各項業務有效簽署戶數
     * @param snapDate
     * @param conditions
     * @return
     */
    public List<EffectiveSignAcctData> getEffectiveSignAcctData(String snapDate, String conditions) {
    	EffectiveSignAcctMapper mapper = dmsSqlTemplate.getMapper(EffectiveSignAcctMapper.class);
        return mapper.getEffectiveSignAcct(snapDate, conditions);
    }
    
    /**
     * 更新USER_TEMP
     * @param temp
     */
    @Transactional("dmsTxnManager")
    public void updateUserTemp(List<UserTempDashboard> temp, String userName) {
    	UserTempDashboardMapper mapper = dmsSqlTemplate.getMapper(UserTempDashboardMapper.class);
    	mapper.deleteByUserName(userName);
    	
    	if (temp != null) {
    		for (UserTempDashboard t : temp) {
        		mapper.insert(t);
        	}
    	}
    	
    }
    
    public long getUserTempCount(String userAccount) {
    	UserTempDashboardMapper mapper = dmsSqlTemplate.getMapper(UserTempDashboardMapper.class);
    	return mapper.countByUserAcct(userAccount);
    }
}
