package tw.com.fubon.dashboard.api.taiexrealizedprofitloss;

public class TaiexRealizedProfitLossData extends ProfitLossData{}
