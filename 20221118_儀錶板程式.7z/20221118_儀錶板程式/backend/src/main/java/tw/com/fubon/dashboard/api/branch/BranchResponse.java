package tw.com.fubon.dashboard.api.branch;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class BranchResponse extends ResponseBase {

	private List<BranchData> data;

	public List<BranchData> getData() {
		return data;
	}

	public void setData(List<BranchData> data) {
		this.data = data;
	}
	
}
