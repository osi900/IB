package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.effectivesignacct.EffectiveSignAcctData;

public interface EffectiveSignAcctMapper {

	
	/**
     * 開戶進件來源
     * @param snapDate
     * @return
     */
    public List<EffectiveSignAcctData> getEffectiveSignAcct(
    		@Param("snapDate") String snapDate,
            @Param("conditions") String conditions);
}
