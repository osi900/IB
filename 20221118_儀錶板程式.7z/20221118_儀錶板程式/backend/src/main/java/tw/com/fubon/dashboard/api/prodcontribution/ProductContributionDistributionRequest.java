package tw.com.fubon.dashboard.api.prodcontribution;

import tw.com.fubon.dashboard.api.RequestBase;

public class ProductContributionDistributionRequest extends RequestBase {

}
