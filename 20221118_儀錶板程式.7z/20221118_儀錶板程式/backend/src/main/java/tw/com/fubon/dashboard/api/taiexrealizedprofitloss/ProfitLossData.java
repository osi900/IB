package tw.com.fubon.dashboard.api.taiexrealizedprofitloss;

import java.math.BigDecimal;

public class ProfitLossData {

    /**  */
    private String seq;
    /**  */
	private String scale;
	/** 賺錢戶數 */
	private Long benefitAcct = 0L;
	/** 賺錢金額 */
	private BigDecimal benefitAmt = BigDecimal.ZERO;
	/** 人均賺  */
	private BigDecimal benefitPerCapita = BigDecimal.ZERO;
	/** 賠錢戶數 */
	private Long lossAcct = 0L;
	/** 賠錢金額 */
	private BigDecimal lossAmt = BigDecimal.ZERO;
	/** 人均賠 */
	private BigDecimal lossPerCapita = BigDecimal.ZERO;

    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }

    /**
     * @return the scale
     */
    public String getScale() {
        return scale;
    }

    /**
     * @param scale the scale to set
     */
    public void setScale(String scale) {
        this.scale = scale;
    }

    /**
     * @return the benefitAcct
     */
    public Long getBenefitAcct() {
        return benefitAcct;
    }

    /**
     * @param benefitAcct the benefitAcct to set
     */
    public void setBenefitAcct(Long benefitAcct) {
        this.benefitAcct = benefitAcct;
    }

    /**
     * @return the benefitAmt
     */
    public BigDecimal getBenefitAmt() {
        return benefitAmt;
    }

    /**
     * @param benefitAmt the benefitAmt to set
     */
    public void setBenefitAmt(BigDecimal benefitAmt) {
        this.benefitAmt = benefitAmt;
    }

    /**
     * @return the benefitPerCapita
     */
    public BigDecimal getBenefitPerCapita() {
        return benefitPerCapita;
    }

    /**
     * @param benefitPerCapita the benefitPerCapita to set
     */
    public void setBenefitPerCapita(BigDecimal benefitPerCapita) {
        this.benefitPerCapita = benefitPerCapita;
    }

    /**
     * @return the lossAcct
     */
    public Long getLossAcct() {
        return lossAcct;
    }

    /**
     * @param lossAcct the lossAcct to set
     */
    public void setLossAcct(Long lossAcct) {
        this.lossAcct = lossAcct;
    }

    /**
     * @return the lossAmt
     */
    public BigDecimal getLossAmt() {
        return lossAmt;
    }

    /**
     * @param lossAmt the lossAmt to set
     */
    public void setLossAmt(BigDecimal lossAmt) {
        this.lossAmt = lossAmt;
    }

    /**
     * @return the lossPerCapita
     */
    public BigDecimal getLossPerCapita() {
        return lossPerCapita;
    }

    /**
     * @param lossPerCapita the lossPerCapita to set
     */
    public void setLossPerCapita(BigDecimal lossPerCapita) {
        this.lossPerCapita = lossPerCapita;
    }

    
	
}
