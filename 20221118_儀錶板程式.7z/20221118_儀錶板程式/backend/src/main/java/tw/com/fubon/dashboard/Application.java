package tw.com.fubon.dashboard;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import tw.com.fubon.dashboard.filter.AuthFilter;
import tw.com.fubon.dashboard.interceptor.RqInterceptor;
import tw.com.fubon.dashboard.utils.AuthUtil;

@EnableAutoConfiguration
@EnableTransactionManagement
@SpringBootApplication
public class Application implements WebMvcConfigurer {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	/**
	 * 設定Request Filter
	 * @return
	 */
	@Bean
    public FilterRegistrationBean<?> authFilter(AuthUtil authUtil, NativeWebRequest webRequest) {
        FilterRegistrationBean<AuthFilter> bean = new FilterRegistrationBean<>();        
        bean.setFilter(new AuthFilter(authUtil, webRequest));
        bean.addUrlPatterns("/*");
        return bean;
    }
	
	/**
	 * 解密設定值
	 * @return
	 */
	@Bean(name = "encryptorBean")
	static public StringEncryptor stringEncryptor() {
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig config = new SimpleStringPBEConfig();
        config.setPassword("!!!yourpassword!!!");
        config.setAlgorithm("PBEWithMD5AndDES");
        config.setKeyObtentionIterations("1000");
        config.setPoolSize("1");
        config.setProviderName("SunJCE");
        config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
        config.setIvGeneratorClassName("org.jasypt.iv.NoIvGenerator");
        config.setStringOutputType("base64");
        encryptor.setConfig(config);
        return encryptor;
    }
	
	@Override
    public void addInterceptors(InterceptorRegistry registry) {
       registry.addInterceptor(new RqInterceptor()).addPathPatterns("/**");
    }
	
	
}
