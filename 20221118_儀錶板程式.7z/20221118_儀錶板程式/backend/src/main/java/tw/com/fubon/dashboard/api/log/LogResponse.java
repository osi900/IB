package tw.com.fubon.dashboard.api.log;

import tw.com.fubon.dashboard.api.ResponseBase;

public class LogResponse extends ResponseBase {

}
