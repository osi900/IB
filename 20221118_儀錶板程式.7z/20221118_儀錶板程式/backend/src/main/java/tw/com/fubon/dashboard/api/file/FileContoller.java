package tw.com.fubon.dashboard.api.file;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.errors.ErrorCode;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.vo.UserProfile;
import tw.com.fubon.dashboard.vo.UserTempDashboard;

@RestController
@RequestMapping(path = "/file")
public class FileContoller extends ControllerBase {
	
	@Autowired
	private DmsService dao;
	
	/**
	 * 上傳客戶帳號
	 * @param rq
	 * @return
	 */
	@PostMapping(path = "/uploadAccts",  produces = MediaType.APPLICATION_JSON_VALUE)
    public FileResponse uploadAccts(@RequestBody FileRequest rq) {
		FileResponse rs = new FileResponse();
		
		String acctData = new String(Base64.getDecoder().decode(StringUtils.substringAfter(rq.getAccts(), "base64,")));
		List<String> acctList = Arrays.asList(acctData.split("\\r?\\n")).stream()
				.filter(p -> StringUtils.isNotBlank(p))
				.distinct()
				.collect(Collectors.toList());
		
		if (acctList.size() < 20) {
			rs.setCode(ErrorCode.FILE_ACCT_NUM_ERROR.getCode());
			rs.setMessage(ErrorCode.FILE_ACCT_NUM_ERROR.getMessage());
			return rs;
		}
		
		// 新增Oracle USER_TEMP_DASHBOARD
		List<UserTempDashboard> temp = new ArrayList<>();
		for (String act : acctList) {
			UserTempDashboard t = new UserTempDashboard();
			t.setAcctNbr(StringUtils.trimToEmpty(act));
			t.setLoginUser(getLoginUser().getUserAccount());
			temp.add(t);
		}
		
		dao.updateUserTemp(temp, getLoginUser().getUserAccount());
		
		if (!temp.isEmpty()) {
			UserProfile user = getLoginUser();
			user.setJoinAccts(user.getUserAccount());
			setLoginUser(user);
		}
		
		return rs;
	}
	
	/**
	 * 移除客戶帳號
	 * @param rq
	 * @return
	 */
	@PostMapping(path = "/removeAccts",  produces = MediaType.APPLICATION_JSON_VALUE)
    public FileResponse removeAccts() {
		FileResponse rs = new FileResponse();
		dao.updateUserTemp(null, getLoginUser().getUserAccount());
		
		UserProfile user = getLoginUser();
		user.setJoinAccts(null);
		setLoginUser(user);
		return rs;
	}
}
