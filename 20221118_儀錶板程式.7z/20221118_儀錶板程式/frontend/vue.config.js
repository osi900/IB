module.exports = {
		lintOnSave: false,
		publicPath: '/dashboard',
		devServer: {
			port: 3000,
			proxy: {
				'/Dashboard/*': {
					target: 'http://localhost:8080'
				}
			}
		},
		configureWebpack: {
			entry: {
				app: './src/main.ts',
				style: [
					'bootstrap/dist/css/bootstrap.min.css',
					'jquery-ui/themes/base/all.css',
					'@fortawesome/fontawesome-free/css/all.min.css',
				]
			}
		},
		chainWebpack: config => {
            config
                .plugin('html')
                .tap(args => {
                    args[0].title = "可視化數據平台";
                    return args;
                })
        }
}