<template>
	<ChartTabs @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<!-- 頁簽 -->
		<ul slot="tabs" class="nav nav-tabs card-header-tabs pull-right" role="tablist">
			<li class="nav-item">
				<a class="nav-link active" data-toggle="tab" href="#prodContributionTab1" role="tab" aria-controls="cusincome" aria-selected="true">圖</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#prodContributionTab2" role="tab" aria-controls="cusunincome" aria-selected="false">表</a>
			</li>
		</ul>
		<template slot="chart">
			<!-- 圖 -->
			<div id="prodContributionTab1" style="height: 100%" class="tab-pane fade show active" role="tabpanel" aria-labelledby="tab1-tab">
				<div ref="prodContributionChart" style="height: 100%"></div>
			</div>
			<!-- 表 -->
			<div id="prodContributionTab2" class="tab-pane fade" role="tabpanel" aria-labelledby="tab2-tab" style="height: 100%;width: 100%;">
				<a @click="exportExcel" class="sidebar-brand d-flex align-items-end justify-content-end mb-2">
					<div class="sidebar-brand-icon">
						<img class="img-fluid" src="@/assets/img/excel.png" width="25" />
					</div>
				</a>
				<div slot="chart" style="height: 90%;width: 100%;overflow-y: auto;">
					<div class="table-responsive-sm" ref="prodContributionTable">
						<table class="table table-bordered table-sm table-hover">
							<thead class="text-center">
								<tr>
									<th></th>
									<th>產品</th>
									<th>全體戶數</th>
									<th>受眾戶數</th>
									<th>全體滲透率(%)</th>
									<th>受眾滲透率(%)</th>
									<th>年累貢獻度(新台幣/千元)/口數</th>
									<th>受眾貢獻度佔比(%)</th>
									<th>年累交易量<br/>(新台幣/百萬)</th>
								</tr>
							</thead>
							<tbody>
								<template v-for="(data_main, main_idx) in data" >
									<tr v-for="(data_, i) in data_main.datas" v-bind:key="'prod_contri_main_'+main_idx+'_'+i">
										<td v-if="i == 0" :rowspan="data_main.rowSpan" :class="data_main.cateBgColor" >{{ data_main.cateName }}</td>
										<td :class="data_main.prodBgColor">{{data_.product}}</td>
										<td style="text-align: right;">{{formatNumber(data_.accountCnt)}}</td>
										<td style="text-align: right;">{{formatNumber(data_main.targetData[i].accountCnt)}}</td>
										<td style="text-align: right;">{{formatFloat(data_.participationRate, 1)}}</td>
										<td style="text-align: right;">{{formatFloat(data_main.targetData[i].participationRate, 1)}}</td>
										<td style="text-align: right;">{{formatNumber(data_.contributionYearly)}}</td>
										<td style="text-align: right;">{{formatFloat(data_main.targetData[i].contributionProportion, 2)}}</td>
										<td style="text-align: right;">{{formatNumber(data_.tradeVolumeYearly)}}</td>
									</tr>
								</template>
							</tbody>
						</table>		
					</div>
				</div>
			</div>
		</template>
		
		
	</ChartTabs>
</template>

<script type="ts" src="./ProdContributionChart.ts"></script>