<template>
	<ChartTabs @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<!-- 頁簽 -->
		<ul slot="tabs" class="nav nav-tabs card-header-tabs pull-right" role="tablist">
			<li class="nav-item">
			    <a class="nav-link active" data-toggle="tab" href="#tab1" role="tab" aria-controls="cusincome" aria-selected="true">台股已實現損益</a>
			</li>
			<li class="nav-item">
			    <a class="nav-link" data-toggle="tab" href="#tab2" role="tab" aria-controls="cusunincome" aria-selected="false">台股未實現損益</a>
			</li>
		</ul>
		<template ref="tableChart" slot="chart">
			<div id="tab1" class="tab-pane fade show active" role="tabpanel" aria-labelledby="tab1-tab">
                <div class="table-responsive">
                	<table class="table table-bordered table-sm table-striped table-hover">
                		<thead class="text-center">
                			<tr>
                				<th></th>
                				<th colspan="3">賺錢</th>
                				<th colspan="3">賠錢</th>
                			</tr>
                		</thead>
                		<tbody>
                			<tr>
                				<td>級距</td>
	                            <td>戶數</td>
	                            <td>金額</td>
	                            <td>賺錢/人</td>
	                            <td>戶數</td>
	                            <td>金額</td>
	                            <td>賠錢/人</td>
                			</tr>
                			<tr>
                				<td>1萬以內</td>
                				<td>1</td>
	                            <td>1</td>
	                            <td>1</td>
	                            <td>1</td>
	                            <td>1</td>
	                            <td>1</td>
                			</tr>
                		</tbody>
                	</table>
                </div>
            </div>
            <div id="tab2" class="tab-pane fade" role="tabpanel" aria-labelledby="tab2-tab">
                2
            </div>
		</template>
	</ChartTabs>
</template>

<script type="ts" src="./TableChart.ts"></script>