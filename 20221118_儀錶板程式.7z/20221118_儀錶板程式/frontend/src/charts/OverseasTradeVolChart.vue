<template>
	<ChartTabs @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<!-- 頁簽 -->
		<ul slot="tabs" class="nav nav-tabs card-header-tabs pull-right" role="tablist">
			<li class="nav-item">
				<a class="nav-link active" data-toggle="tab" href="#OverseasTradeVolTab1" role="tab" aria-controls="cusincome" aria-selected="true">圖</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" data-toggle="tab" href="#OverseasTradeVolTab2" role="tab" aria-controls="cusunincome" aria-selected="false">表</a>
			</li>
		</ul>
		<template slot="chart">
			<!-- 圖 -->
			<div id="OverseasTradeVolTab1" style="height: 100%" class="tab-pane fade show active" role="tabpanel" aria-labelledby="tab1-tab">
				<div ref="overseasTradeVolChart" style="height: 100%"></div>
			</div>
			<!-- 表 -->
			<div id="OverseasTradeVolTab2" class="tab-pane fade" role="tabpanel" aria-labelledby="tab2-tab" style="height: 100%;width: 100%;">
				<a @click="exportExcel" class="sidebar-brand d-flex align-items-end justify-content-end mb-2">
					<div class="sidebar-brand-icon">
						<img class="img-fluid" src="@/assets/img/excel.png" width="25" />
					</div>
				</a>
				<div class="table-responsive-sm" ref="overseasTradeVolTable" style="height: 90%;width: 100%;overflow-y: auto;">
					<table class="table table-bordered table-sm table-striped table-hover">
						<thead class="text-center">
							<tr>
								<th>月均交易量級距<br>(新台幣/元)</th>
								<th>全體戶數</th>
								<th>受眾戶數</th>
								<th>受眾戶數佔比(%)</th>
								<th>全體戶數佔比(%)</th>
								<th>受眾交易量佔比(%)</th>
							</tr>
						</thead>
						<tbody>
							<tr v-for="(data_, i) in data" v-bind:key="'taiex_trade_'+i">
								<td>{{data_.avgMonthlyTradVolCI}}</td>
								<td style="text-align: right;">{{data_.sampleAcct}}</td>
								<td style="text-align: right;">{{data_.targetAcct}}</td>
								<td style="text-align: right;">{{data_.targetActRatio}}</td>
								<td style="text-align: right;">{{data_.sampleActRatio}}</td>
								<td style="text-align: right;">{{data_.targetTxRatio}}</td>
							</tr>
						</tbody>
					</table>		
				</div>
			</div>
		</template>
	</ChartTabs>
</template>

<script type="ts" src="./OverseasTradeVolChart.ts"></script>