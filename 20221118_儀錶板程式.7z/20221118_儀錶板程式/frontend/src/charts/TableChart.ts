import { Component } from 'vue-property-decorator';
import ChartTabs from '@/charts/ChartTabs.vue';
import * as echarts from 'echarts';
import { DataUtils } from '@/commons/DataUtils';


@Component({
	components: {
		ChartTabs
	}
})
export default class TableChart extends ChartTabs {
	
	title: string;
	
	option: any;
	
	/**
	 * 建構子
	 */
	constructor() {
		super();
		this.title = '';
	}
	
	/**
	 * 顯示圖表modal
	 */
	showModal() {
		this.$store.commit('showChartModal', {
			'title': this.title,
			'option': this.option
		});
	}
	
	/**
	 * 開始繪圖
	 */
	draw() {
		console.log();
	}
}