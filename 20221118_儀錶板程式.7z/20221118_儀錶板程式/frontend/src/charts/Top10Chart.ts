import Chart from "@/charts/Chart.vue";
import { DataUtils } from '@/commons/DataUtils';
import { Component } from "vue-property-decorator";
import { NumberUtils } from '@/commons/utilities/number.utils';

@Component({
  components: {
    Chart,
  },
})
export default class Top10Chart extends Chart {
	
	title: string;
	
	data: any[];
	
	/**
	 * 建構子
	 */
	constructor() {
		super();
		this.title = "台股交易類股TOP 10";
		this.data = [];
	}
	
	/**
	 * 顯示圖表modal
	 */
	showModal() {
		this.$store.commit('showChartModal', {
			'title': this.title,
			'table': this.$refs.top10Table
		}); 
	}
	
	/**
	 * 開始繪圖
	 */
	draw() {
		new DataUtils(this).getData('/top10/', (data: any) => {
			this.data = data.data;
		});
	}
	
	formatNumber(num: string) {
		if (!num) {
			return '0';
		}
		return NumberUtils.commafy(num+'');
	}
	
	/**
	 * 匯出Excel
	 */
	exportExcel() {
		new DataUtils(this).download("/top10/exportExcel", this.data, this.title + '.xlsx');
	}
}