<template>
	<Chart @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<template slot="chart">
			<a @click="exportExcel" class="sidebar-brand d-flex align-items-end justify-content-end mb-2">
				<div class="sidebar-brand-icon">
					<img class="img-fluid" src="@/assets/img/excel.png" width="25" />
				</div>
			</a>
			<div class="table-responsive" ref="effectiveSignAcctTable" style="height: 90%;width: 100%;">
				<table class="table table-bordered table-sm table-striped table-hover">
					<thead class="text-center">
						<tr>
							<th>分群</th>
							<th>已有<br/>電子戶</th>
							<th>已有<br/>現股當沖簽屬</th>
							<th>已有<br/>出借簽署</th>
							<th>已有<br/>不限用途簽屬</th>
							<th>已有<br/>定期定額簽屬</th>
							<th>已有<br/>複委託帳戶</th>
							<th>已有<br/>期貨IB</th>
							<th>已有<br/>信用戶註記</th>
							<th>已有<br/>財管信託帳戶</th>
						</tr>
					</thead>
					<tbody>
						<tr v-for="(data_, i) in data" v-bind:key="i">
							<td style="text-align: center;">{{data_.groupName}}</td>
							<template v-if="i < data.length - 1">
								<td style="text-align: right;">{{formatNumber(data_.ecAcct)}}</td>
								<td style="text-align: right;">{{formatNumber(data_.dtSign)}}</td>
								<td style="text-align: right;">{{formatNumber(data_.bsblSign)}}</td>
								<td style="text-align: right;">{{formatNumber(data_.urulSign)}}</td>
								<td style="text-align: right;">{{formatNumber(data_.dcSign)}}</td>
								<td style="text-align: right;">{{formatNumber(data_.sbkAcct)}}</td>
								<td style="text-align: right;">{{formatNumber(data_.futIbAcc)}}</td>
								<td style="text-align: right;">{{formatNumber(data_.cdAcct)}}</td>
								<td style="text-align: right;">{{formatNumber(data_.wtFund)}}</td>
							</template>
							<template v-if="i == data.length - 1">
								<td style="text-align: right;">{{formatRatio(data_.ecAcct)}}</td>
								<td style="text-align: right;">{{formatRatio(data_.dtSign)}}</td>
								<td style="text-align: right;">{{formatRatio(data_.bsblSign)}}</td>
								<td style="text-align: right;">{{formatRatio(data_.urulSign)}}</td>
								<td style="text-align: right;">{{formatRatio(data_.dcSign)}}</td>
								<td style="text-align: right;">{{formatRatio(data_.sbkAcct)}}</td>
								<td style="text-align: right;">{{formatRatio(data_.futIbAcc)}}</td>
								<td style="text-align: right;">{{formatRatio(data_.cdAcct)}}</td>
								<td style="text-align: right;">{{formatRatio(data_.wtFund)}}</td>
							</template>
						</tr>
					</tbody>
				</table>		
			</div>
		</template>
	</Chart>
	
</template>

<script type="ts" src="./EffectiveSignAcctChart.ts"></script>