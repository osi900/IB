import ChartTabs from "@/charts/ChartTabs.vue";
import { DataUtils } from "@/commons/DataUtils";
import { NumberUtils } from "@/commons/utilities/number.utils";
import * as echarts from "echarts";
import { Component } from "vue-property-decorator";

@Component({
  components: {
    ChartTabs,
  },
})
export default class AgeChart extends ChartTabs {
  title: string;

  chart: any;

  option: any;

  data: unknown[];

  /**
   * 建構子
   */
  constructor() {
    super();
    this.title = "年齡層分布";
    this.chart = null;
    this.data = [];
  }

  /**
   * 顯示圖表modal
   */
  showModal() {
    this.$store.commit("showChartModal", {
      title: this.title,
      tabs: [
        { name: "年齡層分佈圖", option: this.option },
        { name: "年齡層分佈表", html: this.$refs.ageTable },
      ],
    });
  }

  /**
   * 開始繪圖
   */
  draw() {
    new DataUtils(this).getData("/age/", (data: any) => {
      this.createChart(data);
    });
  }

  createChart(data: any) {
    const conditions = this.$store.state.conditions;

    const allConditionKeys = Object.keys(conditions);

    allConditionKeys.splice(
      allConditionKeys.findIndex((ack) => ack == "snapYYYYMM"),
      1
    );
    console.log("allConditionKeys2: ", allConditionKeys);

    const noFilter = allConditionKeys.length === 0;

    const xLabel = [];
    const baseProporValue: number[] = [];
    const baseAcctCntVal: number[] = [];
    const targetProporValue = [];
    const targetAcctCntVal: number[] = [];
    let maxY = 0;
    //const yValue = [];
    this.data = data.data;
    for (let i = 0; i < data.data.length; i++) {
      if (noFilter) {
        data.data[i]["targetAcctCnt"] = 0;
        data.data[i]["targetProportion"] = 0;
      }

      const label = data.data[i]["label"];
      const baseAcctCnt = data.data[i]["baseAcctCnt"];
      const baseProportion = data.data[i]["baseProportion"];
      const targetAcctCnt = data.data[i]["targetAcctCnt"];
      const targetProportion = data.data[i]["targetProportion"];
      xLabel.push(label);
      baseAcctCntVal.push(baseAcctCnt);
      baseProporValue.push(baseProportion);
      targetProporValue.push(targetProportion);
      targetAcctCntVal.push(targetAcctCnt);
    }

    maxY = Math.max(...baseProporValue);

    if (!this.chart) {
      const el = this.$refs.ageChart as HTMLElement;
      this.chart = echarts.init(el);
    }

    this.option = {
      title: {},
      tooltip: {
        trigger: "axis",
        formatter: function (params: any) {
          let res = ""; /* 
						"<div style='margin-bottom:5px;padding:0 12px;width:100%;height:24px;line-height:24px;background:pink;border-radius:3px;'><p>" +
						params[0].name +
						" </p></div>"; */
          for (let i = 0; i < params.length; i++) {
            const isBase = i == 0;
            //console.log('isBase: ',isBase);
            //console.log('params[i].dataIndex: ',params[i].dataIndex);
            res += `<div style="color: #000;font-size: 14px; padding:0 6px;line-height: 24px">
			  
			  ${params[i].seriesName}<br/>
			  ${params[0].name}:
			  
			  ${
          isBase
            ? baseAcctCntVal[params[i].dataIndex]
            : targetAcctCntVal[params[i].dataIndex]
        } 人
			</div>`;
          }
          //console.log(res);
          return res;
        },
      },
      legend: {
        data: ["全體", "受眾"],
      },
      xAxis: {
        type: "category",
        data: xLabel,
      },
      yAxis: {
        type: "value",
        min: 0,
        max: maxY,
      },
      series: [
        {
          name: "全體",
          data: baseProporValue,
          type: "bar",
          label: {
            show: true,
          },
        },
        {
          name: "受眾",
          data: targetProporValue,
          type: "bar",
          label: {
            show: true,
          },
        },
      ],
    };

    this.chart.setOption(this.option);

    window.addEventListener("resize", this.resizeTheChart);
  }

  resizeTheChart() {
    if (this.chart) {
      this.chart.resize();
    }
  }

  formatNumber(num: string) {
    if (!num) {
      return "0";
    }
    return NumberUtils.commafy(num + "");
  }

	/**
	 * 匯出Excel
	 */
	exportExcel() {
		new DataUtils(this).download("/age/exportExcel", this.data, this.title + '.xlsx');
	}
}
