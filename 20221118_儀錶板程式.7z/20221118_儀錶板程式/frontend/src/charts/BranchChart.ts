import Chart from "@/charts/Chart.vue";
import { DataUtils } from "@/commons/DataUtils";
import * as echarts from "echarts";
import { Component } from "vue-property-decorator";

@Component({
  components: {
    Chart,
  },
})
export default class BranchChart extends Chart {
  title: string;

  chart: any;

  option: any;

  /**
   * 建構子
   */
  constructor() {
    super();
    this.title = "分公司分布";
    this.chart = null;
  }

  /**
   * 顯示圖表modal
   */
  showModal() {
    this.$store.commit("showChartModal", {
      title: this.title,
      option: this.option,
    });
  }

  /**
   * 開始繪圖
   */
  draw() {
    new DataUtils(this).getData("/branch/", (data: any) => {
      const datas = [];
      for (let i = 0; i < data.data.length; i++) {
        const data_ = {
          name: data.data[i]['branchName'],
          value: data.data[i]['count']
        }
        datas.push(data_);
      }

      if (!this.chart) {
        const el = this.$refs.branchChart as HTMLElement;
        this.chart = echarts.init(el);
      }
      const formatUtil = echarts.format;
      this.option = {
        tooltip: {
          formatter: function (info: any) {
            //console.log(info)
            const value = info.value;
            const treePathInfo = info.treePathInfo;
            const treePath = [];
            for (let i = 1; i < treePathInfo.length; i++) {
              treePath.push(treePathInfo[i].name);
            }
            return [
              '<div class="tooltip-title">' +
                formatUtil.encodeHTML(treePath.join('/')) +
                '</div>',
              '客戶: ' + formatUtil.addCommas(value) + ' 戶'
            ].join('');
          }
        },
        series: [
          {
            type: "treemap",
            roam: false,
            label: {
              show: true,
              formatter: "{b}",
            },
            breadcrumb: {
              show: false,
            },
            silent: false,
            nodeClick: false,
            data: datas,
          },
        ],
      };

      this.chart.setOption(this.option);
      window.addEventListener('resize', this.resizeTheChart);
    });
  }

  resizeTheChart() {
    if (this.chart) {
      this.chart.resize()
    }
  }
}

/* 
{
  "data": [
    { "branchName": "竹東分公司", "count": 4 },
    { "branchName": "左營分公司", "count": 4 },
    { "branchName": "竹北分公司", "count": 3 },
    { "branchName": "羅東分公司", "count": 2 },
    { "branchName": "內湖分公司", "count": 2 },
    { "branchName": "員林分公司", "count": 2 },
    { "branchName": "仁愛分公司", "count": 1 },
    { "branchName": "嘉義分公司", "count": 1 },
    { "branchName": "台北分公司", "count": 1 }
  ]
}
*/
