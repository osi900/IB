import ChartTabs from "@/charts/ChartTabs.vue";
import { DataUtils } from "@/commons/DataUtils";
import { Component } from "vue-property-decorator";
import { NumberUtils } from '@/commons/utilities/number.utils';
import * as echarts from "echarts";

/**
 * 產品貢獻度分布
 */
@Component({
	components: {
		ChartTabs,
	},
})
export default class ProdContributionChart extends ChartTabs {
	
	chartSpan: number;
	
	title: string;

	chart: any;

	option: any;

	data: unknown[];
	/**
	 * 建構子
	 */
	constructor() {
		super();
		this.chartSpan = 2;
		this.title = "產品貢獻度分布";
		this.chart = null;
		this.data = [];
	}

	/**
	 * 顯示圖表modal
	 */
	showModal() {
		this.$store.commit("showChartModal", {
			title: this.title,
			tabs: [
				{ name: "圖", option: this.option },
				{ name: "表", html: this.$refs.prodContributionTable },
			],
		});
	}

	/**
	 * 開始繪圖
	 */
	draw() {
		new DataUtils(this).getData("/prod_contribute/", (data: any) => {
			if (data) {
				const commodityProduct: Record<string, any> = {
					cateName: '經紀商品',
					cateBgColor:'bg-warning',
					prodBgColor:'table-warning',
					productNames: [
						"台股",
						"定期定額",
						"信用",
						"不限用途",
						"通路介入",
						"期貨",
					],
					datas: [],
					targetData: [],
					rowSpan: 1
				};
				
				
				const finMgmProduct: Record<string, any> = {
					cateName: '財管商品',
					cateBgColor:'bg-success',
					prodBgColor:'table-success',
					productNames: ["海外股", "基金", "海外債", "結構型", "保險"],
					datas: [],
					targetData: [],
					rowSpan: 1
				};
				
				let maxY = 0;
				const accts: number[] = [];
				const targetAccts: number[] = [];
				
				for (let i = 0; i < data.data.length; i++) {
					const dat = data.data[i];
					const prodName = dat["product"];
					
					// 全體
					accts.push(dat['accountCnt']);
					if (commodityProduct.productNames.includes(prodName)) {
						commodityProduct.datas.push(dat);
					}
					if (finMgmProduct.productNames.includes(prodName)) {
						finMgmProduct.datas.push(dat);
					}
					
					// 受眾
					if (data.targetData) {
						targetAccts.push(data.targetData[i]['accountCnt']);
						if (commodityProduct.productNames.includes(prodName)) {
							commodityProduct.targetData.push(data.targetData[i]);
						}
						if (finMgmProduct.productNames.includes(prodName)) {
							finMgmProduct.targetData.push(data.targetData[i]);
						}
					} else {
						targetAccts.push(0);
						commodityProduct.targetData.push(0);
						finMgmProduct.targetData.push(0);
					}
					
				}
				commodityProduct.rowSpan = commodityProduct.datas.length;
				finMgmProduct.rowSpan = finMgmProduct.datas.length;
				
				if (!this.chart) {
					const el = this.$refs.prodContributionChart as HTMLElement;
					this.chart = echarts.init(el);
				}
				maxY = Math.max(...accts, ...targetAccts);
				const xLabel: string[] = [...commodityProduct.productNames, ...finMgmProduct.productNames];
				const allData: any[] = [...commodityProduct.datas, ...finMgmProduct.datas];
				const allTargetData: any[] = [...commodityProduct.targetData, ...finMgmProduct.targetData];
				
				this.option = {
					title: {},
					tooltip: {
						trigger: "axis",
						formatter: function (params: any) {
							let res = '';
							for (let i = 0; i < params.length; i++) {
								if (i == 0) {
									const dt = allData.find(d => d['product'] == params[i].name);
									res += `<div style="color: #000;font-size: 14px; padding:0 6px;line-height: 24px">
			  							${params[i].seriesName} (${params[i].name})<br/>
										戶數: <strong>${dt['accountCnt']}</strong>戶<br/>
										年累貢獻度(新台幣/千元): <strong>${dt['contributionYearly']}</strong><br/>
										戶均貢獻度佔比: <strong>${dt['contributionMonthAvg']}</strong><br/>
									</div><br/>`;
									
								} else {
									const dt = allTargetData.find(d => d['product'] == params[i].name);
									res += `<div style="color: #000;font-size: 14px; padding:0 6px;line-height: 24px">
			  							${params[i].seriesName} (${params[i].name})<br/>
										戶數: <strong>${dt['accountCnt']}</strong>戶<br/>
										年累貢獻度(新台幣/千元): <strong>${dt['contributionYearly']}</strong><br/>
										戶均貢獻度佔比: <strong>${dt['contributionMonthAvg']}</strong>
									</div>`;
								}
								
							}
							return res;
						},
					},
					legend: {
						data: ["全體", "受眾"],
					},
					xAxis: {
						type: "category",
						data: xLabel,
					},
					yAxis: {
						type: "value",
						min: 0,
						max: maxY,
					},
					series: [
						{
							name: "全體",
							data: accts,
							type: "bar",
							label: {
								show: true,
							},
						},
						{
							name: "受眾",
							data: targetAccts,
							type: "bar",
							label: {
								show: true,
							},
						},
					],
				};
				
				this.chart.setOption(this.option);

				this.data = [commodityProduct, finMgmProduct];
				window.addEventListener('resize', this.resizeTheChart);
			}
		});
	}

	resizeTheChart() {
		if (this.chart) {
			this.chart.resize()
		}
	}

	formatFloat(num: string, pt: number) {
		if (!num) {
			num = '0';
		}
		return (parseFloat(num)).toFixed(pt);
	}

	formatNumber(num: string) {
		if (!num) {
			return '0';
		}
		return NumberUtils.commafy(num+'');
	}
	
	/**
	 * 匯出Excel
	 */
	exportExcel() {
		new DataUtils(this).download("/prod_contribute/exportExcel", this.data, this.title + '.xlsx');
	}
}
