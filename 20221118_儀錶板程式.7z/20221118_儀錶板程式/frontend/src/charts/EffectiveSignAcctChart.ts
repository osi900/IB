import Chart from "@/charts/Chart.vue";
import { DataUtils } from '@/commons/DataUtils';
import { Component } from "vue-property-decorator";
import { NumberUtils } from '@/commons/utilities/number.utils';

@Component({
  components: {
    Chart,
  },
})
export default class EffectiveSignAcctChart extends Chart {
	
	title: string;
	
	data: any[];
	
	/**
	 * 建構子
	 */
	constructor() {
		super();
		this.title = "各項業務有效簽署戶數";
		this.data = [];
	}
	
	/**
	 * 顯示圖表modal
	 */
	showModal() {
		this.$store.commit('showChartModal', {
			'title': this.title,
			'table': this.$refs.effectiveSignAcctTable
		}); 
	}
	
	/**
	 * 開始繪圖
	 */
	draw() {
		new DataUtils(this).getData('/effectiveSignAcct/', (data: any) => {
			this.data = data.data;
		});
	}
	
	formatNumber(num: string) {
		if (!num) {
			return '0';
		}
		return NumberUtils.commafy(num+'');
	}
	
	formatRatio(num: string) {
		return (parseFloat(num) * 100).toFixed(2);
	}
	
	/**
	 * 匯出Excel
	 */
	exportExcel() {
		new DataUtils(this).download("/effectiveSignAcct/exportExcel", this.data, this.title + '.xlsx');
	}
}