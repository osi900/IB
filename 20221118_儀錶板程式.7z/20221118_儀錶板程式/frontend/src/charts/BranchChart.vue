<template>
	<Chart @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<div ref="branchChart" slot="chart" style="height: 100%"></div>
	</Chart>
</template>

<script type="ts" src="./BranchChart.ts"></script>