import zhTWMessages from './messages/zh_TW'

export const zhTW = zhTWMessages