import { PageBaseComponent } from '@/components/PageBaseComponent';
import * as echarts from 'echarts';
import $ from 'jquery';
import { Component } from 'vue-property-decorator';

@Component({})
export default class ChartModal extends PageBaseComponent {
	
	title: string;
	
	charts: any;
	
	info: any;
	
	tabIdx: number;
	
	constructor() {
		super();
		this.title = '';
		this.info = {};
		this.charts = [];
		this.tabIdx = 0;
	}
	
	show(title: string, info: any) {
		this.title = title;
		this.info = info;
		this.charts = [];
		this.tabIdx = 0;
		
		if (info.tabs) {
			for (let i = 0; i < info.tabs.length; i++) {
				$('#Tab_'+i + ' div').empty();
			}
		}
		
		($(this.$el) as any).on('shown.bs.modal', () => {
			($(this.$el) as any).off('shown.bs.modal');
			$(this.$el).find('a[data-toggle="tab"]').off("shown.bs.tab");
			
			if (info.tabs) { // 有頁籤
				for (let i = 0; i < info.tabs.length; i++) {
					if (info.tabs[i].option) {
						if (!this.charts[i]) {
							const el = $('#Tab_'+i + ' div')[0];
							this.charts[i] = echarts.init(el);
						}
						this.charts[i].setOption(info.tabs[i].option);
					} else {
						$('#Tab_'+i + ' div').append(info.tabs[i].html.innerHTML);
					}
				}
				
				// 切換tab，重畫
				$(this.$el).find('a[data-toggle="tab"]').on("shown.bs.tab", (event) => {
					const currentTabId = $(event.target).attr("tab-id");
					const idx = currentTabId!.replace('Tab_', '');
					
					$('#Tab_'+idx).empty();
					$('#Tab_'+idx).append('<div style="height: 100%"/>');
					if (info.tabs[idx].option) {
						const el = $('#Tab_'+idx + ' div')[0];
						this.charts[idx] = echarts.init(el);
						this.charts[idx].setOption(info.tabs[idx].option);
					} else {
						$('#Tab_'+idx + ' div').append(info.tabs[idx].html.innerHTML);
					}
				});
			} else if (info.table) { // 資料為table格式
				$('#chart').empty();
				$('#chart').append('<div style="width:100%; min-width: 100%; height:400px;"/>');
				$('#chart div').append(info.table.innerHTML);
				
			} else { // 資料為圖形格式
				$('#chart').empty();
				$('#chart').append('<div style="width:100%; min-width: 100%; height:400px;"/>');
				if (!this.charts[0]) {
					const el = $('#chart div')[0];
					this.charts[0] = echarts.init(el);
				}
				this.charts[0].setOption(info.option);
			}
			($(this.$el) as any).off('shown.bs.modal');
			
			
		});
		($(this.$el) as any).modal('show');
		
		
	}
	
}