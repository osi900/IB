<template>
	<div id="app">
		<router-view />
		
		<!-- 
		<footer class="sticky-footer bg-white">
			<div class="container my-auto">
				<div class="copyright text-center my-auto">
					<span>{{ $t('home.copyright') }}</span>
				</div>
			</div>
		</footer>
		 -->
		<div id="loading" v-if="$store.state.showLoading">
			<div class="fa fa-spinner fa-spin fa-3x"></div>
		</div>
	</div>
</template>

<style scoped>
/*
#app {
	font-family: Avenir, Helvetica, Arial, sans-serif;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	text-align: center;
	color: #2c3e50;
}

nav {
	padding: 30px;
}

nav a {
	font-weight: bold;
	color: #2c3e50;
}

nav a.router-link-exact-active {
	color: #42b983;
}
*/

#loading {
	position: fixed;
	top: 0;
	left: 0;
	z-index: 1050;
	width: 100%;
	height: 100%;
	overflow: hidden;
	outline: 0;
	background-color: #0005;
}

#loading .fa-spinner {
	position: absolute;
	top: 50%;
	left: 50%;
}

</style>
