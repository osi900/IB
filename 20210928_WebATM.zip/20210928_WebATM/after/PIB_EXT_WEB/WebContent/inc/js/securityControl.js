//EXT version 1.0
//--------------------------------------------------------------------
(function() {
	String.prototype.startsWith = function(str) {
	var reg = new RegExp("^" + str);
	return reg.test(this);
	};
})();
/**
 * 取得頁面中的元件
 */
function getSecurityControlObject(){
	return ATLActiveXControl;
	
}
//--------------------------------------------------------------------
/**
 * 顯示錯誤訊息 
 */
function showScMsg(msgKey, rc) {
	
	//"ox" + rHex + "產生晶片卡交易驗證碼失敗！"
	var resultMsg = '';
	if (arguments.length == 2) {
		resultMsg = "ox" + rc + ' ';			
	}
	var msg = scMsg.validationMsgs[msgKey];
	if(!msg){
		msg = '';
	}		

	
	if(rc){
		var aeMsg = '';
		if('string' == typeof rc && rc.length > 4){
			rc = rc.substring(rc.length - 4);
		}
		var aeMsg = scMsg.ActiveXErrorMessages[rc];
		
		//這兩個rc特別處理
		if(rc == '1203' || rc == '1206') {
			//您的晶片金融卡密碼輸入錯誤已達三次並鎖定，請本人攜帶身分證、晶片金融卡、原留印鑑洽各分行辦理解除鎖定！
			//晶片金融卡密碼輸入錯誤，密碼錯誤三次將鎖定
			resultMsg = resultMsg + aeMsg;
			
		}		
	}

	resultMsg = resultMsg + msg;
	
	alert(resultMsg);
}
//--------------------------------------------------------------------
/**
 * 顯示錯誤訊息 
 */
function showScMsgOld(msgKey, rc) {
	var msg = scMsg.validationMsgs[msgKey];
	if(!msg){
		msg = '';
	}
	if(rc){
		if('string' == typeof rc && rc.length > 4){
			rc = rc.substring(rc.length - 4);
		}
		var aeMsg = scMsg.ActiveXErrorMessages[rc];
		msg += rc + ' ' + ( msg && aeMsg ? ", " : "") + (aeMsg ? aeMsg : '');
	}
	alert(msg);
}
//--------------------------------------------------------------------
/**
 * 目前瀏覽器是否支援元件
 */
function isSupportSecurityControl(){
	if($.browser.mobile){
		return false;
	} else if(navigator.platform.match(/^Win(32|64)$/)) {
		if(isIE()){
			var supported = false;
	        try {
	        	// ActiveXObject 被關掉了
	            supported = !!new ActiveXObject("htmlfile");
	        } catch (e) {
	            supported = false;
	        }
	        return supported;
		} else {
			//windows, not IE
			return true;
		}
	} else if(navigator.platform.match(/^MacIntel$/)){
		// Mac OS, check version
		if(navigator.userAgent.match(/Intel Mac OS X/)){
			var versionStr = navigator.userAgent.match(/Intel Mac OS X (\d+_\d+)/)[1].split('_');
			var major = parseInt(versionStr[0]);
			var minor = parseInt(versionStr[1]);
			if(isNaN(major) || major < 10 || (major == 10 && minor < 5) ) {
				// parse error or less than 10.5
				return false;
			}
			return true;
		}
		// check failed, return false
		return false;
	}
	// finally, return false if i don't know you
	return false;
}
//--------------------------------------------------------------------
/**
 * 是否為二代讀卡機
 * @param readerName 
 * @returns {Boolean}
 */
function is2ndGeneration(readerName) {
	for(var i = 0; i < scData.nextGenerationReaderList.length; i++) {
		var ngr = scData.nextGenerationReaderList[i];
		if(readerName.indexOf(ngr) >= 0) {
			return true;
		}
	}
	return false;
}
//--------------------------------------------------------------------
/**
 * 初始化讀卡機 卡片
 * @param readerList (讀卡機html element 的 id)
 * @param accountList (晶片卡卡號/帳號 html element 的 id)
 * @param throwError
 * @param pinField  (pin html element 的 id, 前面要加上#, ex '#pin')
 * @param buttonText (確認鈕 html element 的 value)
 * @param uiType (畫面類型 不傳入或'' = b2c 標準畫面, 'webatm'=網路ATM) 
 * @param notDetectInstall
 */
function initReaderList(readerList, accountList, throwError, pinField, buttonText, uiType, notDetectInstall, readerCount, efData) {

	if(typeof readerList == 'string') {
		readerList = $('#' + readerList.replace(/:/g,'\\:'));
	}
	if(typeof accountList == 'string') {
		accountList = $('#' + accountList.replace(/:/g,'\\:'));
	}
	if(typeof pinField == 'string') {
		pinField = $('#' + pinField.replace(/:/g,'\\:'));
	}
	var $pinField = $(pinField);
	var $parentPopupCom = readerList.parents('div.popup_com');
	//清空讀卡機, 卡號帳號 下拉選單
	readerList.find('option').remove();
	accountList.find('option').remove();
	
	// detect install
	if (notDetectInstall == undefined || notDetectInstall == false) {
		
		var result = detectInstall();
		if(!result){
			if($parentPopupCom.size() > 0) {
				$parentPopupCom.css('z-index', 1010);
			} else {
				cleanMask();
			}
			return false;
		}		
	}

	
	var scObj = getSecurityControlObject();
	
	//----------------------------------
	//列出目前所有連接的讀卡機，如果有過安裝但未連接上系統時並未列出。
	var rc = 0;
	// 若有傳入 readerCount, 則不需要再抓一次
	if(!readerCount) {
		scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，ListReaders()前不DisconnectCard()會讀卡失敗
		rc = scObj.ListReaders();
		//----------------------------------
		//不等於0, 為失敗
		if(rc!=0){
			showScMsg('please.connect.card.reader', toHex(rc));
			return false;
		}
		//------------------------------------------------------
		//回傳讀卡機個數。必須先執行ListReaders。  >0 成功，讀卡機的個數。 -1讀卡機不存在。
		readerCount = scObj.GetReaderNumber();
		if(readerCount < 0 ){
			showScMsg('please.connect.card.reader');
			return false;
		}
	}
	//----------------------------------
	// generate list and check card issuser
	var isTFB = -1;
	try {
		for(var i=0;i<readerCount;i++) {
			
			// get first reader name  回傳讀卡機名稱。
			var readerName = scObj.GetReaderName(i);
			var hasError = false;
			if(!readerName){
				showScMsg('detect.card.reader.failed');
				return false;
			}
			
			//產生讀卡機下拉選單
			$opt = $('<option value="' + readerName + '">' + readerName + '</option>');
			$(readerList).append($opt);
			
			//連接讀卡機
			rc = scObj.ConnectReader(readerName);
			if(rc!=0) {
				if(throwError){			
					showScMsg('connect.card.reader.failed', toHex(rc));
					throw new Error('connect.card.reader.failed');
				} else {
					hasError = true;
				}
			}
			
			//連接指定的IC卡與應用程式之間的連結
			rc = scObj.ConnectCard(readerName);
			if(rc!=0) {
				if(throwError) {
					showScMsg('read.card.failed', toHex(rc));
					throw new Error('read.card.failed');
				} else {
					hasError = true;
				}
			}
			
			//取得 發卡單位代碼
			var issuerBank =  scObj.GetIssuerBank() ;
			if(!issuerBank) {
				if(throwError) {
					showScMsg('get.issuer.failed');
					throw new Error('get.issuer.failed');
				} else {
					hasError = true;
				}
			} else if(issuerBank.match(/^012[0-9]{5}$/) && isTFB < 0){
				isTFB = i;
			}
			if(isTFB == i) {
				$opt.attr('selected','selected');
			}
			if(!hasError){
				// 目前帳號列表仍是空的, 或是目前讀卡機中的卡片是富邦卡, 需抓出帳號組成帳號列表
				if($(accountList).find('option').size() == 0 || isTFB == i){
					reloadAccountList(readerName, accountList, false, pinField, buttonText, uiType);
					if (efData != undefined) {
						if(efData.success){
							getCardEFDataWithConnected(efData, rc, scObj);
						}						
					}
				}
			}
			scObj.DisconnectCard(readerName);
			//scObj.DisconnectReader(readerName);
			scObj.ConnectCard(readerName);	// add by Sky@WebComm, 交易結束後恢復獨佔模式
		}
	} catch(err) {
		$.log('error',err);
	} finally {
		if($(readerList).data("selectBox-selectBoxIt")) {
			$(readerList).data("selectBox-selectBoxIt").refresh();
		}
		if($(accountList).data("selectBox-selectBoxIt")) {
			$(accountList).data("selectBox-selectBoxIt").refresh();
		}
		setupComboWidth();
	}
	
	setupPinFieldFor2nd($(readerList).val(), $pinField, buttonText, uiType);
	return true;
}
//--------------------------------------------------------------------
/**
 * 重新載入 帳戶/卡號 (Ex :for 重選讀卡機....)
 * @param readerName (讀卡機html element 的 id)
 * @param accountList (晶片卡卡號/帳號 html element 的 id)
 * @param needConnectCard 是否需要連接 晶片卡
 * @param pinField  (pin html element 的 id, 前面要加上#, ex '#pin')
 * @param buttonText (確認鈕 html element 的 value)
 * @param uiType (畫面類型 不傳入或'' = b2c 標準畫面, 'webatm'=網路ATM) 
 */
function reloadAccountList(readerName, accountList, needConnectCard, pinField, buttonText, uiType){
	
	if(typeof accountList == 'string') {
		accountList = $('#' + accountList.replace(/:/g,'\\:'));
	}
	if(typeof pinField == 'string') {
		pinField = $('#' + pinField.replace(/:/g,'\\:'));
	}
	var $pinField = $(pinField);
	var $parentPopupCom = $(accountList).parents('div.popup_com');
	
	//清空 卡號/帳號 下拉選單
	$(accountList).find('option').remove();
	if($(accountList).data("selectBox-selectBoxIt")) {
		$(accountList).data("selectBox-selectBoxIt").refresh();
	}
	
	var scObj = getSecurityControlObject();
	var rc = 0;
	if(needConnectCard) {
		if($parentPopupCom.size() > 0) {
			$parentPopupCom.css('z-index', 999);
		} else {
			screenMask();
		}
		setupPinFieldFor2nd(readerName, $pinField, buttonText, uiType);
		rc = scObj.ConnectReader(readerName);
		if(rc!=0){
			showScMsg('connect.card.reader.failed', toHex(rc));
			if($parentPopupCom.size() > 0) {
				$parentPopupCom.css('z-index', 1010);
			} else {
				cleanMask();
			}
			return false;
		}
		rc = scObj.ConnectCard(readerName);
		if(rc!=0){
			showScMsg('read.card.failed', toHex(rc));
			if($parentPopupCom.size() > 0) {
				$parentPopupCom.css('z-index', 1010);
			} else {
				cleanMask();
			}
			return false;
		}
	}

	rc = scObj.ListEF1001Accounts();
	if(rc!=0) {
		showScMsg('get.account.list.failed', toHex(rc));
		return false;
	}
	var acctCount = scObj.GetEF1001TotalAccounts();
	if(acctCount < 0) {
		showScMsg('get.account.list.failed', toHex(rc));
		return false;
	}
	for(var j = 0;j<acctCount;j++) {
		var accountNo = scObj.GetEF1001Account(j);
		if(!accountNo) {
			showScMsg('get.account.list.failed', toHex(rc));
			return false;
		}
		$(accountList).append('<option value="' + accountNo + '">' + accountNo + '</option>');
	}
	if(needConnectCard){
		scObj.DisconnectCard(readerName);
		scObj.ConnectCard(readerName);	// add by Sky@WebComm, 交易結束後恢復獨佔模式
		//scObj.DisconnectReader(readerName);
		if($(accountList).data("selectBox-selectBoxIt")) {
			$(accountList).data("selectBox-selectBoxIt").refresh();
		}
		setupComboWidth();
		if($parentPopupCom.size() > 0) {
			$parentPopupCom.css('z-index', 1010);
		} else {
			cleanMask();
		}
	}
}
//--------------------------------------------------------------------
/**
 * 設定pin 欄位 是否顯示
 * 一代讀卡機 要顯示輸入
 * 二代讀卡機 不顯示 (直接由讀卡機輸入)
 * 
 * @param readerName 讀卡機名稱
 * @param $pinField
 * @param buttonText (確認鈕 html element 的 value)
 * @param uiType (畫面類型 不傳入或'' = b2c 標準畫面, 'webatm'=網路ATM)
 * 
 */
function setupPinFieldFor2nd(readerName, $pinField, buttonText, uiType) {
	
	if (uiType == 'webatm') {
		if (is2ndGeneration(readerName)) {
			$('#readerG1').hide();	
			$('#readerG2').show();
		} else {
			$('#readerG1').show();	
			$('#readerG2').hide();
		}
	} else {
		var $pinTD = $pinField.parent();
		
		if (is2ndGeneration(readerName)) {
			//二代讀卡機
			//把按鈕置換為 text
			var is2ndMsg = scMsg.validationMsgs['2nd.gen.notice'].replace(/%BUTTON_TEXT%/, buttonText);
			$pinTD.children().hide();
			var span2ndMsg = $pinTD.find('.is2nd_msg');
			if(span2ndMsg.size() == 0) {
				$pinField.before('<span id="is2nd_msg" class="txt-green">' + is2ndMsg + '</span>');
			} else {
				span2ndMsg.show();
			}
		} else {
			//一代讀卡機
			$pinTD.children().hide();
			$pinField.show().parent();
			$pinTD.find('.kbtn2').show();
		}		
	}
}
//--------------------------------------------------------------------
/**
 * 取得ICCard驗證用的 cardInfo
 * @param readerList
 * @param accountList
 * @param pinVal
 * @param resultInput
 */
function accessCardInfo(readerList, accountList, pinVal, resultInput, allowNonTFBCard){
	if(typeof readerList == 'string') {
		readerList = $('#' + readerList.replace(/:/g,'\\:'));
	}
	if(typeof accountList == 'string') {
		accountList = $('#' + accountList.replace(/:/g,'\\:'));
	}
	if(typeof resultInput == 'string') {
		resultInput = $('#' + resultInput.replace(/:/g,'\\:'));
	}
	var readerName = $(readerList).val();
	var scObj = getSecurityControlObject();
	var rc = 0;
	rc = scObj.ConnectReader(readerName);
	if(rc!=0){
		showScMsg('connect.card.reader.failed', toHex(rc));
		return false;
	}
	rc = scObj.ConnectCard(readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		return false;
	}
	//IC卡驗證密碼。密碼格式為6~12位數字。
	if(is2ndGeneration(readerName)){
		rc = scObj.VerifyPINSnd();
	} else {
		rc = scObj.VerifyPIN(pinVal);
	}
	if(rc!=0){
		showScMsg('', toHex(rc));
		return false;
	}
	//$(pin).val('');
	var resultObj = {'readerName':readerName};
	resultObj.allowNonTFBCard = allowNonTFBCard;
	getCardInfoForAuth(resultObj);
	if(resultObj.success){
		resultObj.respData = 'p;;p;;0:' + $(accountList).val() + ';;' + (new Date()).getTime();
	}
	$(resultInput).val($.toJSON(resultObj));
	return resultObj.success;
}
//--------------------------------------------------------------------
/**
 * WebATM 登入
 * 一代機 verifypin 後 發查餘額
 * 二代機 直接發查餘額
 * 
 * @param readerList
 * @param accountList
 * @param pinValue
 * @param resultInput 存放結果
 * @param taskId caller's taskId
 * @param
 */
function doLoginWebATM(readerList, accountList, pinValue, resultInput, taskId, icCardSN){
	return doOverageQuery(readerList, accountList, pinValue, resultInput, false, taskId, false, icCardSN);
}

/**
 * 發查餘額
 * 一代機 視needVerify 決定是否需要驗證pin後 發查餘額
 * 二代機 直接發查餘額
 * 
 * @param readerList
 * @param accountList
 * @param pinValue
 * @param resultInput
 * @param needVerify  是否需要驗證pin
 * @param taskId
 * @param checkSameCard 是否檢核同一張卡片
 * @returns
 */
function doOverageQuery(readerList, accountList, pinValue, resultInput, needVerify, taskId, checkSameCard, icCardSN){
	
	if(typeof readerList == 'string') {
		readerList = $('#' + readerList.replace(/:/g,'\\:'));
	}
	if(typeof accountList == 'string') {
		accountList = $('#' + accountList.replace(/:/g,'\\:'));
	}

	if(typeof resultInput == 'string') {
		resultInput = $('#' + resultInput.replace(/:/g,'\\:'));
	}
	
	var readerName = $(readerList).val();
	var accountId = $(accountList).val();
	var scObj = getSecurityControlObject();
	var rc = 0;
	
	var result = '';
	//----------------------------------
	rc = scObj.ConnectReader(readerName);
	if(rc!=0){
		showScMsg('connect.card.reader.failed', toHex(rc));
		result.success = false;
		return result;
	}
	//----------------------------------
	rc = scObj.ConnectCard(readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		result.success = false;
		return result;
	}
	//----------------------------------
	var icCardRemark = scObj.GetICCRemark();
	if(!icCardRemark){
		showScMsg('get.icc.memo.failed');
		result.success = false;
		return result;
	}	
	
	var issuerBank =  scObj.GetIssuerBank() ;
	if(!issuerBank) {
		showScMsg('get.issuer.failed');
		result.success = false;
		return result;
	}
	
	var EF0001SerialNo = '';
	if (issuerBank == '01200000') {
	    rc = scObj.QuiryEF0001();
	    if(rc != 0) {
	    	showScMsg('read.card.failed', toHex(rc));
	    	result.success = false;
	    	return;
	    } else {
	    	EF0001SerialNo = scObj.GetEF0001SerialNo();
	    }		
	}
    
	//----------------------------------
	//取得約定帳號 
	var eF1002AccountString = '';
	rc = scObj.ListEF1002Accounts();
	if(rc!=0) {
		showScMsg('get.account.list.failed', toHex(rc));
		return false;
	}	
	var acctCount = scObj.GetEF1002TotalAccounts();
	
	//沒有約定帳號的卡片 acctCount < 0, 不alert錯誤 往下作
	if(acctCount >= 0) {
		for(var j = 0;j<acctCount;j++) {
			var accountNo = scObj.GetEF1002Account(j);
			if(!accountNo) {
				showScMsg('get.account.list.failed', toHex(rc));
				return false;
			}
			eF1002AccountString = eF1002AccountString + accountNo;
			if (j < (acctCount -1)) {
				eF1002AccountString = eF1002AccountString + ';';
			}
		}
	}		 
	//----------------------------------
	var CardSerialNo = scObj.ReadCardSN();
	//----------------------------------
	var termData = getTermData(taskId);
	//----------------------------------
	
	if (checkSameCard) {
		var efDataInfo = getCardEFData(readerName);

		result = efDataInfo.success;	
		icCardSN = efDataInfo.efData;
		if(!result) {
			result.success = false;
			return result;
		}					
	}
		
	//----------------------------------
	var hsResult = doHandShake(taskId);			
	if(!hsResult) {
		result.success = false;
		return result;
	}
	var SessionKeyHash = hsResult.sessionKeyHash;				//Session Key Hash值
	var CpukEncSessionKey = hsResult.encSessionKey;				//被公開金鑰加密之SessionKey		
	
	//alert('SessionKeyHash:' + SessionKeyHash);
	//alert('CpukEncSessionKey:' + CpukEncSessionKey);
	//alert('termData.termChkCode:' + termData.termChkCode);	
	//alert(readerName);
	//alert($(accountList).val());
	
	//IC卡驗證密碼。密碼格式為6~12位數字。
	if(is2ndGeneration(readerName)){
		//alert('二代讀卡機');
		//直接發查餘額		
		rc = scObj.AccountInquirySndEx3(
				readerName, 
				'2500', 
				termData.termChkCode, 
				accountId,  
				CardSerialNo, 
				0,  
				SessionKeyHash, 
				CpukEncSessionKey);
		if(rc!=0){
			showScMsg('bho.cratetac.error', toHex(rc));
			result.success = false;
			return result;
		}
		
	} else {

		// 是否需要做驗證pin
		if(needVerify){

			var verify = 0;
			try {
				verify = scObj.VerifyPIN (pinValue);					
			} catch(e) {
				alert('Exception:' + e.message);
			}
			
			if(verify != 0){							
				showScMsg('', toHex(verify));
				return false;	
			} 		
		}
		
		//發查餘額
		rc = scObj.AccountInquiryEx3 (
									readerName, 
									'2500', 
									termData.termChkCode, 
									accountId,  
									pinValue,
									CardSerialNo, 
									0, 
									'', 
									0,  
									SessionKeyHash, 
									CpukEncSessionKey);		
				
		if(rc!=0){
			//bho.cratetac.error
			showScMsg('', toHex(rc));
			result.success = false;
			return result;
		}
	}

	var resultObj = {
			'success' : true,
			'acctNo' : accountId,
			'readerName' : readerName,
			'readerType' : is2ndGeneration(readerName) ? '2' : '1',
			'respSNUM' : scObj.GetRespSNUM(),
			'respData' : scObj.GetRespData(),
			'icCardRemark' : icCardRemark,
			'termNo' : termData.termNo,
			'termChkCode' : termData.termChkCode,
			'issuerBank' : issuerBank,
			'eF1002AccountString' : eF1002AccountString,
			'icCardSN' : icCardSN,
			'EF0001SerialNo' : EF0001SerialNo
	};	
	//----------------------------------
	$(resultInput).val($.toJSON(resultObj));
	
	return resultObj;
}
//--------------------------------------------------------------------
/**
 * 偵測是否已安裝元件
 * (由安裝頁呼叫時會傳入 flag = true)
 */
function isInstall(){
	var installed = false;
	var scObj = getSecurityControlObject();
	apiVersion = scObj.GetInstall();
	if(apiVersion.startsWith("-")){
		return installed;
	}
	if(scObj && apiVersion!=null){
		installed = true;
	}
	return installed;
}
var isCME = /EXT\/common\/CME/.test(parent.location.href);
//--------------------------------------------------------------------
/**
 * 偵測是否已安裝元件
 * (由安裝頁呼叫時會傳入 flag = true)
 */
function detectInstall(flag){
	var installed = false;
	var scObj = getSecurityControlObject();
	var apiVersion = scObj.GetAPIVersion();
	if(scObj && (apiVersion!=null && !apiVersion.startsWith("-"))){
		installed = true;
	}
	if(!installed) {
		winopen($.cfg.cp + '/common/InstallSecurityControl.faces');
		return false;
	} else { 
		// version check;
		if(apiVersion != (isIE64() ? scData.apiX64Version : scData.apiVersion).replace(/,/g, '.')) {
			showScMsg('please.upgrade.security.control');
			// 開新視窗提供安裝
			winopen($.cfg.cp + '/common/InstallSecurityControl.faces');
			return false;
		}
	}
	return true;
}
//--------------------------------------------------------------------
/**
 * 取得已連接的讀卡機裝置數量
 */
function getReaderCount(){
	var scObj = getSecurityControlObject();
	scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，ListReaders()前不DisconnectCard()會讀卡失敗
	var rc = scObj.ListReaders();
	if(rc == 0){
		return scObj.GetReaderNumber();
	}		
	return -1;
}
//--------------------------------------------------------------------
/**
 * 取得發卡銀行前三碼 
 */
function getIssuerBank(readerName){

	var scObj = getSecurityControlObject();

	// get first reader name	
	if(!readerName){
		showScMsg('detect.card.reader.failed');
		return false;
	}

	rc = scObj.ConnectReader(readerName);
	if(rc!=0){
		showScMsg('connect.card.reader.failed', toHex(rc));
		return false;
	}

	rc = scObj.ConnectCard(readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		return false;
	}

	var issuerBank =  scObj.GetIssuerBank() ;
	if(!issuerBank) {
		showScMsg('get.issuer.failed');
		return false;
	}
	scObj.DisconnectCard(readerName);
	scObj.ConnectCard(readerName);	// add by Sky@WebComm, 交易結束後恢復獨佔模式

	return issuerBank.substr(0, 3);
}
//--------------------------------------------------------------------
/**
 * 偵測是否有插卡
 */
function detectCardInsert(readerCount, dontDisconnectCard) {
	if(readerCount == 0) {
		readerCount = getReaderCount();	
	}
	
	if(readerCount > 0) {
		var scObj = getSecurityControlObject();
		// 依序查詢是否有接卡片
		for(var i = 0;i<readerCount;i++) {
			var start = (new Date()).getTime();
			
			var readerName = scObj.GetReaderName(i);
			$.log('GetReaderName : ' + ((new Date()).getTime() - start));
			start = (new Date()).getTime();

			if(scObj.ConnectCard(readerName)  == 0) {
				$.log('ConnectCard : ' + ((new Date()).getTime() - start));
				start = (new Date()).getTime();
				if(!dontDisconnectCard) {
					scObj.DisconnectCard(readerName);
					scObj.ConnectCard(readerName);	// add by Sky@WebComm, 交易結束後恢復獨佔模式
				}
				$.log('DisconnectCard : ' + ((new Date()).getTime() - start));
				start = (new Date()).getTime();
				return true;
			}
		}
	}
	return false;
}
//--------------------------------------------------------------------
/**
 * 顯示 BHO 
 * type 畫面樣板類型 1, 2, 3:驗證帳號後4碼
 * confirmItemName
 * txnTitle
 * xOffset
 * yOffset
 */
function showBHOCommon(type, confirmItemName, txnTitle, xOffset, yOffset, taskId) {
	 showBHOCommon(type, confirmItemName, txnTitle, xOffset, yOffset, taskId, null);
}

function showBHOCommon(type, confirmItemName, txnTitle, xOffset, yOffset, taskId, callback) {
	
	var cardInfo = buildBHOCommonXMLFromCard(type, confirmItemName, txnTitle, xOffset, yOffset);
	
	if(!cardInfo){
		return false;
	}

	var hsResult = doHandShake(taskId);
	if(!hsResult) {
		return false;
	}

	var finalResult = 
		{	'success' : false,
			'hsResult' : hsResult
		};
	var scObj = getSecurityControlObject();
	scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，BHOCommon前不DisconnectCard()會讀卡失敗

	try {

		// hack for Mac OS
		window.comp = scObj;

	    execute("BHOCommon", 
	    		cardInfo.bhoXML, 
	    		hsResult.sessionKeyHash, 
	    		hsResult.encSessionKey, 
	    		function(result) {
	    			console.log('#### WDSTX001 驗證結果=' + result.rtnCode);
	    		    result.allowNonTFBCard = true;
			        if (result.rtnCode != 0) {
			        	finalResult.success = false;
			        	cleanMask();
						// 將 doBHOCommonVerify bind 到  submit
						$('form:first').unbind('submit.BHOVerify', doBHOCommonVerify).bind('submit.BHOVerify', doBHOCommonVerify);
						// 清掉 hidden field 確保JC commandlink ex 繼續送出
						$('input[type="hidden"]').each(function(idx, ele){ if(ele.name == ele.value){ele.value = '';}});
			        	return false;
			        } else {
			        	result.readerName = result.respData.split(';;')[0];
			        	
			        	if (type != 3) {
			        		getCardInfoForAuth(result);
							if(result.success) {
					        	finalResult.cardInfo = cardInfo;		
					        	finalResult = $.extend(finalResult, result);
							}	
			        	} 
			        	finalResult = $.extend(finalResult, result);
			    		var isWin = !!navigator.userAgent.match(/Windows/);
			    		if((isWin && (isIE() || isIE64()))||!isWin) {
			    			// 不是 windows, 直接呼叫 callback
			    			callback(finalResult, true);
			    		}
			    		
			        	return result;
			        }
				}
	    );
	} catch(e) {
		alert('Exception:' + e.message);
		return false;
	}
    return finalResult;
}
//--------------------------------------------------------------------
/**
 * 顯示 BHO 檔案上傳
 * taskId
 * callBack
 */
function showBHOFileTransfer(taskId, trxCallBack) {
	var returnResult = {};					//回傳結果
	var scObj = getSecurityControlObject(); //晶片卡原件	
	var isWin = !!navigator.userAgent.match(/Windows/);  //是否為windows
	
	var hsResult = doHandShake(taskId);
	if(!hsResult) {
		return false;
	}
	
	var finalResult = 
	{	'success' : false,
		'hsResult' : hsResult
	};	
	
	window.comp = scObj; // hack for Mac OS
	executeFileTransfer("FileTransfer",  hsResult.sessionKeyHash, hsResult.encSessionKey, function(result) {
		if (result.rtnCode != 0) {
			finalResult.success = false;
			returnResult.result = result.rtnCode;
			return returnResult;
		} else {
			finalResult = $.extend(finalResult, result);
			returnResult.result = 0;
			if (isWin) {
				returnResult.filename = result.clearFileName;
				returnResult.rsData = result.rspData;
				returnResult.rsLen = result.clearFileLength;
				returnResult.encFilename = result.encFileName;
			} else {
				returnResult.filename = result.clearFileName;
				returnResult.rsData = result.rspData;
				returnResult.rsLen = result.clearFileLength;
				returnResult.encFilename = result.encFileName;
			}
			
			//if((isWin && (isIE()||isIE64()))|| !isWin) {
				trxCallBack(returnResult);
			//}
		return result;
		}
	});
    return finalResult;

}

function executeFileTransfer(command){
    if (command) {
        var args = $.makeArray(arguments).slice(1);
        //window start
        var isWin = true;
        isWin = !!navigator.userAgent.match(/Windows/);  
        var doneFun = false;
        if ( (isWin && !isIE() && !isIE64()) && $.isFunction(args[args.length - 1])) {
            doneFun = $.proxy(args.pop(), this);
        }
        //window end
        var _fun = "";
        for (var idx in args) {
            _fun += ((_fun ? "," : "") + "args[" + idx + "]");
        }

        var rc = (new Function('comp', 'command', 'args', 'return comp[command](' + _fun + ');'))(comp, command, args);
                
        //windows and use callback
        if (doneFun) {
            //default callback result 
            var result = {
                result : rc,
                command: command,
                success: rc == 0,
                rtnCode: rc,
                respData: "",
                encRspData: ""
            };
            if( rc == 0){
              result.filename = comp.GetClearFileName();
              result.rsData = comp.GetRespData();
              result.rsLen = comp.GetRespLength();
              result.encFilename = comp.GetEncFileName();
            }
            doneFun(result);
        } else {
            if (rc === 0) {
                return true;
            } else {
                if (/^-?[0-9]+$/.test(rc)) {
                    $.log("error command:" + command + " code:" + rc);
                    throw rc;
                } else {
                    return rc;
                }
            }
        }
        return rc;
    } else {
        throw "9999999990";
    }              
}

//--------------------------------------------------------------------
/**
 * 卡片 產生 BHO xml (設定值)
 */
function buildBHOCommonXMLFromCard(type, txnTitle, confirmItemName, xOffset, yOffset) {
	if(!confirmItemName) {
		confirmItemName = defaultConfirmTitle;
	}
	if(!txnTitle) {
		txnTitle = defaultTxnTitle;
	}
	var result = {};
	
	//修改template(xml) 內容 by 變數replace 
	var template = '';
	if (type == 1) {
		template = $('#_sc_bhoXMLTemplate1').val();
	} else if (type == 2) {
		template = $('#_sc_bhoXMLTemplate2').val();
	} else if (type == 3) {
		//驗證帳號後4碼
		template = $('#_sc_bhoXMLTemplate3').val();
	} else if(type == 4){
		template = $('#_sc_bhoXMLTemplate4').val();
	} else if(type == 5){
		// SME
		template = $('#_sc_bhoXMLTemplate5').val();
	}
	var bhoXML = template.replace(/%TXN_TITLE%/, txnTitle)
						.replace(/%CONFIRM_ITEM%/, confirmItemName)
						.replace(/%X%/,xOffset)
						.replace(/%Y%/, yOffset);
	result.bhoXML = bhoXML;
	return result;
}
//--------------------------------------------------
/**		
* 呼叫 讀卡機 元件 (插拔畫面)  2562 2563 交易
* 一代機、二代機 都call 此function (差異 二代機 pin 給0)
* readerList 讀卡機 下拉選單
* accountList 帳號卡號下拉選單 
* pin 一代機給 pin id, 二代機 pin 給
* transactionCode 四碼, 晶片卡(他行)2562	晶片卡(自行)2563
* fdid 端末設備代號 八碼
* fdChkCode 端末設備查核碼 八碼亂數
* money 金額 需含小數兩位, ex 100.00 --> 傳入 10000
* transTime 交易時間, 此時間要與 後面HSM電文相同
* taskId caller's taskId
*/
function showAccountPayTaxEx3API(readerId, accountId, pinVal, transactionCode, money, resultInput, taskId ) {
	var termData = getTermDataAtmPay(taskId);
	var fdid = termData.termNo;	
	var fdChkCode = termData.termChkCode;
	
	var result = {};			//回傳結果
	var rc = 0;
	var readerName = readerId;
	var scObj = getSecurityControlObject();
	
	//----------------------------------
	// detect install
	var detectResult = detectInstall();
	if(!detectResult){
		cleanMask();
		result.success = false;
		return result;
	}

	scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，ListReaders()前不DisconnectCard()會讀卡失敗
	//----------------------------------
	//列出目前所有連接的讀卡機，如果有過安裝但未連接上系統時並未列出。
	rc = scObj.ListReaders();
	//----------------------------------
	//不等於0, 為失敗
	if(rc!=0){
		showScMsg('please.connect.card.reader', toHex(rc));
		result.success = false;
		return result;
	}
	//------------------------------------------------------
	//回傳讀卡機個數。必須先執行ListReaders。  >0 成功，讀卡機的個數。 -1讀卡機不存在。
	var readerCount = scObj.GetReaderNumber();
	if(readerCount < 0 ){
		showScMsg('please.connect.card.reader');
		result.success = false;
		return result;
	}

	rc = scObj.ConnectReader(readerName);
	if(rc!=0){  
		showScMsg('connect.card.reader.failed', toHex(rc));
		
		result.success = false;
		return result;
	}

	rc = scObj.ConnectCard(readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		result.success = false;
		return result;
	}
	
	//不是2代機, 要驗pin, 2代機交易api 會自動要pin
	if (!is2ndGeneration(readerName)) {
		rc = scObj.VerifyPIN(pinVal);
		if(rc!=0){
			showScMsg('', toHex(rc));
			result.success = false;
			return result;
		}				
	}

	var icCardRemark = scObj.GetICCRemark();
	if(!icCardRemark){
		showScMsg('get.icc.memo.failed');
    	result.success = false;
    	return result;
	}			

	//----------------------------------------------------------------
	/*
	AccountPayTaxEx3 參數 
	AccountPayTaxSndEx3 參數  --> 沒有pin
	readerName	String	n	讀卡機名稱
	transactionCode	String	4	交易代號
	Fdid	String	8	端末設備代號
	FdChkCode	String	8	端末設備查核碼
	money	String	14	轉帳金額欄位，內含有兩位小數;右靠。	
	Account	String	16	轉出帳號
	pin		String	6-16	晶片密碼
	CardSerialNo	String	16	晶片序號(呼叫connectCard完, 呼叫ReadCardSerialNo獲得)
	CardNoFlag	long	4	0-無須驗證晶片序號, 1-需要
	ShowMsg	String	n	須顯示之訊息,訊息格式參考目錄C
	ConfirmFlag	Long	4	0-無晶片拔插確認畫面, 1-有
	VerifyValFlag	Long	4	0-無須比對帳號金額與訊息是否相符, 1-需要
	SessionKeyHash	String	40	Session Key Hash值
	CpukEncSessionKey	String	256	被公開金鑰加密之SessionKey
	DateStr	String	14	14 bytes server date–time string (YYYYMMDDhhmmss)
	*/
	var CardSerialNo = scObj.ReadCardSN(); 					//晶片序號(呼叫connectCard完, 呼叫ReadCardSerialNo獲得)
	var CardNoFlag = 0;										//0-無須驗證晶片序號,1-需要
	var ShowMsg = $('#_sc_AccountPayTaxEx3Template1').val();//須顯示之訊息,訊息格式參考目錄C (放在secutityControlObject.xhtml裡面共用)
	var ConfirmFlag = 1;									//long   0-無晶片拔插確認畫面,1-有
	var VerifyValFlag = 0;									//long   0-無須比對帳號金額與訊息是否相符, 1-需要
				
	var hsResult = doHandShake(taskId);
	if(!hsResult) {
		result.success = false;
		return result;
	}
	
	var SessionKeyHash = hsResult.sessionKeyHash;				//Session Key Hash值
	var CpukEncSessionKey = hsResult.encSessionKey;				//被公開金鑰加密之SessionKey
	var transTime = getYYYYMMDDHHMMSSDate();
    var respData = {
        data: ''
    }

	try {

		if (is2ndGeneration(readerName)) {
			
			var msg = 'readerName:' + readerName + '\n'
						+ 'transactionCode:' + transactionCode + '\n'
						+ 'fdid:' + fdid + '\n'
						+ 'fdChkCode:' + fdChkCode + '\n'
						+ 'pad(money, 14):' + pad(money, 14) + '\n'
						+ 'accountId:' + accountId + '\n'
						+ 'CardSerialNo:' + CardSerialNo + '\n'
						+ 'CardNoFlag:' + CardNoFlag + '\n'
						+ 'SessionKeyHash:' + SessionKeyHash + '\n'
						+ 'CpukEncSessionKey:' + CpukEncSessionKey + '\n'
						+ 'transTime:' + transTime + '\n';
			//show info
			//alert(msg);
			
			rc = scObj.AccountPayTaxSndEx3 (readerName, 
					transactionCode, 
					fdid, 
					fdChkCode,
					pad(money, 14), 	
					accountId,	
					CardSerialNo, 
					CardNoFlag, 
					SessionKeyHash, 
					CpukEncSessionKey,
					transTime); 					

		} else {
			var msg = 'readerName:' + readerName + '\n'
						+ 'transactionCode:' + transactionCode + '\n'
						+ 'fdid:' + fdid + '\n'
						+ 'fdChkCode:' + fdChkCode + '\n'
						+ 'pad(money, 14):' + pad(money, 14) + '\n'
						+ 'accountId:' + accountId + '\n'
						+ 'CardSerialNo:' + CardSerialNo + '\n'
						+ 'CardNoFlag:' + CardNoFlag + '\n'
						+ 'ShowMsg:' + ShowMsg + '\n'
						+ 'ConfirmFlag:' + ConfirmFlag + '\n'
						+ 'VerifyValFlag:' + VerifyValFlag + '\n'
						+ 'SessionKeyHash:' + SessionKeyHash + '\n'
						+ 'CpukEncSessionKey:' + CpukEncSessionKey + '\n'
						+ 'transTime:' + transTime + '\n';
			//show info
			//alert(msg);
			
			rc = scObj.AccountPayTaxEx3 (readerName, 
					transactionCode, 
					fdid, 
					fdChkCode,
					pad(money, 14), 	
					accountId,	
					pinVal, 
					CardSerialNo, 
					CardNoFlag, 
					ShowMsg, 
					ConfirmFlag, 
					VerifyValFlag, 
					SessionKeyHash, 
					CpukEncSessionKey,
					transTime,
                    respData);
		}
		
		
	} catch(e) {
		alert('Exception:' + e.message);
	}
	//rc:67113987
	//alert('rc:' + rc);

    isMac = !!navigator.userAgent.match(/Mac/);

	var resultObj = {
			'issuer' : scObj.GetIssuerBank(),
			'readerName' : readerName,
			'readerType' : is2ndGeneration(readerName) ? '2' : '1',
			'respSNUM' : (isMac && respData.data) ? respData.data.respSNUM : scObj.GetRespSNUM(),
			'respData' : (isMac && respData.data) ? respData.data.respEncTAC : scObj.GetRespData(),
			'icCardRemark' : icCardRemark,
			'termNo' : termData.termNo,
			'termChkCode' : termData.termChkCode,
			'transTime' : transTime
	};	
	//----------------------------------
	$(resultInput).val($.toJSON(resultObj));
	
	if(rc!=0){			
		
		if (rc != 67113987) {
			//alert('rc:' + rc);		//67113987  取消碼
			showScMsg('bho.cratetac.error', toHex(rc));			
		}	
		result.rc = rc;	
		result.success = false;
		return result;
	} else {
		result.success = true;
		result.respSNUM = scObj.GetRespSNUM();
		result.respData = scObj.GetRespData();
		result.icCardRemark = icCardRemark;	
		result.rc = rc;	
		return result;					
	}
	//----------------------------------------------------------------	
}			
//--------------------------------------------------
/**		
* 呼叫 讀卡機 元件 (繳稅交易)  交易代號(2531~2532) 交易
* 一代機、二代機 都call 此function (差異 二代機 pin 給0)
* 
* readerName 讀卡機
* transactionCode 交易代號
* paymentType 繳款類別
* cancelNo 銷帳編號
* account 轉出帳號
* pinVal 一代機給 pin id, 二代機 pin 給
* money 金額 需含小數兩位, ex 100.00 --> 傳入 10000
* resultInput 交易結果 
* taskId caller's taskId
*/
function execAccountPayment(readerName, transactionCode, paymentType, cancelNo, account, pinVal, money, resultInput, taskId) {

	var result = {};			//回傳結果
	var rc = 0;
	var rcode = 0;
	var scObj = getSecurityControlObject();
	var isWin = true;
    var iswindow = !!navigator.userAgent.match(/Windows/);  
    isWin = iswindow;
	
	if(typeof resultInput == 'string') {
		resultInput = $('#' + resultInput.replace(/:/g,'\\:'));
	}
	
	//----------------------------------
	// detect install
	var detectResult = detectInstall();
	if(!detectResult){
		cleanMask();
		result.success = false;
		return result;
	}
/*
	//----------------------------------
	//列出目前所有連接的讀卡機，如果有過安裝但未連接上系統時並未列出。
	rc = scObj.ListReaders();
	//----------------------------------
	//不等於0, 為失敗
	if(rc!=0){
		showScMsg('please.connect.card.reader', toHex(rc));
		result.success = false;
		return result;
	}
	//------------------------------------------------------
	//回傳讀卡機個數。必須先執行ListReaders。  >0 成功，讀卡機的個數。 -1讀卡機不存在。
	var readerCount = scObj.GetReaderNumber();
	if(readerCount < 0 ){
		showScMsg('please.connect.card.reader');
		result.success = false;
		return result;
	}
*/
	rc = scObj.ConnectReader(readerName);
	if(rc!=0){  
		showScMsg('connect.card.reader.failed', toHex(rc));
		
		result.success = false;
		return result;
	}

	rc = scObj.ConnectCard(readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		result.success = false;
		return result;
	}

	var icCardRemark = scObj.GetICCRemark();
	if(!icCardRemark){
		showScMsg('get.icc.memo.failed');
    	result.success = false;
    	return result;
	}			
	
	//----------------------------------------------------------------
	var termData = getTermDataAtmPay(taskId);
	//----------------------------------------------------------------
	var CardSerialNo = scObj.ReadCardSN(); 					//晶片序號(呼叫connectCard完, 呼叫ReadCardSerialNo獲得)
	var CardNoFlag = 1;										//0-無須驗證晶片序號,1-需要
	var ShowMsg = $('#_sc_AccountPayTaxEx3Template1').val();//須顯示之訊息,訊息格式參考目錄C (放在secutityControlObject.xhtml裡面共用)
	var ConfirmFlag = 1;									//long   0-無晶片拔插確認畫面,1-有
	var VerifyValFlag = 0;									//long   0-無須比對帳號金額與訊息是否相符, 1-需要
				
	var hsResult = doHandShake(taskId);
	if(!hsResult) {
		result.success = false;
		return result;
	}

	var SessionKeyHash = hsResult.sessionKeyHash;				//Session Key Hash值
	var CpukEncSessionKey = hsResult.encSessionKey;				//被公開金鑰加密之SessionKey
	//TODO
	var transTime = getYYYYMMDDHHMMSSDate();
	var callback={
		data: ''
	};
	try {
		if (is2ndGeneration(readerName)) {
			/*
			ReaderName	String	n	讀卡機名稱
			TransactionCode	String	4	交易代號
			Fdid	String	8	端末設備代號
			FdChkCode	String	8	端末設備查核碼
			Money	String	14	轉帳金額欄位，內含有兩位小數; 右靠。
			PaymentType	String	5	繳款類別
			CancelNo	String	16	銷帳編號
			Account	String	16	轉帳帳號
			CardSerialNo	String	16	晶片序號(呼叫connectCard完, 呼叫ReadCardSerialNo獲得)
			CardNoFlag	long	4	0-無須驗證晶片序號,1-需要
			SessionKeyHash	String	40	Session Key Hash值
			CpukEncSessionKey	String	256	被公開金鑰加密之SessionKey
			DateStr	String	14	14 bytes server date–time string (YYYYMMDDhhmmss)
			 */
			rc = scObj.AccountPaymentSndEx3 (
					readerName, 
					transactionCode, 
					termData.termNo, 
					termData.termChkCode,
					pad(money, 14), 
					paymentType,
					padBlank(cancelNo, 16),
					pad(account, 16),	
					CardSerialNo, 
					CardNoFlag, 
					SessionKeyHash, 
					CpukEncSessionKey,
					transTime); 
			
			var paramStr = 'Ver2.1 readerName:[' + readerName + ']\n';
			paramStr = paramStr + 'transactionCode:[' + transactionCode+ ']\n';
			paramStr = paramStr + 'termNo:[' + termData.termNo+ ']\n';
			paramStr = paramStr + 'termChkCode:[' + termData.termChkCode+ ']\n';
			paramStr = paramStr + 'money:[' + pad(money, 14)+ ']\n';
			paramStr = paramStr + 'paymentType:[' + paymentType+ ']\n';
			paramStr = paramStr + 'cancelNo:[' + padBlank(cancelNo, 16)+ ']\n';
			paramStr = paramStr + 'account:[' + pad(account, 16)+ ']\n';

			paramStr = paramStr + 'CardSerialNo:[' + CardSerialNo+ ']\n';
			paramStr = paramStr + 'CardNoFlag:[' + CardNoFlag+ ']\n';
			paramStr = paramStr + 'SessionKeyHash:[' + SessionKeyHash+ ']\n';
			paramStr = paramStr + 'CpukEncSessionKey:[' + CpukEncSessionKey+ ']\n';
			paramStr = paramStr + 'transTime:[' + transTime+ ']\n';
			//alert(paramStr);

		} else {
			/*
			ReaderName	String	n	讀卡機名稱
			TransactionCode	String	4	交易代號
			Fdid	String	8	端末設備代號
			FdChkCode	String	8	端末設備查核碼
			Money	String	14	轉帳金額欄位，內含有兩位小數; 右靠。
			PaymentType	String	5	繳款類別
			CancelNo	String	16	銷帳編號
			Account	String	16	轉帳帳號
			Password	String	6-16	晶片密碼
			CardSerialNo	String	16	晶片序號(呼叫connectCard完, 呼叫ReadCardSerialNo獲得)
			CardNoFlag	long	4	0-無須驗證晶片序號,1-需要
			ShowMsg	String	n	須顯示之訊息,訊息格式參考目錄C
			ConfirmFlag	Long	4	0-無晶片拔插確認畫面,1-有
			VerifyValFlag	Long	4	0-無須比對帳號金額與訊息是否相符, 1-需要
			SessionKeyHash	String	40	Session Key Hash值
			CpukEncSessionKey	String	256	被公開金鑰加密之SessionKey
			DateStr	String	14	14 bytes server date–time string (YYYYMMDDhhmmss)
			 */
				rc = scObj.AccountPaymentEx3 (
						readerName, 
						transactionCode, 
						termData.termNo, 
						termData.termChkCode,
						pad(money, 14), 
						paymentType,
						padBlank(cancelNo, 16),
						pad(account, 16),
						pinVal, 
						CardSerialNo, 
						CardNoFlag, 
						ShowMsg, 
						ConfirmFlag, 
						VerifyValFlag, 
						SessionKeyHash, 
						CpukEncSessionKey,
					transTime,
					callback);
			
					var paramStr = 'Ver2 readerName:[' + readerName + ']\n';
					paramStr = paramStr + 'transactionCode:[' + transactionCode+ ']\n';
					paramStr = paramStr + 'termNo:[' + termData.termNo+ ']\n';
					paramStr = paramStr + 'termChkCode:[' + termData.termChkCode+ ']\n';
					paramStr = paramStr + 'money:[' + pad(money, 14)+ ']\n';
					paramStr = paramStr + 'paymentType:[' + paymentType+ ']\n';
					paramStr = paramStr + 'cancelNo:[' + padBlank(cancelNo, 16)+ ']\n';
					paramStr = paramStr + 'account:[' + pad(account, 16)+ ']\n';
					paramStr = paramStr + 'pin:[' + pinVal+ ']\n';
					paramStr = paramStr + 'CardSerialNo:[' + CardSerialNo+ ']\n';
					paramStr = paramStr + 'CardNoFlag:[' + CardNoFlag+ ']\n';
					//paramStr = paramStr + 'readerName:[' + ShowMsg+ ']\n';
					paramStr = paramStr + 'ConfirmFlag:[' + ConfirmFlag+ ']\n';
					paramStr = paramStr + 'VerifyValFlag:[' + VerifyValFlag+ ']\n';
					paramStr = paramStr + 'SessionKeyHash:[' + SessionKeyHash+ ']\n';
					paramStr = paramStr + 'CpukEncSessionKey:[' + CpukEncSessionKey+ ']\n';
					paramStr = paramStr + 'transTime:[' + transTime+ ']\n';
					//alert(paramStr);
		}
		
		
	} catch(e) {
		alert('Exception:' + e.message);
	}

	var respSNUM;
	var respData;
	if(!isWin){
		var respObj = callback.data;
		respSNUM = respObj.respSNUM;
		respData = respObj.respEncTAC;
	} else {
		respSNUM = scObj.GetRespSNUM();
		respData = scObj.GetRespData();
	}
	
	var resultObj = {
			'issuer' : scObj.GetIssuerBank(),
			'readerName' : readerName,
			'readerType' : is2ndGeneration(readerName) ? '2' : '1',
		'respSNUM' : respSNUM,
		'respData' : respData,
			'icCardRemark' : icCardRemark,
			'termNo' : termData.termNo,
			'termChkCode' : termData.termChkCode,
			'transTime' : transTime
	};	
	//----------------------------------
	$(resultInput).val($.toJSON(resultObj));
	
		if(rc!=0){			
			if (rc != 67113987) {
				//alert('rc:' + rc);		//67113987  取消碼
				showScMsg('bho.cratetac.error', toHex(rc));			
			}	
			result.rc = rc;	
			result.success = false;
			return result;
		} else {
			result.success = true;
		result.respSNUM = respSNUM;
		result.respData = respData;
			result.icCardRemark = icCardRemark;	
			result.rc = rc;	
			return result;					
		}
	//----------------------------------------------------------------	
}	
//----------------------------------------------------------------
/**		
* 驗證 pin
* 一代機、二代機 都call 此function , 二代機 pin 給0
* readerList 讀卡機 下拉選單
* accountId 卡號
* pinVal
*/
function doVerifyPIN(readerId, accountId, pinVal) {

	var result = {};			//回傳結果
	var rc = 0;
	var readerName = readerId;
	var scObj = getSecurityControlObject();
	
	//----------------------------------
	// detect install
	var detectResult = detectInstall();
	if(!detectResult){
		cleanMask();
		result.success = false;
		return result;
	}
	scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，ListReaders()前不DisconnectCard()會讀卡失敗
	//----------------------------------
	//列出目前所有連接的讀卡機，如果有過安裝但未連接上系統時並未列出。
	rc = scObj.ListReaders();
	//----------------------------------
	//不等於0, 為失敗
	if(rc!=0){
		showScMsg('please.connect.card.reader', toHex(rc));
		result.success = false;
		return result;
	}
	//------------------------------------------------------
	//回傳讀卡機個數。必須先執行ListReaders。  >0 成功，讀卡機的個數。 -1讀卡機不存在。
	var readerCount = scObj.GetReaderNumber();
	if(readerCount < 0 ){
		showScMsg('please.connect.card.reader');
		result.success = false;
		return result;
	}
	rc = scObj.ConnectReader(readerName);
	if(rc!=0){  
		showScMsg('connect.card.reader.failed', toHex(rc));
		
		result.success = false;
		return result;
	}
	rc = scObj.ConnectCard(readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		result.success = false;
		return result;
	}
	//----------------------------------------------------------------
	try {
		if (is2ndGeneration(readerName)) {
			//二代機
			rc = scObj.VerifyPINSnd();				
		} else {	
			//一代機
			rc = scObj.VerifyPIN (pinVal);					
		}
	} catch(e) {
		alert('Exception:' + e.message);
	}

	if(rc!=0){							
		showScMsg('', toHex(rc));
		result.success = false;
		return result;
	} else {			
		result.success = true;
		return result;				
	}
	//----------------------------------------------------------------	
}	
//----------------------------------------------------------------
/**		
* 修改 pin
* 一代機、二代機 都call 此function , 二代機 oldpin, newpin 給0
* readerList 讀卡機 String
* accountId 卡號 String 
* oldpin 原pin 二代機 給 0
* newpin 新pin 二代機 給 0
* taskId caller's taskId
*/
function doChangePIN(readerId, accountId, oldpin, newpin, taskId) {

	var result = {};			//回傳結果
	var rc = 0;
	var readerName = readerId;
	var scObj = getSecurityControlObject();

	//----------------------------------
	// detect install
	var detectResult = detectInstall();
	if(!detectResult){
		cleanMask();
		result.success = false;
		return result;
	}
	scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，ListReaders()前不DisconnectCard()會讀卡失敗
	//----------------------------------
	//列出目前所有連接的讀卡機，如果有過安裝但未連接上系統時並未列出。
	rc = scObj.ListReaders();
	//----------------------------------
	//不等於0, 為失敗
	if(rc!=0){
		showScMsg('please.connect.card.reader', toHex(rc));
		result.success = false;
		return result;
	}
	//------------------------------------------------------
	//回傳讀卡機個數。必須先執行ListReaders。  >0 成功，讀卡機的個數。 -1讀卡機不存在。
	var readerCount = scObj.GetReaderNumber();
	if(readerCount < 0 ){
		showScMsg('please.connect.card.reader');
		result.success = false;
		return result;
	}
	rc = scObj.ConnectReader(readerName);
	if(rc!=0){  
		showScMsg('connect.card.reader.failed', toHex(rc));
		
		result.success = false;
		return result;
	}
	rc = scObj.ConnectCard(readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		result.success = false;
		return result;
	}
	var icCardRemark = scObj.GetICCRemark();
	if(!icCardRemark){
		showScMsg('get.icc.memo.failed');
    	result.success = false;
    	return result;
	}		
	//----------------------------------------------------------------
	var CardSerialNo = scObj.ReadCardSN(); 					//晶片序號(呼叫connectCard完, 呼叫ReadCardSerialNo獲得)
	//----------------------------------------------------------------
	// call 餘額查詢, change pin 要發送 HSM0250電文 需要有 tac, 但 changepin 無tac。
	// 參照現行fubon作法，call 餘額查詢
	var hsResult = doHandShake(taskId);			
	if(!hsResult) {
		result.success = false;
		return result;
	}			
	var termData = getTermData(taskId);
	result.termNo = termData.termNo;
	result.termChkCode = termData.termChkCode;
	
	var SessionKeyHash = hsResult.sessionKeyHash;				//Session Key Hash值
	var CpukEncSessionKey = hsResult.encSessionKey;				//被公開金鑰加密之SessionKey	

	if (is2ndGeneration(readerName)) {
		//發查餘額
		
		rc = scObj.AccountInquirySndEx3 (
									readerName, 
									'2500', 
									termData.termChkCode, 
									accountId,  
									CardSerialNo, 
									1, 
									SessionKeyHash, 
									CpukEncSessionKey);		
		if(rc!=0){
			showScMsg('', toHex(rc));
			result.success = false;
	    	return result;
		} else {
			result.respSNUM = scObj.GetRespSNUM();
			result.respData = scObj.GetRespData();
		}
	} else {
		//發查餘額
		rc = scObj.AccountInquiryEx3 (
									readerName, 
									'2500', 
									termData.termChkCode, 
									accountId,  
									oldpin,
									CardSerialNo, 
									0, 
									'', 
									0,  
									SessionKeyHash, 
									CpukEncSessionKey);		
		if(rc!=0){
			showScMsg('', toHex(rc));
			result.success = false;
	    	return result;
		} else {
			result.respSNUM = scObj.GetRespSNUM();
			result.respData = scObj.GetRespData();
		}		
	}

	
	//----------------------------------------------------------------
	
	var VerifyValFlag = 1;										//VerifyFlag︰0-No, 1-需要驗證卡片序號
	try {
		if (is2ndGeneration(readerName)) {
			//二代機
			rc = scObj.ChangePINSnd ( readerName, CardSerialNo, VerifyValFlag);				
		} else {	
			//一代機
			rc = scObj.ChangePIN ( readerName, oldpin,  newpin, CardSerialNo, VerifyValFlag);					
		}
	} catch(e) {
		alert('Exception:' + e.message);
	}
	if(rc!=0){							
		showScMsg('pin.change.error', toHex(rc));
		result.success = false;
		return result;
	} else {	
		result.icCardRemark = icCardRemark;
		result.success = true;
		return result;				
	}
	//----------------------------------------------------------------	
}	
//--------------------------------------------------
/**
 * 判斷 發卡銀行是否為富邦。true=富邦, false=非富邦
 */
function detectCardIssuser(){
	var scObj = getSecurityControlObject();
	scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，ListReaders()前不DisconnectCard()會讀卡失敗
	var rc = scObj.ListReaders();
	if(rc!=0){
		showScMsg('please.connect.card.reader', toHex(rc));
		return false;
	}
	var readerCount = scObj.GetReaderNumber();
	if(readerCount < 0 ){
		showScMsg('please.connect.card.reader');
		return false;
	}
	for(var i=0;i<readerCount;i++){
		var isTFB = false;
		// get first reader name
		var readerName = scObj.GetReaderName(i);
		if(!readerName){
			showScMsg('detect.card.reader.failed');
			return false;
		}
		rc = scObj.ConnectReader(readerName);
		if(rc!=0){
			showScMsg('connect.card.reader.failed', toHex(rc));
			return false;
		}
		rc = scObj.ConnectCard(readerName);
		if(rc!=0){
			showScMsg('read.card.failed', toHex(rc));
			return false;
		}
		var issuerBank =  scObj.GetIssuerBank() ;
		if(!issuerBank) {
			showScMsg('get.issuer.failed');
			return false;
		} else if(!issuerBank.match(/^012[0-9]{5}$/)){
			isTFB = false;
		} else {
			isTFB = true;
		}
		scObj.DisconnectCard(readerName);
		scObj.ConnectCard(readerName);	// add by Sky@WebComm, 交易結束後恢復獨佔模式
		if(isTFB) {
			return true;
		}
		return false;
	}
	return false;
}
//--------------------------------------------------------------------
function encryptBySessionKey(hsResult, data) {
	var scObj = getSecurityControlObject();
	var hex = hexEncode(data);
	var rc = scObj.DESEncipher(hsResult.sessionKeyHash, hsResult.encSessionKey, hex.length / 2, hex);
	if(rc != 0) {
		showScMsg('unknown.error', toHex(rc));
		return false;
	}
	return scObj.GetRespData();
}
//--------------------------------------------------------------------
/**
 * 取得卡片資訊
 */
function getCardInfoForAuth(result) {
	var scObj = getSecurityControlObject();
	var rc = scObj.ReConnectCard(result.readerName, '0');
	if(rc != 0) {
		showScMsg('read.card.failed', toHex(rc));
    	result.success = false;
    	return;
	}
	
	var issuerBank =  scObj.GetIssuerBank() ;
	if(!issuerBank) {
		showScMsg('get.issuer.failed');
    	result.success = false;
    	return;
	} else if(result.allowNonTFBCard && !issuerBank.match(/^012[0-9]{5}$/)){
		// 一定要  01200000
		showScMsg('not.TFB.card');
    	result.success = false;
    	return;
	}
	var iccardRemark = scObj.GetICCRemark();
	if(!iccardRemark){
		showScMsg('get.icc.memo.failed');
    	result.success = false;
    	return;
	}

	// 成功繼續 QuiryEF0001
	//QuiryEF001
    rc = scObj.QuiryEF0001();
    if(rc != 0) {
    	showScMsg('read.card.failed', toHex(rc));
    	result.success = false;
    	return;
    } else {
    	// result.EF0001Issuer = scObj.GetEF0001Issuer();
    	result.EF0001Account = scObj.GetEF0001Account();
    	result.EF0001SerialNo = scObj.GetEF0001SerialNo();
    }
    
	scObj.DisconnectCard(result.readerName);
	scObj.ConnectCard(result.readerName);	// add by Sky@WebComm, 交易結束後恢復獨佔模式
	result.issuerBank = issuerBank;
	result.iccardRemark = iccardRemark;
	result.success = true;
	return;
}
//--------------------------------------------------------------------
//取得 卡片 帳號資訊 for 判斷是否為同一張卡 
function getCardEFData(readerName) {

	var result = {};			//回傳結果
	
	result.success = true;
	result.efData = '';
	var start = (new Date()).getTime();


	var scObj = getSecurityControlObject();
	//----------------------------------
	rc = scObj.ConnectReader(readerName);
	$.log('ConnectReader : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();
	if(rc!=0){
		showScMsg('connect.card.reader.failed', toHex(rc));
		result.success = false;		
		return result;
	}

	//----------------------------------
	rc = scObj.ConnectCard(readerName);
	$.log('ConnectCard : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		result.success = false;
		return result;
	}
	
	getCardEFDataWithConnected(result, rc, scObj);

	scObj.DisconnectCard(readerName);
	scObj.ConnectCard(readerName);	// add by Sky@WebComm, 交易結束後恢復獨佔模式
		
	return result;
}
//--------------------------------------------------------------------
//取得 卡片 帳號資訊 (for 判斷是否為同一張卡) 
function getCardEFDataWithConnected(result, rc, scObj) {
	var start = (new Date()).getTime();

	rc = scObj.ListEF1002Accounts();
	$.log('ListEF1002Accounts : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();

	if(rc!=0) {
		showScMsg('get.account.list.failed', toHex(rc));
		result.success = false;
		return result;
	}

	rc = scObj.ListEF1001Accounts();
	$.log('ListEF1001Accounts : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();
	if(rc!=0) {
		showScMsg('get.account.list.failed', toHex(rc));
		result.success = false;
		return result;
	}

	var acctCount = scObj.GetEF1001TotalAccounts();
	$.log('GetEF1001TotalAccounts : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();
	if(acctCount < 0) {
		showScMsg('get.account.list.failed', toHex(rc));
		result.success = false;
		return result;
	}

	//把卡片中EF1001帳號逐筆 字串 連接 
	var efData = '';
	for(var j = 0;j<acctCount;j++) {
		var accountNo = scObj.GetEF1001Account(j);
		$.log('GetEF1001Account : ' + ((new Date()).getTime() - start));
		start = (new Date()).getTime();
		if(!accountNo) {
			showScMsg('get.account.list.failed', toHex(rc));
			result.success = false;
			return result;
		}
		efData = efData + accountNo;
	}	

	var issuerBank =  scObj.GetIssuerBank() ;
	$.log('GetIssuerBank : ' + ((new Date()).getTime() - start));
	result.issuerBank = issuerBank;
	start = (new Date()).getTime();
	if(!issuerBank) {
		showScMsg('get.issuer.failed');
		result.success = false;
		return result;
	}

	var icCardRemark = scObj.GetICCRemark();
	$.log('GetICCRemark : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();
	if(!icCardRemark){
		showScMsg('get.icc.memo.failed');
		result.success = false;
		return result;
	}	
	
	efData = issuerBank + icCardRemark + efData;
	result.efData = efData;
	return result;
}
//--------------------------------------------------------------------
//webatm 共用邏輯，讀卡機安裝檢核
function webatmCheckBeforeTrx(dontDisconnectCard){

	var resultObj = {};	
	resultObj.desc = '';
	resultObj.install = 'Y';		
	
	// 偵測元件安裝
	var start = (new Date()).getTime();

	result = detectInstall();
	$.log('detectInstall : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();

	if(!result){
		resultObj.install = 'N';		
		resultObj.desc = '請檢查元件安裝是否正確安裝!'; 
		//"#{mconstants['Card.validation.object.install.ready']}";
		return resultObj;
	}

	// 偵測是否有接讀卡機
	var readerCount = getReaderCount(); 
	result = (readerCount >= 0);
	$.log('getReaderCount : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();

	if(!result){
		resultObj.desc = '連結所有讀卡機失敗，請您先確認已安裝讀卡機並插入您的晶片金融卡。';
		//return "#{mconstants['Card.validation.reader.connect.ready']}";
		return resultObj;
	}
	resultObj.readerCount = readerCount;
	
	// 偵測卡片
	result = detectCardInsert(readerCount, dontDisconnectCard);
	$.log('detectCardInsert : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();
	if(!result){
		resultObj.desc = '讀取卡片失敗，請檢查卡片是否正確放入讀卡機中!';
		//return "#{mconstants['Card.validation.iccard.connect.ready']}";
		return resultObj;
	}
	return resultObj;
}
//SME 共用邏輯，讀卡機安裝檢核
function smeCheckBeforeTrx(dontDisconnectCard){

	var resultObj = {};	
	resultObj.desc = '';
	resultObj.install = 'Y';		
	
	// 偵測元件安裝
	var start = (new Date()).getTime();

	result = detectInstall();
	$.log('detectInstall : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();

	if(!result){
		resultObj.install = 'N';		
		resultObj.desc = '請檢查元件安裝是否正確安裝!'; 
		//"#{mconstants['Card.validation.object.install.ready']}";
		return resultObj;
	}

	// 偵測是否有接讀卡機
	var readerCount = getReaderCount(); 
	result = (readerCount >= 0);
	$.log('getReaderCount : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();

	if(!result){
		resultObj.desc = '連結所有讀卡機失敗，請您先確認已安裝讀卡機並插入您的交易授權卡。';
		//return "#{mconstants['Card.validation.reader.connect.ready']}";
		return resultObj;
	}
	resultObj.readerCount = readerCount;
	
	// 偵測卡片
	result = detectCardInsert(readerCount, dontDisconnectCard);
	$.log('detectCardInsert : ' + ((new Date()).getTime() - start));
	start = (new Date()).getTime();
	if(!result){
		resultObj.desc = '讀取卡片失敗，請檢查卡片是否正確放入讀卡機中!';
		//return "#{mconstants['Card.validation.iccard.connect.ready']}";
		return resultObj;
	}
	return resultObj;
}
//--------------------------------------------------------------------
//執行各種BHO功能
function doBHOAction(param, resultInput,taskId) {

	var result = {};						//回傳結果
	var rc = 0;								//回傳代碼
	var scObj = getSecurityControlObject();	//晶片卡原件		
	//----------------------------------
	// 偵測安裝
	if (param.doDetectInstall) {
		var detectResult = detectInstall();
		if(!detectResult){
			cleanMask();
			result.success = false;
			return result;
		}		
	}
	scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，ListReaders()前不DisconnectCard()會讀卡失敗
	//----------------------------------
	//列出目前所有連接的讀卡機，如果有過安裝但未連接上系統時並未列出。
	rc = scObj.ListReaders();
	//----------------------------------
	//不等於0, 為失敗
	if(rc!=0){
		showScMsg('please.connect.card.reader', toHex(rc));
		result.success = false;
		return result;
	}
	//----------------------------------
	//回傳讀卡機個數。必須先執行ListReaders。  >0 成功，讀卡機的個數。 -1讀卡機不存在。
	var readerCount = scObj.GetReaderNumber();
	if(readerCount < 0 ){
		showScMsg('please.connect.card.reader');
		result.success = false;
		return result;
	}

	rc = scObj.ConnectReader(param.readerName);
	if(rc!=0){  
		showScMsg('connect.card.reader.failed', toHex(rc));		
		result.success = false;
		return result;
	}

	rc = scObj.ConnectCard(param.readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		result.success = false;
		return result;
	}
	
	var cardSerialNo = scObj.ReadCardSN();
	if(!cardSerialNo){
		showScMsg('get.icc.serialno.failed');
		result.success = false;
		return result;
	}	
	
	var icCardRemark = scObj.GetICCRemark();
	if(!icCardRemark){
		showScMsg('get.icc.memo.failed');
    	result.success = false;
    	return result;
	}		
	
	//不是2代機, 要驗pin, 2代機交易api 會自動要pin
	if (!is2ndGeneration(param.readerName)) {
		rc = scObj.VerifyPIN(param.pin);
		if(rc!=0){
			showScMsg('', toHex(rc));
			result.success = false;
			return result;
		}				
	}	
	//--------------------------------------------------------------------------
	var transTime = getYYYYMMDDHHMMSSDate();
	var termData = getTermDataAtmPay(taskId);
	//--------------------------------------------------------------------------
	//執行各種交易
	console.log('#### WDSTX001 開始驗證=' + (param instanceof AccountPayParamClass));
	if (param instanceof AccountPayParamClass) {
				
		var hsResult = doHandShake(taskId);
		if(!hsResult) {
			result.success = false;
			return result;
		}
		
		try {
			console.log('#### WDSTX001 是否為二代讀卡機=' + is2ndGeneration(param.readerName));
			if (is2ndGeneration(param.readerName)) {
				
				var paramStr = '';
				paramStr = paramStr + 'readerName:[' + param.readerName + ']\n';
				paramStr = paramStr + 'pCode:[' + param.pCode + ']\n';
				paramStr = paramStr + 'termNo:[' + termData.termNo + ']\n';
				paramStr = paramStr + 'termChkCode:[' + termData.termChkCode + ']\n';
				paramStr = paramStr + 'txAmount:[' + pad(param.txAmount, 14) + ']\n';
				paramStr = paramStr + 'account:[' + pad(param.account, 16) + ']\n';
				paramStr = paramStr + 'inAccount:[' + pad(param.inAccount, 16) + ']\n';
				paramStr = paramStr + 'ReadCardSN:[' + cardSerialNo + ']\n';
				paramStr = paramStr + ':[' + 1 + ']\n';
				paramStr = paramStr + 'sessionKeyHash:[' + hsResult.sessionKeyHash + ']\n';
				paramStr = paramStr + 'encSessionKey:[' + hsResult.encSessionKey + ']\n';
				paramStr = paramStr + 'transTime:[' + transTime + ']\n';
				//alert(paramStr);
				
				rc = scObj.AccountPayTaxSndEx3 (param.readerName, 
						param.pCode, 
						termData.termNo, 
						termData.termChkCode,
						pad(param.txAmount, 14), 	
						pad(param.account, 16),	
						cardSerialNo, 
						1, 
						hsResult.sessionKeyHash, 
						hsResult.encSessionKey,
						transTime);
				
				if(rc!=0){							
					if (rc != 67113987) {
						showScMsg('bho.cratetac.error', toHex(rc));			//67113987  取消碼
					}	
					result.rc = rc;	
					result.success = false;
					return result;
				}	
				
				//設定回傳
				var resultObj = {
						'issuer' : scObj.GetIssuerBank(),
						'readerName' : param.readerName,
						'readerType' : is2ndGeneration(param.readerName) ? '2' : '1',
						'respSNUM' : scObj.GetRespSNUM(),
						'respData' : scObj.GetRespData(),
						'icCardRemark' : icCardRemark,
						'termNo' : termData.termNo,
						'termChkCode' : termData.termChkCode,
						'transTime' : transTime
				};	

				$(resultInput).val($.toJSON(resultObj));	
				
				//如果設定要驗證帳號後四碼，才作
				console.log('#### WDSTX001 是否驗證帳號後四碼=' + param.validAcctLastFourNum);
				if (param.validAcctLastFourNum) {
					var respData = showBHOCommon(3, '轉入帳號', '', 4, 4, taskId);					
					// 先驗證 respData 中的轉入帳號末四碼
					if(respData.success){
						var expectValue = param.inAccount.substring(param.inAccount.length - 4);	//轉入帳號 末四碼
						var acctSame = respData.respData.split(";;")[0] == expectValue;
								
						if (!acctSame) {
							alert('帳號後4碼輸入錯誤!');
							result.success = false;
							return result;			
						}		
					} else {		
						result.success = false;
						return result;
					}					
				}
				
			} else {
				
				//如果設定要驗證帳號後四碼，才作
				console.log('#### WDSTX001 是否驗證帳號後四碼=' + param.validAcctLastFourNum);
				if (param.validAcctLastFourNum) {
					//------------------------------------
					var respData = showBHOCommon(3, '轉入帳號', '', 4, 4, taskId);
					
					// 先驗證 respData 中的轉入帳號末四碼
					if(respData.success){
						
						var expectValue = param.inAccount.substring(param.inAccount.length - 4);	//轉入帳號 末四碼
						var acctSame = respData.respData.split(";;")[0] == expectValue;
												
						if (!acctSame) {
							alert('帳號後4碼輸入錯誤!');
							result.success = false;
							return result;			
						}		
					} else {		
						result.success = false;
						return result;
					}
					//------------------------------------						
				}
				
				rc = scObj.AccountPayTaxEx3 (param.readerName, 
						param.pCode, 
						termData.termNo, 
						termData.termChkCode,
						pad(param.txAmount, 14), 	
						pad(param.account, 16),	
						param.pin, 
						cardSerialNo, 
						1, 
						$('#_sc_AccountPayTaxEx3Template1').val(), 
						1, 
						0, 
						hsResult.sessionKeyHash, 
						hsResult.encSessionKey,
						transTime); 	
				
				if(rc!=0){							
					if (rc != 67113987) {
						showScMsg('bho.cratetac.error', toHex(rc));	//67113987  取消碼		
					}	
					result.rc = rc;	
					result.success = false;
					return result;
				}		
				
				var resultObj = {
						'issuer' : scObj.GetIssuerBank(),
						'readerName' : param.readerName,
						'readerType' : is2ndGeneration(param.readerName) ? '2' : '1',
						'respSNUM' : scObj.GetRespSNUM(),
						'respData' : scObj.GetRespData(),
						'icCardRemark' : icCardRemark,
						'termNo' : termData.termNo,
						'termChkCode' : termData.termChkCode,
						'transTime' : transTime
				};
				$(resultInput).val($.toJSON(resultObj));				
			}
			
		} catch(e) {
			alert('Exception:' + e.message);
		}	
	
	//--------------------------------------------------------------------------
	} else if (param instanceof AccountTransferParamClass) {
		
		var hsResult = doHandShake(taskId);
		if(!hsResult) {
			result.success = false;
			return result;
		}
		
		if (is2ndGeneration(param.readerName)) {

			var paramStr = '';
			paramStr = paramStr + 'readerName:[' + param.readerName + ']\n';
			paramStr = paramStr + 'pCode:[' + param.pCode + ']\n';
			paramStr = paramStr + 'termNo:[' + termData.termNo + ']\n';
			paramStr = paramStr + 'termChkCode:[' + termData.termChkCode + ']\n';
			paramStr = paramStr + 'txAmount:[' + pad(param.txAmount, 14) + ']\n';
			paramStr = paramStr + 'account:[' + pad(param.account, 16) + ']\n';
			paramStr = paramStr + 'inAccount:[' + pad(param.inAccount, 16) + ']\n';
			paramStr = paramStr + 'ReadCardSN:[' + cardSerialNo + ']\n';
			paramStr = paramStr + 'CardNoFlag:[1]\n';
			paramStr = paramStr + 'sessionKeyHash:[' + hsResult.sessionKeyHash + ']\n';
			paramStr = paramStr + 'encSessionKey:[' + hsResult.encSessionKey + ']\n';
			paramStr = paramStr + 'transTime:[' + transTime + ']\n';
			
			var callback = {
				data: ''
			};

			rc = scObj.AccountTransferSndEx3 (
					param.readerName, 
					param.pCode, 
					termData.termNo, 
					termData.termChkCode,
					pad(param.txAmount, 14), 	
					pad(param.inAccount, 16),	
					pad(param.account, 16),	
					cardSerialNo, 
					1, 
					hsResult.sessionKeyHash, 
					hsResult.encSessionKey,
					transTime,
					callback);

			paramStr = paramStr + 'rc:[' + rc + ']\n';
			if(rc!=0){							
				if (rc != 67113987) {
					doWriteScErrorLog(taskId, paramStr);
					showScMsg('bho.cratetac.error', toHex(rc));			//67113987  取消碼
				}	
				result.rc = rc;	
				result.success = false;
				return result;
			}			

			var resultObj = {
					'issuer' : scObj.GetIssuerBank(),
					'readerName' : param.readerName,
					'readerType' : is2ndGeneration(param.readerName) ? '2' : '1',
					'respSNUM' : scObj.GetRespSNUM(),
					'respData' : scObj.GetRespData(),
					'icCardRemark' : icCardRemark,
					'termNo' : termData.termNo,
					'termChkCode' : termData.termChkCode,
					'transTime' : transTime
			};	
			$(resultInput).val($.toJSON(resultObj));
			//------------------------------------
			var respData = showBHOCommon(3, '轉入帳號', '', 4, 4, taskId);
			
			// 先驗證 respData 中的轉入帳號末四碼
			if(respData.success){

				var expectValue = param.inAccount.substring(param.inAccount.length - 4);	//轉入帳號 末四碼
				var acctSame = respData.respData.split(";;")[0] == expectValue;
						
				if (!acctSame) {
					alert('帳號後4碼輸入錯誤!');
					result.success = false;
					return result;			
				}		
			} else {		
				result.success = false;
				return result;
			}
			//------------------------------------		
		} else {
			
			//------------------------------------
			var respData = showBHOCommon(3, '轉入帳號', '', 4, 4, taskId);
			
			// 先驗證 respData 中的轉入帳號末四碼
			if(respData.success){

				var expectValue = param.inAccount.substring(param.inAccount.length - 4);	//轉入帳號 末四碼
				var acctSame = respData.respData.split(";;")[0] == expectValue;
						
				if (!acctSame) {
					alert('帳號後4碼輸入錯誤!');
					result.success = false;
					return result;			
				}		
			} else {		
				result.success = false;
				return result;
			}
			//------------------------------------	
			var paramStr = '';
			paramStr = paramStr + 'readerName:[' + param.readerName + ']\n';
			paramStr = paramStr + 'pCode:[' + param.pCode + ']\n';
			paramStr = paramStr + 'termNo:[' + termData.termNo + ']\n';
			paramStr = paramStr + 'termChkCode:[' + termData.termChkCode + ']\n';
			paramStr = paramStr + 'txAmount:[' + pad(param.txAmount, 14) + ']\n';
			paramStr = paramStr + 'account:[' + pad(param.account, 16) + ']\n';
			paramStr = paramStr + 'inAccount:[' + pad(param.inAccount, 16) + ']\n';
			paramStr = paramStr + 'ReadCardSN:[' + cardSerialNo + ']\n';
			paramStr = paramStr + 'CardNoFlag:[1]\n';
			paramStr = paramStr + 'template:[' + $('#_sc_AccountPayTaxEx3Template1').val() + ']\n';
			paramStr = paramStr + 'ConfirmFlag:[1]\n';
			paramStr = paramStr + 'VerifyValFlag:[0]\n';
			paramStr = paramStr + 'sessionKeyHash:[' + hsResult.sessionKeyHash + ']\n';
			paramStr = paramStr + 'encSessionKey:[' + hsResult.encSessionKey + ']\n';
			paramStr = paramStr + 'transTime:[' + transTime + ']\n';
			//alert(paramStr);
			
			rc = scObj.AccountTransferEx3 (
					param.readerName, 
					param.pCode, 
					termData.termNo, 
					termData.termChkCode,
					pad(param.txAmount, 14), 
					pad(param.inAccount, 16),	
					pad(param.account, 16),
					param.pin, 
					cardSerialNo, 
					1, 
					$('#_sc_AccountPayTaxEx3Template1').val(), 
					1, 
					0, 
					hsResult.sessionKeyHash, 
					hsResult.encSessionKey,
					transTime); 	
			paramStr = paramStr + 'rc:[' + rc + ']\n';
			if(rc!=0){							
				if (rc != 67113987) {
					doWriteScErrorLog(taskId, paramStr);
					showScMsg('bho.cratetac.error', toHex(rc));	//67113987  取消碼									
				}	
				result.rc = rc;	
				result.success = false;
				return result;
			}		
			
			var resultObj = {
					'issuer' : scObj.GetIssuerBank(),
					'readerName' : param.readerName,
					'readerType' : is2ndGeneration(param.readerName) ? '2' : '1',
					'respSNUM' : scObj.GetRespSNUM(),
					'respData' : scObj.GetRespData(),
					'icCardRemark' : icCardRemark,
					'termNo' : termData.termNo,
					'termChkCode' : termData.termChkCode,
					'transTime' : transTime
			};
			$(resultInput).val($.toJSON(resultObj));
		}		
	//--------------------------------------------------------------------------
	} else {
		alert('傳入參數param class有誤');	
	}
	//--------------------------------------------------------------------------
	if(rc!=0){			
		
		if (rc != 67113987) {
			showScMsg('bho.cratetac.error', toHex(rc));		//67113987  取消碼	
		}	
		result.rc = rc;	
		result.success = false;
		return result;
	} else {
		result.success = true;
		result.icCardRemark = icCardRemark;	
		result.rc = rc;	
		return result;					
	}
	//----------------------------------
}


//--------------------------------------------------------------------
//執行各種BHO功能
function doMacBHOAction(param, resultInput, taskId,  trxCallBack) {

	var result = {};						//回傳結果
	var rc = 0;								//回傳代碼
	var scObj = getSecurityControlObject();	//晶片卡原件		
	//----------------------------------
	// 偵測安裝
	if (param.doDetectInstall) {
		var detectResult = detectInstall();
		if(!detectResult){
			cleanMask();
			result.success = false;
			return result;
		}		
	}
	scObj.DisconnectCard();	// add by Sky@WebComm, 如果正在獨佔模式，ListReaders()前不DisconnectCard()會讀卡失敗
	//----------------------------------
	//列出目前所有連接的讀卡機，如果有過安裝但未連接上系統時並未列出。
	rc = scObj.ListReaders();
	//----------------------------------
	//不等於0, 為失敗
	if(rc!=0){
		showScMsg('please.connect.card.reader', toHex(rc));
		result.success = false;
		return result;
	}
	//----------------------------------
	//回傳讀卡機個數。必須先執行ListReaders。  >0 成功，讀卡機的個數。 -1讀卡機不存在。
	var readerCount = scObj.GetReaderNumber();
	if(readerCount < 0 ){
		showScMsg('please.connect.card.reader');
		result.success = false;
		return result;
	}

	rc = scObj.ConnectReader(param.readerName);
	if(rc!=0){  
		showScMsg('connect.card.reader.failed', toHex(rc));		
		result.success = false;
		return result;
	}

	rc = scObj.ConnectCard(param.readerName);
	if(rc!=0){
		showScMsg('read.card.failed', toHex(rc));
		result.success = false;
		return result;
	}

	var icCardRemark = scObj.GetICCRemark();
	if(!icCardRemark){
		showScMsg('get.icc.memo.failed');
		result.success = false;
		return result;
	}				
	//--------------------------------------------------------------------------
	var cardSerialNo = scObj.ReadCardSN();
	if(!cardSerialNo){
		showScMsg('get.icc.serialno.failed');
		result.success = false;
		return result;
	}	
	
	//不是2代機, 要驗pin, 2代機交易api 會自動要pin
	if (!is2ndGeneration(param.readerName)) {
		rc = scObj.VerifyPIN(param.pin);
		if(rc!=0){
			showScMsg('', toHex(rc));
			result.success = false;
			return result;
		}				
	}
	
	var transTime = getYYYYMMDDHHMMSSDate();
	var termData = getTermDataAtmPay(taskId);
	//--------------------------------------------------------------------------
	//執行各種交易
	if (param instanceof AccountPayParamClass) {
				
		var hsResult = doHandShake(taskId);
		if(!hsResult) {
			result.success = false;
			return result;
		}
		
		try {
			if (is2ndGeneration(param.readerName)) {	
				alert('目前無支援Mac二代讀卡機');
				result.success = false;
				return result;								
			} else {
				
				//如果設定要驗證帳號後四碼，才作
				if (param.validAcctLastFourNum) {

					var cardInfo = buildBHOCommonXMLFromCard('3', '轉入帳號', '', 4, 4);
					
					if(!cardInfo){
						result.success = false;
						return result;	
					}
				
					var hsResult = doHandShake(taskId);
					if(!hsResult) {
						result.success = false;
						return result;	
					}				
					
					var finalResult = 
						{	'success' : false,
							'hsResult' : hsResult
						};						
					
					try {
						window.screenMask(null, null, 'DETAILS_MASK');
						// hack for Mac OS
						window.comp = scObj;
				
						execute("BHOCommon", 
				    		cardInfo.bhoXML, 
				    		hsResult.sessionKeyHash, 
				    		hsResult.encSessionKey, 
			
				    		function(result) {
				    		    result.allowNonTFBCard = true;
						        if (result.rtnCode != 0) {
						        	finalResult.success = false;
						        	window.cleanMask(null, 'DETAILS_MASK');
						        	return false;
						        } else { 

						        	finalResult = $.extend(finalResult, result);
						        						        
									var checkAcctLast4NumResult = checkAcctLast4Num (param, result.respData);		

									if (!checkAcctLast4NumResult) {
										result.rc = rc;	
										result.success = false;
										window.cleanMask(null, 'DETAILS_MASK');
										return result;	//有錯誤直接return
									}	
									
									var respData = {
				                        data: ''
				                    };

										rc = scObj.AccountPayTaxEx3 (param.readerName, 
												param.pCode, 
												termData.termNo, 
												termData.termChkCode,
												pad(param.txAmount, 14), 	
												pad(param.account, 16),	
												param.pin, 
												cardSerialNo, 
												1, 
												$('#_sc_AccountPayTaxEx3Template1').val(), 
												1, 
												0, 
												hsResult.sessionKeyHash, 
												hsResult.encSessionKey,
											transTime,
											respData);
										
										if(rc!=0){							
											if (rc != 67113987) {
												showScMsg('bho.cratetac.error', toHex(rc));	//67113987  取消碼		
											}	
											result.rc = rc;	
											result.success = false;
											window.cleanMask(null, 'DETAILS_MASK');
											return result;
										}							
									settingResultCallBack(resultInput, scObj, param, icCardRemark, termData, transTime, respData.data);
										
										result.success = true;
										result.icCardRemark = icCardRemark;	
										result.rc = rc;	
										window.cleanMask(null, 'DETAILS_MASK');
						    			trxCallBack(result);
						        }
							}
					    );
					} catch(e) {
						window.cleanMask(null, 'DETAILS_MASK');
						alert('Exception:' + e.message);
						result.success = false;
						return result;
					}						
					
				} else {
					window.screenMask(null, null, 'DETAILS_MASK');
					var respData = {
                        data: ''
                    };

						rc = scObj.AccountPayTaxEx3 (param.readerName, 
								param.pCode, 
								termData.termNo, 
								termData.termChkCode,
								pad(param.txAmount, 14), 	
								pad(param.account, 16),	
								param.pin, 
								cardSerialNo, 
								1, 
								$('#_sc_AccountPayTaxEx3Template1').val(), 
								1, 
								0, 
								hsResult.sessionKeyHash, 
								hsResult.encSessionKey,
							transTime,
                            respData);
						
						if(rc!=0){							
							if (rc != 67113987) {
								showScMsg('bho.cratetac.error', toHex(rc));	//67113987  取消碼		
							}	
							result.rc = rc;	
							result.success = false;
							window.cleanMask(null, 'DETAILS_MASK');
							return result;
						}							
					settingResultCallBack(resultInput, scObj, param, icCardRemark, termData, transTime, respData.data);
						
						result.success = true;
						result.icCardRemark = icCardRemark;	
						result.rc = rc;	
						
					    			trxCallBack(result);	
					}
			}
			
		} catch(e) {
			window.cleanMask(null, 'DETAILS_MASK');
			alert('Exception:' + e.message);
		}	
	
	//--------------------------------------------------------------------------
	} else if (param instanceof AccountTransferParamClass) {
			
		var hsResult = doHandShake(taskId);
		if(!hsResult) {
			result.success = false;
			return result;
		}
		
		if (is2ndGeneration(param.readerName)) {
			alert('目前無支援Mac二代讀卡機');
			result.success = false;
			return result;		
		} else {
			
			var cardInfo = buildBHOCommonXMLFromCard('3', '轉入帳號', '', 4, 4);
			
			if(!cardInfo){
				result.success = false;
				return result;	
			}
		
			var hsResult = doHandShake(taskId);
			if(!hsResult) {
				result.success = false;
				return result;	
			}				
			
			var finalResult = 
				{	'success' : false,
					'hsResult' : hsResult
				};						
			
			try {
				window.screenMask(null, null, 'DETAILS_MASK');
				
				window.comp = scObj;
		
				execute("BHOCommon", 
		    		cardInfo.bhoXML, 
		    		hsResult.sessionKeyHash, 
		    		hsResult.encSessionKey, 
	
		    		function(result) {
		    		    result.allowNonTFBCard = true;
				        if (result.rtnCode != 0) {
				        	finalResult.success = false;
				        	window.cleanMask(null, 'DETAILS_MASK');
				        	return false;
				        } else { 

				        	finalResult = $.extend(finalResult, result);
				        						        
							var checkAcctLast4NumResult = checkAcctLast4Num (param, result.respData);		

							if (!checkAcctLast4NumResult) {
								result.rc = rc;	
								result.success = false;
								window.cleanMask(null, 'DETAILS_MASK');
								return result;	//有錯誤直接return
							}	
							
							var callback = {
                                data: ''
                            };

								rc = scObj.AccountTransferEx3 (
										param.readerName, 
										param.pCode, 
										termData.termNo, 
										termData.termChkCode,
										pad(param.txAmount, 14), 
										pad(param.inAccount, 16),	
										pad(param.account, 16),
										param.pin, 
										cardSerialNo, 
										1, 
										$('#_sc_AccountPayTaxEx3Template1').val(), 
										1, 
										0, 
										hsResult.sessionKeyHash, 
										hsResult.encSessionKey,
                                transTime,
                                callback);
								
								if(rc!=0){							
									if (rc != 67113987) {
										showScMsg('bho.cratetac.error', toHex(rc));	//67113987  取消碼		
									}	
									result.rc = rc;	
									result.success = false;
									window.cleanMask(null, 'DETAILS_MASK');
									return result;
								}							
							settingResultCallBack(resultInput, scObj, param, icCardRemark, termData, transTime, callback.data);
								
								result.success = true;
								result.icCardRemark = icCardRemark;	
								result.rc = rc;	
								window.cleanMask(null, 'DETAILS_MASK');
				    			trxCallBack(result);
				        }
					}
			    );
			} catch(e) {
				alert('Exception:' + e.message);
				result.success = false;
				return result;
			}					

		}		
	//--------------------------------------------------------------------------
	} else {
		alert('傳入參數param class有誤');	
	}
	//--------------------------------------------------------------------------
	if(rc!=0){				
		if (rc != 67113987) {
			showScMsg('bho.cratetac.error', toHex(rc));		//67113987  取消碼	
		}	
		result.rc = rc;	
		result.success = false;
		return result;
	} else {
		result.success = true;
		result.icCardRemark = icCardRemark;	
		result.rc = rc;	
		return result;					
	}

	//--------------------------------------------------------------------
	//設定  reutrn Val 的 function
	function checkAcctLast4Num (param, respData) {
		var expectValue = param.inAccount.substring(param.inAccount.length - 4);	//轉入帳號 末四碼
		var acctSame = respData.split(";;")[0] == expectValue;

		if (!acctSame) {
			alert('帳號後4碼輸入錯誤!');
			return false;		
		}	else {
			//執行驗證完後的動作
			return true;
		}					
	}
	//--------------------------------------------------------------------
	//設定  reutrn Val 的 function
	function settingResultCallBack(resultInput, scObj, param, icCardRemark, termData, transTime, respData) {
		//設定回傳
		var isMac = navigator.platform.match(/Mac.*/);
		var resultObj = {
				'issuer' : scObj.GetIssuerBank(),
				'readerName' : param.readerName,
				'readerType' : is2ndGeneration(param.readerName) ? '2' : '1',
			'respSNUM' : (isMac && respData) ? respData.respSNUM : scObj.GetRespSNUM(),
			'respData' : (isMac && respData) ? respData.respEncTAC : scObj.GetRespData(),
				'icCardRemark' : icCardRemark,
				'termNo' : termData.termNo,
				'termChkCode' : termData.termChkCode,
				'transTime' : transTime
		};	
		
		$(resultInput).val($.toJSON(resultObj));	
	}
	//--------------------------------------------------------------------	
}

//--------------------------------------------------------------------
/**
 * 啟動獨佔模式
 * @returns {Boolean}
 */
function connectAllCards() {
	var scObj = getSecurityControlObject();
	//----------------------------------
	//列出目前所有連接的讀卡機，如果有過安裝但未連接上系統時並未列出。
	var rc = 0;
	scObj.DisconnectCard();
	rc = scObj.ListReaders();
	//----------------------------------
	//不等於0, 為失敗
	if(rc!=0){
		console.log('ListReaders=' + rc);
		return false;
	}
	//------------------------------------------------------
	//回傳讀卡機個數。必須先執行ListReaders。  >0 成功，讀卡機的個數。 -1讀卡機不存在。
	var readerCount = scObj.GetReaderNumber();
	if(readerCount < 0){
		console.log('GetReaderNumber=' + rc);
		return false;
	}
	//----------------------------------
	for(var i=0;i<readerCount;i++) {
		
		// get first reader name  回傳讀卡機名稱。
		var readerName = scObj.GetReaderName(i);
		if(!readerName){
			console.log('readerName is empty');
			return false;
		}
		
		//連接指定的IC卡與應用程式之間的連結
		rc = scObj.ConnectCard(readerName);
	}
	return true;
}
//--------------------------------------------------------------------
/**
 * 關閉獨佔模式
 * @returns {Boolean}
 */
function disconnectAllCards() {
	var scObj = getSecurityControlObject();
	//----------------------------------
	// 若有傳入 readerCount, 則不需要再抓一次
	var rc = 0;
	scObj.DisconnectCard();
	return true;
}
//--------------------------------------------------------------------
//繳費交易-傳入參數類別
var AccountPayParamClass = function(){};
AccountPayParamClass.prototype = {
	readerName: '',
    readerType: '',
    pin: '',
    pCode: '',
    account: '',
    inAccount: '',
    txAmount: 0,
    doDetectInstall: false,
    validAcctLastFourNum: false,
    toString: function() {        
        return 'readerName : ' + this.readerName + '\n'
        		+ 'readerType : ' + this.readerType + '\n'
        		+ 'pin : ' + this.pin + '\n'
        		+ 'pCode : ' + this.pCode + '\n'
        		+ 'account : ' + this.account + '\n'
        		+ 'txAmount : ' + this.txAmount + '\n'
        		+ 'validAcctLastFourNum : ' + this.validAcctLastFourNum
        		+ 'doDetectInstall : ' + this.doDetectInstall;
    }
};
//--------------------------------------------------------------------
//轉帳交易-傳入參數類別
var AccountTransferParamClass = function(){};
AccountTransferParamClass.prototype = {
	readerName: '',
	readerType: '',
	pin: '',
	pCode: '',
	account: '',
	inAccount: '',
	txAmount: 0,
	doDetectInstall: false,
	toString: function() {        
	return 'readerName : ' + this.readerName + '\n'
      		+ 'readerType : ' + this.readerType + '\n'
      		+ 'pin : ' + this.pin + '\n'
      		+ 'pCode : ' + this.pCode + '\n'
      		+ 'account : ' + this.account + '\n'
      		+ 'inAccount : ' + this.inAccount + '\n'
      		+ 'txAmount : ' + this.txAmount + '\n'
      		+ 'doDetectInstall : ' + this.doDetectInstall;
  }
};
//--------------------------------------------------------------------
/**
 * execute command with callback(for Mac OS plugin)
 */
function execute(command){
    if (command) {
        var args = $.makeArray(arguments).slice(1);
        //window start
        var isWin = true;
        var iswindow = !!navigator.userAgent.match(/Windows/);  
        isWin = iswindow;
        var doneFun = false;
        if (isWin && $.isFunction(args[args.length - 1]) && (!isIE64() && !isIE())) {
            doneFun = $.proxy(args.pop(), this);
        }
        //window end
        var _fun = "";
        for (var idx in args) {
            _fun += ((_fun ? "," : "") + "args[" + idx + "]");
        }
        var NetWeb = ATLActiveXControl;
        var rc;
        if((isWin && (isIE() || isIE64())) || !isWin) {
        	rc = (new Function('comp', 'command', 'args', 'return comp[command](' + _fun + ');'))(comp, command, args);
        }else if(isWin && (!isIE() && !isIE64())){
        	//cardInfo.bhoXML, HashKey1, EncKey1	
            rc = NetWeb.BHOCommon(args[0], args[1], args[2]);
        }
        //windows and use callback
        if (doneFun) {
            //default callback result 
            var result = {
                result : rc,
                command: command,
                success: rc == 0,
                rtnCode: rc,
                respData: "",
                encRspData: ""
            };
            if( rc == 0){
                result.readerName = NetWeb.GetRespData().split(';;')[0];
                result.encRspData= NetWeb.GetEncRspData();
                result.respData = NetWeb.GetRespData();
              }
            doneFun(result);
        } else {
            if (rc === 0) {
                return true;
            } else {
                if (/^-?[0-9]+$/.test(rc)) {
                    $.log("error command:" + command + " code:" + rc);
                    throw rc;
                } else {
                    return rc;
                }
            }
        }
        return rc;
    } else {
        throw "9999999990";
    }              
}
//--------------------------------------------------------------------
//taskId 呼叫者的taskId
function doHandShake(taskId){

	if (taskId == undefined) {
		taskId = '';
	}
  	var scObj = getSecurityControlObject(); 
  	var handshakeResult = {}; 
	$.ajax($.cfg.cp + "/handshake", 
		{
			async: false,
			type: 'POST',
			data: {
				'action':'initRN1',
				'keyVersion':scObj.GetAPIVersion(),
				'taskId': taskId
			},
			success: function(data){
				if(data.success) {
					if(data.hasSessionKey){
						handshakeResult = data;
					} else {
						var result = verifyRN1andSendRN2(data.clientEncRN1, data.serverSignRN1, taskId);
						if(result.success) {
							handshakeResult = result; 
						} else {
							alert(result.error);
							handshakeResult = false;
						}
					}
				} else {
					alert(data.error);
					handshakeResult = false;
				}
			},
			error: function() {
				showScMsg('init.key.failed');
				handshakeResult = false;
			}
		}
	);
	return handshakeResult;
}
//--------------------------------------------------------------------
//taskId 呼叫者的taskId
function doWriteScErrorLog(taskId, msg){

	if (taskId == undefined) {
		taskId = '';
	}
	$.ajax($.cfg.cp + "/handshake", 
		{
			async: true,
			type: 'POST',
			data: {
				'action': 'writeScErrorLog',
				'errorType': 'scapierror',
				'msg': msg,
				'taskId': taskId
			},
			success: function(data){

			},
			error: function() {
			}
		}
	);
}
//--------------------------------------------------------------------
/*
 * call HSM2500 判斷是否為新卡
 */
function doIsNewCard(acctNo, respData, respSNUM, icCardRemark, termNo, termChkCode, task_id){
	
    //alert('acctNo:' + acctNo);
    //alert('respData:' + respData);
    //alert('respSNUM:' + respSNUM);
    //alert('icCardRemark:' + icCardRemark);
    //alert('termNo:' + termNo);
    //alert('termChkCode:' + termChkCode);

	var result = {}; 
	$.ajax($.cfg.cp + "/handshake", 
		{
			async: false,
			type: 'POST',
			data: {
				'action' : 'isNewCard4WebATM',
				'acctNo' : acctNo,
				'respData' : respData,
				'respSNUM' : respSNUM,
				'icCardRemark' : icCardRemark,
				'termNo' : termNo,
				'termChkCode' : termChkCode,
				'task_id' : task_id
			},
			success: function(data){
				if(data.success) {
					result.success = true;
					result.isNewCard = data.isNewCard;
				} else {
					alert('doIsNewCard(error):' + data.error);
					result.success = false;
					result.isNewCard = false;
				}
			},
			error: function() {
				alert('doIsNewCard failed');
				result.success = false;
				result.isNewCard = false;
			}
		}
	);
	return result;

}
//--------------------------------------------------------------------
function verifyRN1andSendRN2(encRn1, encRn1Hash, taskId){
  var scObj = getSecurityControlObject();
  var rc = scObj.VerifyRN1andGenerateRN2(encRn1.length/2, encRn1, encRn1Hash.length/2, encRn1Hash);
  if(rc != 0){
	  // TODO: errorMsg
    alert('rc == ' + rc + '\n0x' + toHex(rc));
    return false;
  }
  
  var encRN2 = scObj.GetEncryptRN2();
  var encRN2Hash = scObj.GetEncryptHashRN2();
  var sessionKeyHash = scObj.GetSessionKeyHash();
  var result = {};
  	$.ajax($.cfg.cp + "/handshake", 
		{
  			async: false,
			type: 'POST',
			data: {
				'action':'verifyRN2',
				'encRN2':  encRN2,
				'encRN2Hash':  encRN2Hash,
				'sessionKeyHash': sessionKeyHash,
				'taskId' : taskId
			},
			success: function(data, status){
				result = data;
			}
		}
	);
  	if(!result.success){
		alert(result.error);
	}
  return result;
}
//--------------------------------------------------------------------
/**
 * 取得末端資訊
 */
function getTermData(taskId){
  
  var result = {};
  	$.ajax($.cfg.cp + "/handshake", 
		{
  			async: false,
			type: 'POST',
			data: {
				'action':'getTermData',
				'taskId': taskId
			},
			success: function(data, status){
				result = data;
			}
		}
	);
  	if(!result.success){
		alert(result.error);
	}
  return result;
}
//--------------------------------------------------------------------
/** 
 * 取得末端資訊
 */
function getTermDataAtmPay(taskId){

  var result = {};
  	$.ajax($.cfg.cp + "/handshake", 
		{
  			async: false,
			type: 'POST',
			data: {
				'action':'getTermDataAtmPay',
				'taskId': taskId
			},
			success: function(data, status){
				result = data;
			}
		}
	);
  	if(!result.success){
		alert(result.error);
	}
  return result;
}
//--------------------------------------------------------------------
function toHex(i) {
  runningTotal = '';
  quotient = hexQuotient(i);
  remainder = eval(i + '-(' + quotient + '* 16)');
  runningTotal = charToHex(remainder) + runningTotal;
  while( quotient >= 16) {
    savedQuotient = hexQuotient(quotient);
    remainder = eval(quotient + '-(' + savedQuotient + '* 16)');
    runningTotal = charToHex(remainder) + runningTotal;
    quotient = savedQuotient;
  } 
  return charToHex(quotient) + runningTotal ;
}
//--------------------------------------------------------------------
/* Internal method... for toHex() */
function hexQuotient(i) {
  return Math.floor(eval(i +'/ 16'));
}
//--------------------------------------------------------------------
/*Internal method*/
function charToHex(i) {
 var digit;
  if (i==10) {digit='A';}
  else if (i==11) {digit='B';}
  else if (i==12) {digit='C';}
  else if (i==13) {digit='D';}
  else if (i==14) {digit='E';}
  else if (i==15) {digit='F';}
  else {digit=i;}
  return digit;
}
//--------------------------------------------------------------------
/**
 * 取得 YYYYMMDDHHMMSS Date
 */
function getYYYYMMDDHHMMSSDate() {
	var d = new Date();
    var yyyy = d.getFullYear().toString();
    var MM = pad(d.getMonth() + 1,2);
    var dd = pad(d.getDate(), 2);
    var hh = pad(d.getHours(), 2);
    var mm = pad(d.getMinutes(), 2);
    var ss = pad(d.getSeconds(), 2);

    return yyyy + MM + dd+  hh + mm + ss;
};
//--------------------------------------------------------------------
/**
 * 處理數字左補零到指定長度
 */
function pad(number, length) {
    var str = '' + number;
    while (str.length < length) {
        str = '0' + str;
    }
    return str;
}
//--------------------------------------------------------------------
/**
 * 處理數字左補空白到指定長度securityControl.js
 */
function padBlank(number, length) {
    var str = '' + number;
    while (str.length < length) {
        str = ' ' + str;
    }
    return str;
}
//--------------------------------------------------------------------
/**
 * 字串 to Hex String
 */
function hexDecode(hexString){var r='';for(var i=0;i<hexString.length;i+=2){r+=unescape('%'+hexString.substr(i,2));}return r;}
//--------------------------------------------------------------------
/**
 * Hex String to String
 */
function hexEncode(plainString){var r='';var i=0;var h;while(i<plainString.length){h=plainString.charCodeAt(i++).toString(16);while(h.length<2){h='0'+h;}r+=h;}return r;}
//--------------------------------------------------------------------
