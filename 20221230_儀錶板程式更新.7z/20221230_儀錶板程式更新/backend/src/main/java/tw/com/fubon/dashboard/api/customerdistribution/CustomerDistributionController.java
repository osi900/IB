package tw.com.fubon.dashboard.api.customerdistribution;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.StringUtil;

/**
 * 客群分布
 */
@RestController
@RequestMapping(path = "/customer_distribution")
public class CustomerDistributionController extends ControllerBase {

    @Autowired
    private DmsService dao;

    @RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public CustomerDistributionResponse getData(@RequestBody CustomerDistributionRequest rq) {
        String snapMonth = rq.getSnapDate();
        String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());

        logger.info("snapMonth: {}, whereCondition: {}", snapMonth, whereCondition);

        CustomerDistributionResponse rs = new CustomerDistributionResponse();
        // 全體 + 受眾
        List<CustomerDistributionData> datas = dao.getCustomerDistribution(snapMonth, whereCondition);

        rs.setData(datas);
        return rs;
    }

}
