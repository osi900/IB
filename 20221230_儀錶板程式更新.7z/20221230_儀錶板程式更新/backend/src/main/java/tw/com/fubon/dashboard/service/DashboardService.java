package tw.com.fubon.dashboard.service;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import tw.com.fubon.dashboard.dao.bean.Options;
import tw.com.fubon.dashboard.dao.bean.OptionsExample;
import tw.com.fubon.dashboard.dao.bean.TagGroupVals;
import tw.com.fubon.dashboard.dao.bean.TagGroupValsExample;
import tw.com.fubon.dashboard.dao.bean.TagGroups;
import tw.com.fubon.dashboard.dao.bean.TagGroupsExample;
import tw.com.fubon.dashboard.dao.bean.Tags;
import tw.com.fubon.dashboard.dao.bean.TagsExample;
import tw.com.fubon.dashboard.dao.bean.TagsLog;
import tw.com.fubon.dashboard.dao.mapper.OptionsMapper;
import tw.com.fubon.dashboard.dao.mapper.TagGroupValsMapper;
import tw.com.fubon.dashboard.dao.mapper.TagGroupsMapper;
import tw.com.fubon.dashboard.dao.mapper.TagsLogMapper;
import tw.com.fubon.dashboard.dao.mapper.TagsMapper;

@Component
public class DashboardService {

	@Autowired
	@Qualifier("dashboardSqlSessionTemplate")
    private SqlSessionTemplate dashboardSqlTemplate;
	
	/**
	 * 取得第一層標籤
	 * @return
	 */
	public List<Tags> getLv1Tags() {
		TagsMapper mapper = dashboardSqlTemplate.getMapper(TagsMapper.class);
		TagsExample example = new TagsExample();
		TagsExample.Criteria criteria = example.createCriteria();
		criteria.andParentTagIsNull();
		return mapper.selectByExample(example);
	}
	
	/**
	 * 查詢子標籤
	 * @param parentId
	 * @return
	 */
	public List<Tags> getTagsByParentId(Long parentId) {
		TagsMapper mapper = dashboardSqlTemplate.getMapper(TagsMapper.class);
		TagsExample example = new TagsExample();
		TagsExample.Criteria criteria = example.createCriteria();
		criteria.andParentTagEqualTo(parentId);
		return mapper.selectByExample(example);
	}
	
	/**
	 * 查詢標籤選項
	 * @param tagId
	 * @return
	 */
	public List<Options> getOptionsByTagId(Long tagId, Integer parentOptId) {
		OptionsMapper mapper = dashboardSqlTemplate.getMapper(OptionsMapper.class);
		OptionsExample example = new OptionsExample();
		OptionsExample.Criteria criteria = example.createCriteria();
		criteria.andTagIdEqualTo(tagId);
		if (parentOptId != null) {
			criteria.andParentOptEqualTo(parentOptId.longValue());
		} else {
			criteria.andParentOptIsNull();
		}
		example.setOrderByClause("label");
		return mapper.selectByExample(example);
	}
	
	/**
	 * 儲存標籤群組
	 * @param group
	 * @param vals
	 */
	@Transactional("dashboardTxnManager")
	public void saveTagGroup(TagGroups group, List<TagGroupVals> vals) {
		TagGroupsMapper groupMapper = dashboardSqlTemplate.getMapper(TagGroupsMapper.class);
		groupMapper.insert(group);
		
		TagGroupValsMapper valsMapper = dashboardSqlTemplate.getMapper(TagGroupValsMapper.class);
		for (TagGroupVals val : vals) {
			val.setGroupId(group.getGroupId().longValue());
			valsMapper.insert(val);
		}
	}
	
	/**
	 * 查詢標籤群組
	 * @param userAccount
	 * @return
	 */
	public List<TagGroups> getTagGroups(String userAccount) {
		TagGroupsMapper groupMapper = dashboardSqlTemplate.getMapper(TagGroupsMapper.class);
		TagGroupsExample example = new TagGroupsExample();
		TagGroupsExample.Criteria criteria = example.createCriteria();
		criteria.andUserAcctEqualTo(userAccount);
		
		return groupMapper.selectByExample(example);
	}
	
	/**
	 * 查詢標籤群組
	 * @param groupId
	 * @return
	 */
	public List<TagGroupVals> getTagGroupVals(Integer groupId) {
		TagGroupValsMapper valsMapper = dashboardSqlTemplate.getMapper(TagGroupValsMapper.class);
		TagGroupValsExample example = new TagGroupValsExample();
		TagGroupValsExample.Criteria criteria = example.createCriteria();
		criteria.andGroupIdEqualTo(groupId.longValue());
		
		return valsMapper.selectByExample(example);
	}
	
	/**
	 * 紀錄標籤使用紀錄
	 * @param log
	 */
	public void saveTagLog(TagsLog log) {
		TagsLogMapper mapper = dashboardSqlTemplate.getMapper(TagsLogMapper.class);
		mapper.insert(log);
	}
}
