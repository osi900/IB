package tw.com.fubon.dashboard.api;

import java.util.HashMap;
import java.util.Map;

public class ResponseBase {

	private String code = "0000";
	
	private String message;
	
	private Map<String, String> payloads = new HashMap<>();

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Map<String, String> getPayloads() {
		return payloads;
	}

	public void setPayloads(Map<String, String> payloads) {
		this.payloads = payloads;
	}
	
}
