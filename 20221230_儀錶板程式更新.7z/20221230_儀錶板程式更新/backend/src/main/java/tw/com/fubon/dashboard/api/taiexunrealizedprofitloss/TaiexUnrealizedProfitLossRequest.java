package tw.com.fubon.dashboard.api.taiexunrealizedprofitloss;

import tw.com.fubon.dashboard.api.RequestBase;

public class TaiexUnrealizedProfitLossRequest extends RequestBase {

}
