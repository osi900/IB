package tw.com.fubon.dashboard.api.top10;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.filter.AuthFilter;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.ExcelGenerator;
import tw.com.fubon.dashboard.utils.StringUtil;

@RestController
@RequestMapping(path = "/top10")
public class Top10Controller extends ControllerBase {

	private static Logger _logger = LoggerFactory.getLogger(AuthFilter.class);
	
	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Top10Response getData(@RequestBody Top10Request rq) {
		String snapMonth = rq.getSnapDate();
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		
		Top10Response rs = new Top10Response();
		rs.setData(dao.getTop10Data(snapMonth, whereCondition));
		return rs;
	}
	
	/**
	 * 匯出Excel
	 * @param data
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/exportExcel", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Resource> exportExcel(@RequestBody List<Map<String, String>> data) throws Exception {
		
		return ExcelGenerator.generate((workbook) -> {
			Sheet sheet = workbook.createSheet();
			
			Row headRow = sheet.createRow(0);
			headRow.createCell(0).setCellValue("排名");
			headRow.createCell(1).setCellValue("產業");
			headRow.createCell(2).setCellValue("戶數");
			headRow.createCell(3).setCellValue("佔比(%)");
			
			DecimalFormat numFormat = new DecimalFormat("#,##0");
			for (int i = 0; i < data.size(); i++) {
				Map<String, String> rcd = data.get(i);
				
				try {
					int cnt = Integer.valueOf(rcd.get("cnt"));
					
					Row rcdRow = sheet.createRow(i + 1);
					rcdRow.createCell(0).setCellValue(rcd.get("rank"));
					rcdRow.createCell(1).setCellValue(rcd.get("industry"));
					rcdRow.createCell(2).setCellValue(numFormat.format(cnt));
					rcdRow.createCell(3).setCellValue(rcd.get("ratio"));
				} catch (NumberFormatException ex) {
					_logger.error(ex.getMessage(), ex);
				}
				
			}
			
		});
		
	}
}
