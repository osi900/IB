package tw.com.fubon.dashboard.api.accountopensource;

import tw.com.fubon.dashboard.api.RequestBase;

public class AccountOpenSourceRequest extends RequestBase {

}
