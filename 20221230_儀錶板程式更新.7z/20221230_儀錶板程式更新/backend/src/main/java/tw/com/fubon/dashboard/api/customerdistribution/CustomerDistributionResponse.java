package tw.com.fubon.dashboard.api.customerdistribution;

import java.util.List;
import tw.com.fubon.dashboard.api.ResponseBase;
import tw.com.fubon.dashboard.api.prodcontribution.ProductContributionDistributionData;

public class CustomerDistributionResponse extends ResponseBase {

	private List<CustomerDistributionData> data;

	public List<CustomerDistributionData> getData() {
		return data;
	}

	public void setData(List<CustomerDistributionData> data) {
		this.data = data;
	}
}
