package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.fubon.dashboard.api.customerdistribution.CustomerDistributionData;

public interface CustomerDistributionMapper {

    /**
     * 查詢客群分布
     *
     * @param snapDate
     * @return
     */
    List<CustomerDistributionData> getCustomerDistribution(@Param("snapDate") String snapDate,
        @Param("snapDateStart") String snapDateStart,
        @Param("snapDateEnd") String snapDateEnd,
        @Param("conditions") String conditions);
}
