package tw.com.fubon.dashboard.api.top10;

import tw.com.fubon.dashboard.api.RequestBase;

public class Top10Request extends RequestBase {

}
