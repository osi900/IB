package tw.com.fubon.dashboard.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import io.jsonwebtoken.Jwts;
import tw.com.fubon.dashboard.errors.ErrorCode;
import tw.com.fubon.dashboard.vo.BdpUserInfo;

@Component
public class AuthUtil {

	protected static final Logger logger = LoggerFactory.getLogger(AuthUtil.class);
	
	@Value("${authpro.validateurl}")
    private String authproValidateURL;
	@Value("${authpro.signingkey}")
    private String authproSigningKey;
	@Value("${authpro.user.info.url}")
	private String authproUserInfo;
	
	/**
	 * 驗證Token
	 * @param token
	 * @return
	 */
	public ErrorCode checkToken(String token) {
		HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("TOKEN", token);
        
        Map<String, String> request = new HashMap<>();
        request.put("apiPath", "/Dashboard/*");
        request.put("httpMethod", "POST");
        
        HttpEntity<Map> authRequest = new HttpEntity<>(request, headers);
        try {
        	RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<Map> result = restTemplate.postForEntity(authproValidateURL, authRequest, Map.class);
            if ("AUTH10".equals(result.getBody().get("errorCode"))) {
                logger.error("AUTH10，權限不足。TOKEN: {}", token);
                return ErrorCode.NOT_AUTH;
            }
            // JWT decode
            String userId = Jwts.parser().setSigningKey(authproSigningKey).parseClaimsJws(token).getBody().getSubject();
            logger.info("JWT認證成功。UserID:{} API:POST /Dashboard/*", userId);
            
        } catch (HttpClientErrorException e) {
            logger.error("JWT驗證完成，權限不足。TOKEN: {}", token, e);
            return ErrorCode.NOT_AUTH;
        }
        
        return ErrorCode.OK;
	}
	
	/**
	 * 取得使用者資訊
	 * @param token
	 * @return
	 */
	public BdpUserInfo getUserInfo(String token) {
		HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("TOKEN", token);
        
        Map<String, String> request = new HashMap<>();
        
        HttpEntity<Map> authRequest = new HttpEntity<>(request, headers);
        try {
        	RestTemplate restTemplate = new RestTemplate();
        	ResponseEntity<Map> result = restTemplate.exchange(authproUserInfo, HttpMethod.GET, authRequest, Map.class);
        	Map<String, Object> data = (Map<String, Object>) result.getBody().get("data");
        	
        	BdpUserInfo userInfo = new BdpUserInfo();
        	userInfo.setUserId((String) data.get("userId"));
        	userInfo.setUserAccount((String) data.get("userAccount"));
        	userInfo.setUserName((String) data.get("userName"));
        	userInfo.setStatus((String) data.get("status"));
        	userInfo.setAccountType((String) data.get("accountType"));
        	userInfo.setEmail((String) data.get("email"));
        	userInfo.setTelephone((String) data.get("telephone"));
        	userInfo.setMobile((String) data.get("mobile"));
        	userInfo.setOrganization((String) data.get("organization"));
        	userInfo.setRoleIdList((List<String>) data.get("roleIdList"));
        	userInfo.setGroupIdList((List<String>) data.get("groupIdList"));
        	
        	return userInfo;
        	
        } catch (HttpClientErrorException e) {
            logger.error("取得使用者資訊失敗", token, e);
            return null;
        }
        
	}
}
