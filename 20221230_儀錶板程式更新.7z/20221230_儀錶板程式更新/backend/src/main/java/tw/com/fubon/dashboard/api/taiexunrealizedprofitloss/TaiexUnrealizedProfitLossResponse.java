package tw.com.fubon.dashboard.api.taiexunrealizedprofitloss;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class TaiexUnrealizedProfitLossResponse extends ResponseBase {

	private List<TaiexUnrealizedProfitLossData> data;
	
	private List<TaiexUnrealizedProfitLossData> target;

	public List<TaiexUnrealizedProfitLossData> getData() {
		return data;
	}

	public void setData(List<TaiexUnrealizedProfitLossData> data) {
		this.data = data;
	}

	public List<TaiexUnrealizedProfitLossData> getTarget() {
		return target;
	}

	public void setTarget(List<TaiexUnrealizedProfitLossData> target) {
		this.target = target;
	}
	
}
