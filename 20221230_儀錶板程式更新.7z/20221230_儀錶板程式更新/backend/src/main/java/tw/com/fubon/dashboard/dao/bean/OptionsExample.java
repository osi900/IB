package tw.com.fubon.dashboard.dao.bean;

import java.util.ArrayList;
import java.util.List;

public class OptionsExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public OptionsExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andOptIdIsNull() {
            addCriterion("opt_id is null");
            return (Criteria) this;
        }

        public Criteria andOptIdIsNotNull() {
            addCriterion("opt_id is not null");
            return (Criteria) this;
        }

        public Criteria andOptIdEqualTo(Integer value) {
            addCriterion("opt_id =", value, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdNotEqualTo(Integer value) {
            addCriterion("opt_id <>", value, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdGreaterThan(Integer value) {
            addCriterion("opt_id >", value, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("opt_id >=", value, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdLessThan(Integer value) {
            addCriterion("opt_id <", value, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdLessThanOrEqualTo(Integer value) {
            addCriterion("opt_id <=", value, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdIn(List<Integer> values) {
            addCriterion("opt_id in", values, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdNotIn(List<Integer> values) {
            addCriterion("opt_id not in", values, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdBetween(Integer value1, Integer value2) {
            addCriterion("opt_id between", value1, value2, "optId");
            return (Criteria) this;
        }

        public Criteria andOptIdNotBetween(Integer value1, Integer value2) {
            addCriterion("opt_id not between", value1, value2, "optId");
            return (Criteria) this;
        }

        public Criteria andTagIdIsNull() {
            addCriterion("tag_id is null");
            return (Criteria) this;
        }

        public Criteria andTagIdIsNotNull() {
            addCriterion("tag_id is not null");
            return (Criteria) this;
        }

        public Criteria andTagIdEqualTo(Long value) {
            addCriterion("tag_id =", value, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdNotEqualTo(Long value) {
            addCriterion("tag_id <>", value, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdGreaterThan(Long value) {
            addCriterion("tag_id >", value, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdGreaterThanOrEqualTo(Long value) {
            addCriterion("tag_id >=", value, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdLessThan(Long value) {
            addCriterion("tag_id <", value, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdLessThanOrEqualTo(Long value) {
            addCriterion("tag_id <=", value, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdIn(List<Long> values) {
            addCriterion("tag_id in", values, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdNotIn(List<Long> values) {
            addCriterion("tag_id not in", values, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdBetween(Long value1, Long value2) {
            addCriterion("tag_id between", value1, value2, "tagId");
            return (Criteria) this;
        }

        public Criteria andTagIdNotBetween(Long value1, Long value2) {
            addCriterion("tag_id not between", value1, value2, "tagId");
            return (Criteria) this;
        }

        public Criteria andLabelIsNull() {
            addCriterion("label is null");
            return (Criteria) this;
        }

        public Criteria andLabelIsNotNull() {
            addCriterion("label is not null");
            return (Criteria) this;
        }

        public Criteria andLabelEqualTo(String value) {
            addCriterion("label =", value, "label");
            return (Criteria) this;
        }

        public Criteria andLabelNotEqualTo(String value) {
            addCriterion("label <>", value, "label");
            return (Criteria) this;
        }

        public Criteria andLabelGreaterThan(String value) {
            addCriterion("label >", value, "label");
            return (Criteria) this;
        }

        public Criteria andLabelGreaterThanOrEqualTo(String value) {
            addCriterion("label >=", value, "label");
            return (Criteria) this;
        }

        public Criteria andLabelLessThan(String value) {
            addCriterion("label <", value, "label");
            return (Criteria) this;
        }

        public Criteria andLabelLessThanOrEqualTo(String value) {
            addCriterion("label <=", value, "label");
            return (Criteria) this;
        }

        public Criteria andLabelLike(String value) {
            addCriterion("label like", value, "label");
            return (Criteria) this;
        }

        public Criteria andLabelNotLike(String value) {
            addCriterion("label not like", value, "label");
            return (Criteria) this;
        }

        public Criteria andLabelIn(List<String> values) {
            addCriterion("label in", values, "label");
            return (Criteria) this;
        }

        public Criteria andLabelNotIn(List<String> values) {
            addCriterion("label not in", values, "label");
            return (Criteria) this;
        }

        public Criteria andLabelBetween(String value1, String value2) {
            addCriterion("label between", value1, value2, "label");
            return (Criteria) this;
        }

        public Criteria andLabelNotBetween(String value1, String value2) {
            addCriterion("label not between", value1, value2, "label");
            return (Criteria) this;
        }

        public Criteria andOptValueIsNull() {
            addCriterion("opt_value is null");
            return (Criteria) this;
        }

        public Criteria andOptValueIsNotNull() {
            addCriterion("opt_value is not null");
            return (Criteria) this;
        }

        public Criteria andOptValueEqualTo(String value) {
            addCriterion("opt_value =", value, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueNotEqualTo(String value) {
            addCriterion("opt_value <>", value, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueGreaterThan(String value) {
            addCriterion("opt_value >", value, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueGreaterThanOrEqualTo(String value) {
            addCriterion("opt_value >=", value, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueLessThan(String value) {
            addCriterion("opt_value <", value, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueLessThanOrEqualTo(String value) {
            addCriterion("opt_value <=", value, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueLike(String value) {
            addCriterion("opt_value like", value, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueNotLike(String value) {
            addCriterion("opt_value not like", value, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueIn(List<String> values) {
            addCriterion("opt_value in", values, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueNotIn(List<String> values) {
            addCriterion("opt_value not in", values, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueBetween(String value1, String value2) {
            addCriterion("opt_value between", value1, value2, "optValue");
            return (Criteria) this;
        }

        public Criteria andOptValueNotBetween(String value1, String value2) {
            addCriterion("opt_value not between", value1, value2, "optValue");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andSrcColIsNull() {
            addCriterion("src_col is null");
            return (Criteria) this;
        }

        public Criteria andSrcColIsNotNull() {
            addCriterion("src_col is not null");
            return (Criteria) this;
        }

        public Criteria andSrcColEqualTo(String value) {
            addCriterion("src_col =", value, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColNotEqualTo(String value) {
            addCriterion("src_col <>", value, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColGreaterThan(String value) {
            addCriterion("src_col >", value, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColGreaterThanOrEqualTo(String value) {
            addCriterion("src_col >=", value, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColLessThan(String value) {
            addCriterion("src_col <", value, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColLessThanOrEqualTo(String value) {
            addCriterion("src_col <=", value, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColLike(String value) {
            addCriterion("src_col like", value, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColNotLike(String value) {
            addCriterion("src_col not like", value, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColIn(List<String> values) {
            addCriterion("src_col in", values, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColNotIn(List<String> values) {
            addCriterion("src_col not in", values, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColBetween(String value1, String value2) {
            addCriterion("src_col between", value1, value2, "srcCol");
            return (Criteria) this;
        }

        public Criteria andSrcColNotBetween(String value1, String value2) {
            addCriterion("src_col not between", value1, value2, "srcCol");
            return (Criteria) this;
        }

        public Criteria andParentOptIsNull() {
            addCriterion("parent_opt is null");
            return (Criteria) this;
        }

        public Criteria andParentOptIsNotNull() {
            addCriterion("parent_opt is not null");
            return (Criteria) this;
        }

        public Criteria andParentOptEqualTo(Long value) {
            addCriterion("parent_opt =", value, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptNotEqualTo(Long value) {
            addCriterion("parent_opt <>", value, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptGreaterThan(Long value) {
            addCriterion("parent_opt >", value, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptGreaterThanOrEqualTo(Long value) {
            addCriterion("parent_opt >=", value, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptLessThan(Long value) {
            addCriterion("parent_opt <", value, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptLessThanOrEqualTo(Long value) {
            addCriterion("parent_opt <=", value, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptIn(List<Long> values) {
            addCriterion("parent_opt in", values, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptNotIn(List<Long> values) {
            addCriterion("parent_opt not in", values, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptBetween(Long value1, Long value2) {
            addCriterion("parent_opt between", value1, value2, "parentOpt");
            return (Criteria) this;
        }

        public Criteria andParentOptNotBetween(Long value1, Long value2) {
            addCriterion("parent_opt not between", value1, value2, "parentOpt");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}