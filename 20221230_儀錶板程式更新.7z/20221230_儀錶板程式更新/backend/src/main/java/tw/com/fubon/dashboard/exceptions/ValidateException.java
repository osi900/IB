package tw.com.fubon.dashboard.exceptions;

import java.util.Map;

@SuppressWarnings("serial")
public class ValidateException extends Exception {

	private Map<String, String> errors;
	
	/**
     * ValidateException 建構子
     * @param message 例外訊息
     */
    public ValidateException(Map<String, String> errors) {
        this.errors = errors;
    }
	
	/**
     * ValidateException 預設建構子
     */
    public ValidateException() {
        super();
    }
    
    /**
     * ValidateException 建構子
     * @param message 例外訊息
     */
    public ValidateException(String message) {
        super(message);
    }
    
    /**
     * ValidateException 建構子
     * @param message 例外訊息
     * @param cause 根源例外元素
     */
    public ValidateException(String message, Throwable cause) {
        super(message, cause);
    }
    
    /**
     * ValidateException 建構子
     * @param cause 根源例外元素
     */
    public ValidateException(Throwable cause) {
        super(cause);
    }

	public Map<String, String> getErrors() {
		return errors;
	}

	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}
    
}
