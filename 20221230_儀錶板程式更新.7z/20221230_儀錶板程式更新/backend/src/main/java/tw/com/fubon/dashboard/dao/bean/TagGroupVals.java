package tw.com.fubon.dashboard.dao.bean;

import java.io.Serializable;

public class TagGroupVals implements Serializable {
    private Integer tagGroupValsId;

    private Long groupId;

    private String optType;

    private String tagName;

    private String tagOp;

    private String tagVal;

    private String tagVal2;

    private static final long serialVersionUID = 1L;

    public Integer getTagGroupValsId() {
        return tagGroupValsId;
    }

    public void setTagGroupValsId(Integer tagGroupValsId) {
        this.tagGroupValsId = tagGroupValsId;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public String getOptType() {
        return optType;
    }

    public void setOptType(String optType) {
        this.optType = optType == null ? null : optType.trim();
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName == null ? null : tagName.trim();
    }

    public String getTagOp() {
        return tagOp;
    }

    public void setTagOp(String tagOp) {
        this.tagOp = tagOp == null ? null : tagOp.trim();
    }

    public String getTagVal() {
        return tagVal;
    }

    public void setTagVal(String tagVal) {
        this.tagVal = tagVal == null ? null : tagVal.trim();
    }

    public String getTagVal2() {
        return tagVal2;
    }

    public void setTagVal2(String tagVal2) {
        this.tagVal2 = tagVal2 == null ? null : tagVal2.trim();
    }
}