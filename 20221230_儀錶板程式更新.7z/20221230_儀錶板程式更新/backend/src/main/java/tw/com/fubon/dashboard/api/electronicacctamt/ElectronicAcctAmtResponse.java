package tw.com.fubon.dashboard.api.electronicacctamt;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class ElectronicAcctAmtResponse extends ResponseBase {

	private List<ElectronicAcctAmtData> data;

	public List<ElectronicAcctAmtData> getData() {
		return data;
	}

	public void setData(List<ElectronicAcctAmtData> data) {
		this.data = data;
	}
	
}
