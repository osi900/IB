package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.taiexrealizedprofitloss.TaiexRealizedProfitLossData;

public interface TaiexRealizedProfitLossMapper {

    /**
     * 【客戶賺錢/賠錢】-台股已實現損益
     *
     * @param snapDate
     * @return
     */
    public List<TaiexRealizedProfitLossData> getTaiexRealizedProfitLoss(
        @Param("snapDate") String snapDate,
        @Param("snapDateStart") String snapDateStart,
        @Param("snapDateEnd") String snapDateEnd,
        @Param("conditions") String conditions);

}
