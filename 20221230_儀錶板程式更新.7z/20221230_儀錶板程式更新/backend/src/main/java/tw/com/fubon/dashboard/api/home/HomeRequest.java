package tw.com.fubon.dashboard.api.home;

import java.util.List;
import java.util.Map;

import tw.com.fubon.dashboard.api.RequestBase;
import tw.com.fubon.dashboard.vo.Filter;

public class HomeRequest extends RequestBase {

	private String groupName;
	
	private Map<String, List<Filter>> tags;
	
	private Integer groupId;
	
	@Override
	public void validate() {
		
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Map<String, List<Filter>> getTags() {
		return tags;
	}

	public void setTags(Map<String, List<Filter>> tags) {
		this.tags = tags;
	}

}
