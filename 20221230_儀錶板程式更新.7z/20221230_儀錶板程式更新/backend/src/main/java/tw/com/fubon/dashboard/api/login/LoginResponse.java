package tw.com.fubon.dashboard.api.login;

import tw.com.fubon.dashboard.api.ResponseBase;

public class LoginResponse extends ResponseBase {

}
