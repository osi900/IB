package tw.com.fubon.dashboard.api.age;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class AgeResponse extends ResponseBase {

	private List<AgeData> data;

	public List<AgeData> getData() {
		return data;
	}

	public void setData(List<AgeData> data) {
		this.data = data;
	}
	
}
