package tw.com.fubon.dashboard.api.electronicacctamt;

import java.math.BigDecimal;

public class ElectronicAcctAmtData {

    /**  */
    private String seq;
    /** 月均交易量級距 */
	private String product;
	/** 電子戶數 */
	private Long electronicAccount;
	/** 人工戶數 */
    private Long artificialAccount;
	/** 電子戶佔比 */
	private BigDecimal elecAcctProportion;
	/** 人工戶佔比 */
    private BigDecimal artiAcctProportion;
	/** 電子金額 */
	private BigDecimal electronicAmount;
	/** 人工金額 */
    private BigDecimal artificialAmount;
    /** 電子金額佔比 */
    private BigDecimal elecAmountProportion;
    /** 人工金額佔比 */
    private BigDecimal artiAmountProportion;

    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }

    /**
     * @return the product
     */
    public String getProduct() {
        return product;
    }

    /**
     * @param product the product to set
     */
    public void setProduct(String product) {
        this.product = product;
    }

    /**
     * @return the electronicAccount
     */
    public Long getElectronicAccount() {
        return electronicAccount;
    }

    /**
     * @param electronicAccount the electronicAccount to set
     */
    public void setElectronicAccount(Long electronicAccount) {
        this.electronicAccount = electronicAccount;
    }

    /**
     * @return the artificialAccount
     */
    public Long getArtificialAccount() {
        return artificialAccount;
    }

    /**
     * @param artificialAccount the artificialAccount to set
     */
    public void setArtificialAccount(Long artificialAccount) {
        this.artificialAccount = artificialAccount;
    }

    /**
     * @return the elecAcctProportion
     */
    public BigDecimal getElecAcctProportion() {
        return elecAcctProportion;
    }

    /**
     * @param elecAcctProportion the elecAcctProportion to set
     */
    public void setElecAcctProportion(BigDecimal elecAcctProportion) {
        this.elecAcctProportion = elecAcctProportion;
    }

    /**
     * @return the artiAcctProportion
     */
    public BigDecimal getArtiAcctProportion() {
        return artiAcctProportion;
    }

    /**
     * @param artiAcctProportion the artiAcctProportion to set
     */
    public void setArtiAcctProportion(BigDecimal artiAcctProportion) {
        this.artiAcctProportion = artiAcctProportion;
    }

    /**
     * @return the electronicAmount
     */
    public BigDecimal getElectronicAmount() {
        return electronicAmount;
    }

    /**
     * @param electronicAmount the electronicAmount to set
     */
    public void setElectronicAmount(BigDecimal electronicAmount) {
        this.electronicAmount = electronicAmount;
    }

    /**
     * @return the artificialAmount
     */
    public BigDecimal getArtificialAmount() {
        return artificialAmount;
    }

    /**
     * @param artificialAmount the artificialAmount to set
     */
    public void setArtificialAmount(BigDecimal artificialAmount) {
        this.artificialAmount = artificialAmount;
    }

    /**
     * @return the elecAmountProportion
     */
    public BigDecimal getElecAmountProportion() {
        return elecAmountProportion;
    }

    /**
     * @param elecAmountProportion the elecAmountProportion to set
     */
    public void setElecAmountProportion(BigDecimal elecAmountProportion) {
        this.elecAmountProportion = elecAmountProportion;
    }

    /**
     * @return the artiAmountProportion
     */
    public BigDecimal getArtiAmountProportion() {
        return artiAmountProportion;
    }

    /**
     * @param artiAmountProportion the artiAmountProportion to set
     */
    public void setArtiAmountProportion(BigDecimal artiAmountProportion) {
        this.artiAmountProportion = artiAmountProportion;
    }
    



	
}
