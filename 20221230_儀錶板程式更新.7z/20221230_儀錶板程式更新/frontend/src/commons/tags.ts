export interface TagData{
    id: string;
    name: string;
    icon: string;
    children: TagDataSec[];
}

export interface TagDataSec {
    id: string;
    name: string;
    children: TagDataThird[];
}

export interface TagDataThird {
    id: string;
	type?: string;
    name: string;
	nameEN?: string; 
	nameCH?: string; 
	desc?: string;
    options: TagDataOptoin[];
}

export interface TagDataOptoin {
	label: string;
	value: string;
	name?: string; 
	colName?: string;
	options?: TagDataOptoin[];
	source?:TagDataOptoin[];
	branch?: TagDataOptoin[];
	segment?: TagDataOptoin[];
}

export const TAG_DATA: TagData[] = [
	{ id: "1", name: "顧客屬性", icon: 'fa-user', children: [
			{ id: "1", name: "基本資料", children: [
					{id: "0", type:"TIME", name: "測試", nameEN: "ACCT_OPEN_DATE", nameCH: "測試", options: []},
					{ id: "1", type: "CHECKBOX", name: "年齡", nameEN: "AGELEVEL", nameCH: "年齡", desc: "客戶的年齡層區間，20歲以上每10歲1個區間直到60歲", options: [
							{ label: 'NULL', value: '', colName: "AGE_DESC" },
							{ label: '未滿20歲', value: '0-19歲', colName: "AGE_DESC" },
							{ label: '20-29歲', value: '20-29歲', colName: "AGE_DESC" },
							{ label: '30-39歲', value: '30-39歲', colName: "AGE_DESC" },
							{ label: '40-49歲', value: '40-49歲', colName: "AGE_DESC" },
							{ label: '50-59歲', value: '50-59歲', colName: "AGE_DESC" },
							{ label: '60歲以上', value: '60歲以上', colName: "AGE_DESC" },
						] 
					},
					{ id: "2", type: "CHECKBOX", name: "性別", nameEN: "GENDER", nameCH: "性別", desc: "客戶性別", options: [
							{ label: 'NULL', value: '', colName: "GENDER_DESC" },
							{ label: '女', value: '女', colName: "GENDER_DESC" },
							{ label: '男', value: '男', colName: "GENDER_DESC" },
						] 
					},
					{ id: "3", type: "CHECKBOX", name: "星座", nameEN: "CONSTELLATION", nameCH: "星座", desc: "客戶星座", options: [
							{ label: '巨蟹座', value: '巨蟹座', colName: "CONSTALLA_DESC" },
							{ label: '射手座', value: '射手座', colName: "CONSTALLA_DESC" },
							{ label: '獅子座', value: '獅子座', colName: "CONSTALLA_DESC" },
							{ label: '摩羯座', value: '摩羯座', colName: "CONSTALLA_DESC" },
							{ label: '天蠍座', value: '天蠍座', colName: "CONSTALLA_DESC" },
							{ label: '水瓶座', value: '水瓶座', colName: "CONSTALLA_DESC" },
							{ label: '雙魚座', value: '雙魚座', colName: "CONSTALLA_DESC" },
							{ label: '處女座', value: '處女座', colName: "CONSTALLA_DESC" },
							{ label: '牡羊座', value: '牡羊座', colName: "CONSTALLA_DESC" },
							{ label: '金牛座', value: '金牛座', colName: "CONSTALLA_DESC" },
							{ label: '天秤座', value: '天秤座', colName: "CONSTALLA_DESC" },
							{ label: '雙子座', value: '雙子座', colName: "CONSTALLA_DESC" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "生肖", nameEN: "ZODIARC", nameCH: "生肖", desc: "", options: [ 
							{ label: '鼠', value: '鼠', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '牛', value: '牛', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '虎', value: '虎', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '兔', value: '兔', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '龍', value: '龍', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '蛇', value: '蛇', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '馬', value: '馬', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '羊', value: '羊', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '猴', value: '猴', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '雞', value: '雞', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '狗', value: '狗', colName: "CHINESE_ZODIAC_DESC" },
							{ label: '豬', value: '豬', colName: "CHINESE_ZODIAC_DESC" },
						]
					},
					
					{ id: "5", type: "MCHECKBOX", name: "通訊地址", nameEN: "RSD_CITY_NAME", nameCH: "通訊地址", desc: "客戶通訊地址之縣市及區域", options: [
							{ label: '台北市', value: '台北市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '中正區', value: '中正區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大同區', value: '大同區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '中山區', value: '中山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '松山區', value: '松山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大安區', value: '大安區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '萬華區', value: '萬華區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '信義區', value: '信義區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '士林區', value: '士林區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北投區', value: '北投區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '內湖區', value: '內湖區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '南港區', value: '南港區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '文山區', value: '文山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '新北市', value: '新北市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '板橋區', value: '板橋區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '新莊區', value: '新莊區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '中和區', value: '中和區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '永和區', value: '永和區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '土城區', value: '土城區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '樹林區', value: '樹林區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '三峽區', value: '三峽區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '鶯歌區', value: '鶯歌區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '三重區', value: '三重區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '五股區', value: '五股區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '泰山區', value: '泰山區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '林口區', value: '林口區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '八里區', value: '八里區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '淡水區', value: '淡水區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '三芝區', value: '三芝區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '石門區', value: '石門區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '金山區', value: '金山區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '萬里區', value: '萬里區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '汐止區', value: '汐止區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '瑞芳區', value: '瑞芳區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '貢寮區', value: '貢寮區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '平溪區', value: '平溪區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '雙溪區', value: '雙溪區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '新店區', value: '新店區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '深坑區', value: '深坑區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '石碇區', value: '石碇區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '坪林區', value: '坪林區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
									{ label: '烏來區', value: '烏來區', name:'通訊_區',colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '桃園市', value: '桃園市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '桃園區', value: '桃園區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '中壢區', value: '中壢區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '平鎮區', value: '平鎮區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '八德區', value: '八德區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '楊梅區', value: '楊梅區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '蘆竹區', value: '蘆竹區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大溪區', value: '大溪區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '龍潭區', value: '龍潭區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '龜山區', value: '龜山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大園區', value: '大園區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '觀音區', value: '觀音區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新屋區', value: '新屋區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '復新區', value: '復新區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '新竹縣', value: '新竹縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '竹北市', value: '竹北市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '竹東鎮', value: '竹東鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新埔鎮', value: '新埔鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '關西鎮', value: '關西鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '湖口鄉', value: '湖口鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新豐鄉', value: '新豐鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '峨嵋鄉', value: '峨嵋鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '寶山鄉', value: '寶山鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北埔鄉', value: '北埔鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '芎林鄉', value: '芎林鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '橫山鄉', value: '橫山鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '尖石鄉', value: '尖石鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '五峰鄉', value: '五峰鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '新竹市', value: '新竹市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '東區', value: '東區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北區', value: '北區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '香山區', value: '香山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '苗栗縣', value: '苗栗縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '苗栗市', value: '苗栗市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '頭份市', value: '頭份市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '竹南鎮', value: '竹南鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '後龍鎮', value: '後龍鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '通霄鎮', value: '通霄鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '苑裡鎮', value: '苑裡鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '卓蘭鎮', value: '卓蘭鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '造橋鄉', value: '造橋鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '西湖鄉', value: '西湖鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '頭屋鄉', value: '頭屋鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '公館鄉', value: '公館鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '銅鑼鄉', value: '銅鑼鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '三義鄉', value: '三義鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大湖鄉', value: '大湖鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '獅潭鄉', value: '獅潭鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '三灣鄉', value: '三灣鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '南庄鄉', value: '南庄鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '泰安鄉', value: '泰安鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '台中市', value: '台中市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '中區', value: '中區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東區', value: '東區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '南區', value: '南區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '西區', value: '西區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北區', value: '北區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北屯區', value: '北屯區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '西屯區', value: '西屯區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '南屯區', value: '南屯區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '太平區', value: '太平區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大里區', value: '大里區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '霧峰區', value: '霧峰區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '烏日區', value: '烏日區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '豐原區', value: '豐原區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '后里區', value: '后里區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '石岡區', value: '石岡區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東勢區', value: '東勢區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新社區', value: '新社區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '潭子區', value: '潭子區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大雅區', value: '大雅區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '神岡區', value: '神岡區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大肚區', value: '大肚區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '沙鹿區', value: '沙鹿區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '龍井區', value: '龍井區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '梧棲區', value: '梧棲區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '清水區', value: '清水區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大甲區', value: '大甲區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '外埔區', value: '外埔區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大安區', value: '大安區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '和平區', value: '和平區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '彰化縣', value: '彰化縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '彰化市', value: '彰化市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '員林市', value: '員林市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '和美鎮', value: '和美鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鹿港鎮', value: '鹿港鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '溪湖鎮', value: '溪湖鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '二林鎮', value: '二林鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '田中鎮', value: '田中鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北斗鎮', value: '北斗鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '花壇鄉', value: '花壇鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '芬園鄉', value: '芬園鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大村鄉', value: '大村鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '永靖鄉', value: '永靖鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '伸港鄉', value: '伸港鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '線西鄉', value: '線西鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '福興鄉', value: '福興鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '秀水鄉', value: '秀水鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '埔心鄉', value: '埔心鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '埔鹽鄉', value: '埔鹽鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大城鄉', value: '大城鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '芳苑鄉', value: '芳苑鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '竹塘鄉', value: '竹塘鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '社頭鄉', value: '社頭鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '二水鄉', value: '二水鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '田尾鄉', value: '田尾鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '埤頭鄉', value: '埤頭鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '溪州鄉', value: '溪州鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '雲林縣', value: '雲林縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '斗六市', value: '斗六市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '斗南鎮', value: '斗南鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '林內鎮', value: '林內鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '古坑鄉', value: '古坑鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大埤鄉', value: '大埤鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '莿桐鄉', value: '莿桐鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '虎尾鎮', value: '虎尾鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '西螺鎮', value: '西螺鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '土庫鎮', value: '土庫鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '褒忠鄉', value: '褒忠鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '二崙鄉', value: '二崙鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '崙背鄉', value: '崙背鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '麥寮鄉', value: '麥寮鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '臺西鄉', value: '臺西鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東勢鄉', value: '東勢鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北港鄉', value: '北港鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '元長鄉', value: '元長鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '四湖鄉', value: '四湖鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '口湖鄉', value: '口湖鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '水林鄉', value: '水林鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '嘉義市', value: '嘉義市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '東區', value: '東區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '西區', value: '西區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '嘉義縣', value: '嘉義縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '太保市', value: '太保市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '朴子市', value: '朴子市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '布袋鎮', value: '布袋鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大林鎮', value: '大林鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '民雄鄉', value: '民雄鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '溪口鄉', value: '溪口鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新港鄉', value: '新港鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '六腳鄉', value: '六腳鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東石鄉', value: '東石鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '義竹鄉', value: '義竹鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鹿草鄉', value: '鹿草鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '水上鄉', value: '水上鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '中埔鄉', value: '中埔鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '竹崎鄉', value: '竹崎鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '梅山鄉', value: '梅山鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '番路鄉', value: '番路鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大埔鄉', value: '大埔鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '阿里山鄉', value: '阿里山鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },

								]
							},
							{ label: '台南市', value: '台南市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '中西區', value: '中西區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東區', value: '東區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '南區', value: '南區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北區', value: '北區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '安平區', value: '安平區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '安南區', value: '安南區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '永康區', value: '永康區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '歸仁區', value: '歸仁區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新化區', value: '新化區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '左鎮區', value: '左鎮區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '玉井區', value: '玉井區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '楠西區', value: '楠西區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '南化區', value: '南化區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '仁德區', value: '仁德區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '關廟區', value: '關廟區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '龍崎區', value: '龍崎區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '官田區', value: '官田區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '麻豆區', value: '麻豆區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '佳里區', value: '佳里區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '西港區', value: '西港區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '七股區', value: '七股區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '將軍區', value: '將軍區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '學甲區', value: '學甲區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北門區', value: '北門區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新營區', value: '新營區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '後壁區', value: '後壁區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '白河區', value: '白河區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東山區', value: '東山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '六甲區', value: '六甲區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '下營區', value: '下營區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '柳營區', value: '柳營區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鹽水區', value: '鹽水區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '善化區', value: '善化區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大內區', value: '大內區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '山上區', value: '山上區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新市區', value: '新市區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '安定區', value: '安定區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '高雄市', value: '高雄市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '楠梓區', value: '楠梓區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '左營區', value: '左營區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鼓山區', value: '鼓山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '三民區', value: '三民區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鹽程區', value: '鹽埕區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '前金區', value: '前金區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新興區', value: '新興區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '苓雅區', value: '苓雅區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '前鎮區', value: '前鎮區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '旗津區', value: '旗津區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '小港區', value: '小港區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鳳山區', value: '鳳山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大寮區', value: '大寮區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鳥松區', value: '鳥松區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '林園區', value: '林園區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '仁武區', value: '仁武區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大樹區', value: '大樹區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大社區', value: '大社區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '岡山區', value: '岡山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '路竹區', value: '路竹區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '橋頭區', value: '橋頭區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '梓官區', value: '梓官區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '彌陀區', value: '彌陀區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '永安區', value: '永安區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '燕巢區', value: '燕巢區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '田寮區', value: '田寮區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '阿蓮區', value: '阿蓮區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '茄萣區', value: '茄萣區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '湖內區', value: '湖內區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '旗山區', value: '旗山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '美濃區', value: '美濃區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '內門區', value: '內門區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '杉林區', value: '杉林區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '甲仙區', value: '甲仙區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '六龜區', value: '六龜區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '茂林區', value: '茂林區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '桃源區', value: '桃園區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '那瑪夏區', value: '那瑪夏區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '屏東縣', value: '屏東縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '屏東市', value: '屏東市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '潮州鎮', value: '潮州鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東港鎮', value: '東港鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '恆春鎮', value: '恆春鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '萬丹鄉', value: '萬丹鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '崁頂鄉', value: '崁頂鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新園鄉', value: '新園鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '林邊鄉', value: '林邊鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '南州鄉', value: '南州鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '琉球鄉', value: '琉球鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '枋寮鄉', value: '枋寮鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '枋山鄉', value: '枋山鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '車城鄉', value: '車城鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '滿洲鄉', value: '滿洲鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '高樹鄉', value: '高樹鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '九如鄉', value: '九如鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鹽埔鄉', value: '鹽埔鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '里港鄉', value: '里港鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '內埔鄉', value: '內埔鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '竹田鄉', value: '竹田鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '長治鄉', value: '長治鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '麟洛鄉', value: '麟洛鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '萬巒鄉', value: '萬巒鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新埤鄉', value: '新埤鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '佳冬鄉', value: '佳冬鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '霧臺鄉', value: '霧臺鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '泰武鄉', value: '泰武鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '瑪家鄉', value: '瑪家鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '來義鄉', value: '來義鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '春日鄉', value: '春日鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '獅子鄉', value: '獅子鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '牡丹鄉', value: '牡丹鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '三地門鄉', value: '三地門鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '臺東縣', value: '臺東縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '台東市', value: '台東市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '成功鎮', value: '成功鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '關山鎮', value: '關山鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '長濱鄉', value: '長濱鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '池上鄉', value: '池上鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東河鄉', value: '東河鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鹿野鄉', value: '鹿野鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '卑南鄉', value: '卑南鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大武鄉', value: '大武鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '綠島鄉', value: '綠島鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '太麻里鄉', value: '太麻里鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '海端鄉', value: '海端鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '延平鄉', value: '延平鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '金峰鄉', value: '金峰鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '達仁鄉', value: '達仁鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '蘭嶼鄉', value: '蘭嶼鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '花蓮縣', value: '花蓮縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '花蓮市', value: '花蓮市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '吉安鄉', value: '吉安鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '壽豐鄉', value: '壽豐鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '新城鄉', value: '新城鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鳳林鎮', value: '鳳林鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '光復鄉', value: '光復鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '玉里鎮', value: '玉里鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '豐濱鄉', value: '豐濱鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '瑞穗鄉', value: '瑞穗鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '富里鄉', value: '富里鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '秀林鄉', value: '修林鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '萬榮鄉', value: '萬榮鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '卓溪鄉', value: '卓溪鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '南投縣', value: '南投縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '南投市', value: '南投市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '埔里鎮', value: '埔里鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '草屯鎮', value: '草屯鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '竹山鎮', value: '竹山鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '集集鎮', value: '集集鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '名間鄉', value: '名間鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '鹿谷鄉', value: '鹿谷鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '中寮鄉', value: '中寮鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '魚池鄉', value: '魚池鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '國姓鄉', value: '國姓鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '水里鄉', value: '水里鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '信義鄉', value: '信義鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '仁愛鄉', value: '仁愛鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '宜蘭縣', value: '宜蘭縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '宜蘭市', value: '宜蘭市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '頭城鎮', value: '頭城鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '礁溪鄉', value: '礁溪鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '壯圍鄉', value: '壯圍鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '員山鄉', value: '員山鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '羅東鎮', value: '羅東鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '蘇澳鎮', value: '蘇澳鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '五結鄉', value: '五結鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '三星鄉', value: '三星鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '冬山鄉', value: '東山鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '大同鄉', value: '大同鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '南澳鄉', value: '南澳鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '基隆市', value: '基隆市', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '仁愛區', value: '仁愛區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '中正區', value: '中正區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '信義區', value: '信義區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '中山區', value: '中山區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '安樂區', value: '安樂區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '暖暖區', value: '暖暖區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '七堵區', value: '七堵區', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '澎湖縣', value: '澎湖縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '馬公市', value: '馬公市', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '湖西鄉', value: '湖西鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '白沙鄉', value: '白沙鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '西嶼鄉', value: '西嶼鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '望安鄉', value: '望安鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '七美鄉', value: '七美鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '金門縣', value: '金門縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '金城鎮', value: '金城鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '金湖鎮', value: '金湖鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '金沙鎮', value: '金沙鎮', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '金寧鄉', value: '金寧鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '烈嶼鄉', value: '烈嶼鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '烏坵鄉', value: '烏坵鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
							{ label: '金門縣', value: '金門縣', name:'通訊_縣市', colName: 'RSD_CITY_NAME', options:[
									{ label: '南竿鄉', value: '南竿鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '北竿鄉', value: '北竿鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '莒光鄉', value: '莒光鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
									{ label: '東引鄉', value: '東引鄉', name:'通訊_區', colName: 'RSD_CITY_AREA' },
								]
							},
						]
					},	
					{ id: "6", type: "CHECKBOX", name: "線上開戶職業", nameEN: "OCCUPATION", nameCH: "線上開戶職業", desc: "", options: [
							{ label: 'A.製造業', value: 'A.製造業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'B.醫療保健及社會工作服務業', value: 'B.醫療保健及社會工作服務業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'C.批發及零售業', value: 'C.批發及零售業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'D.住宿及餐飲業', value: 'D.住宿及餐飲業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'E.藝術、娛樂及休閒服務業', value: 'E.藝術、娛樂及休閒服務業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'F.金融服務業(含銀行、保險、證券、信託、投信投顧、期貨、電子票證機構、電子支付機構等)', value: 'F.金融服務業(含銀行、保險、證券、信託、投信投顧、期貨、電子票證機構、電子支付機構等)', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'G.資訊業', value: 'G.資訊業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'H.營造建築業、不動產經紀業(含仲介業、代銷業 )', value: 'H.營造建築業、不動產經紀業(含仲介業、代銷業 )', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'I.礦業(石油、天然氣及其相關貿易、運輸業)', value: 'I.礦業(石油、天然氣及其相關貿易、運輸業)', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'J.汔車/船舶/飛機經銷商及其零件製造商', value: 'J.汔車/船舶/飛機經銷商及其零件製造商', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'K.自由業(含學生、家管、退休人士)', value: 'K.自由業(含學生、家管、退休人士)', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'L.主要收入來源以投資為主', value: 'L.主要收入來源以投資為主', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'M.銀樓業(含珠寶、鐘錶及貴金屬之製造、批發、零售)、拍賣行', value: 'M.銀樓業(含珠寶、鐘錶及貴金屬之製造、批發、零售)、拍賣行', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'N.律師、會計師(含律師事務服務業、會計服務業)、地政士、公證人、記帳士暨記帳及報稅代理人', value: 'N.律師、會計師(含律師事務服務業、會計服務業)、地政士、公證人、記帳士暨記帳及報稅代理人', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'O.酒家、舞廳等特種行業', value: 'O.酒家、舞廳等特種行業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'Q.其他', value: 'Q.其他', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'R.虛擬貨幣交易買賣業、地下錢莊、地下匯兌業', value: 'R.虛擬貨幣交易買賣業、地下錢莊、地下匯兌業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'S.宗教組織', value: 'S.宗教組織', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'T.提供類金融服務之非金融機構(含融資性租賃事業、典當業、金融代辦中心、第三方支付機構)', value: 'T.提供類金融服務之非金融機構(含融資性租賃事業、典當業、金融代辦中心、第三方支付機構)', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'U.遊戲場及其特殊娛樂業', value: 'U.遊戲場及其特殊娛樂業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'V.人力仲介業', value: 'V.人力仲介業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'W.國際貿易業', value: 'W.國際貿易業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'X.交通運輸業', value: 'X.交通運輸業', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'Y.軍警、公務員、教職', value: 'Y.軍警、公務員、教職', colName: "OPEN_ONLINE_OPT_DESC" },
							{ label: 'Z.農林漁牧業', value: 'Z.農林漁牧業', colName: "OPEN_ONLINE_OPT_DESC" },
						]
					},
					{ id: "7", type: "CHECKBOX", name: "往來年期", nameEN: "PASTYEARS", nameCH: "往來年期", desc: "客戶最早開戶日，距離今日的天數", options: [
							{ label: '未滿一個月', value: '未滿一個月', colName: "PAST_YEARS_DESC" },
							{ label: '一個月以上，未滿三個月', value: '一個月以上，未滿三個月', colName: "PAST_YEARS_DESC" },
							{ label: '三個月以上，未滿半年', value: '三個月以上，未滿半年', colName: "PAST_YEARS_DESC" },
							{ label: '半年以上，未滿一年', value: '半年以上，未滿一年', colName: "PAST_YEARS_DESC" },
							{ label: '一年以上，未滿三年', value: '一年以上，未滿三年', colName: "PAST_YEARS_DESC" },
							{ label: '三年以上，未滿五年', value: '三年以上，未滿五年', colName: "PAST_YEARS_DESC" },
							{ label: '五年以上，未滿十年', value: '五年以上，未滿十年', colName: "PAST_YEARS_DESC" },
							{ label: '十年以上', value: '十年以上', colName: "PAST_YEARS_DESC" },
						]
					},
					{ id: "8", type: "CHECKBOX", name: "靜止年期", nameEN: "DPRMANT_PERIOD", nameCH: "靜止年期", desc: "客戶最近交易日距今的年期", options: [ 
							{ label: '一年以上靜止，未滿兩年', value: '一年以上靜止，未滿兩年', colName: "DPRMANT_PERIOD_DESC" },
							{ label: '兩年以上靜止，未滿三年', value: '兩年以上靜止，未滿三年', colName: "DPRMANT_PERIOD_DESC" },
							{ label: '三年以上靜止，未滿四年', value: '三年以上靜止，未滿四年', colName: "DPRMANT_PERIOD_DESC" },
							{ label: '四年以上靜止，未滿五年', value: '四年以上靜止，未滿五年', colName: "DPRMANT_PERIOD_DESC" },
							{ label: '五年以上靜止，未滿六年', value: '五年以上靜止，未滿六年', colName: "DPRMANT_PERIOD_DESC" },
							{ label: '六年以上靜止，未滿七年', value: '六年以上靜止，未滿七年', colName: "DPRMANT_PERIOD_DESC" },
							{ label: '七年以上靜止，未滿八年', value: '七年以上靜止，未滿八年', colName: "DPRMANT_PERIOD_DESC" },
							{ label: '八年以上靜止，未滿九年', value: '八年以上靜止，未滿九年', colName: "DPRMANT_PERIOD_DESC" },
							{ label: '九年以上靜止，未滿十年', value: '九年以上靜止，未滿十年', colName: "DPRMANT_PERIOD_DESC" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "有效性", nameEN: "EFF_IND", nameCH: "有效性", desc: "有效性", options: [ 
							{ label: '有庫存，有開電子戶', value: '01 有庫存，有開電子戶', colName: "EC_ACCT_STATUS_DESC" },
							{ label: '有庫存，未開電子戶', value: '02 有庫存，未開電子戶', colName: "EC_ACCT_STATUS_DESC" },
							{ label: '無庫存，有開電子戶', value: '03 無庫存，有開電子戶', colName: "EC_ACCT_STATUS_DESC" },
							{ label: '無庫存，未開電子戶', value: '04 無庫存，未開電子戶', colName: "EC_ACCT_STATUS_DESC" },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "所屬分公司", nameEN: "BRANCH_NAME", nameCH: "所屬分公司", desc: "所屬分公司", options: [ 
							{ label: '嘉義分公司', value: '嘉義分公司', colName: "BRANCH_NAME" },
							{ label: '左營分公司', value: '左營分公司', colName: "BRANCH_NAME" },
							{ label: '員林分公司', value: '員林分公司', colName: "BRANCH_NAME" },
							{ label: '仁愛分公司', value: '仁愛分公司', colName: "BRANCH_NAME" },
							{ label: '台北分公司', value: '台北分公司', colName: "BRANCH_NAME" },
							{ label: '竹北分公司', value: '竹北分公司', colName: "BRANCH_NAME" },
							{ label: '竹東分公司', value: '竹東分公司', colName: "BRANCH_NAME" },
							{ label: '內湖分公司', value: '內湖分公司', colName: "BRANCH_NAME" },
							{ label: '羅東分公司', value: '羅東分公司', colName: "BRANCH_NAME" },
						]
					},
					{ id: "11", type: "CHECKBOX", name: "最近一次交易距今", nameEN: "RECENCY", nameCH: "最近一次交易距今", desc: "客戶最近一次交易日期，距離今日的天數", options: [ 
							{ label: '未滿一個月', value: '未滿一個月', colName: "RECENCY_DESC" },
							{ label: '一個月以上，未滿三個月', value: '一個月以上，未滿三個月', colName: "RECENCY_DESC" },
							{ label: '三個月以上，未滿半年', value: '三個月以上，未滿半年', colName: "RECENCY_DESC" },
							{ label: '半年以上，未滿一年', value: '半年以上，未滿一年', colName: "RECENCY_DESC" },
							{ label: '一年以上，未滿三年', value: '一年以上，未滿三年', colName: "RECENCY_DESC" },
							{ label: '三年以上未交易', value: '三年以上未交易', colName: "RECENCY_DESC" },
						]
					},
				]
			},
			{ id: "2", name: "身份註記", children: [
					{ id: "1", type: "MCHECKBOX", name: "客戶分群", desc: "依客戶貢獻度(3千)及庫存(300萬)分為核心客群及數位客群，核心客群細分如下-->1. 高頻: 特定客戶2. 超高貢獻: 貢獻度>=30萬以上3. 高貢獻: 30萬>貢獻度>=10萬4. 高資產: 資產>=3000萬5. 中貢獻: 10萬>貢獻度>=1萬6. 低貢獻: 1萬>貢獻度>=0.3萬數位細分如下-->C1 : 實動、C2 : 靜止有庫存、C3:靜止無庫存 ", options: [ 
							{ label: '高頻', value: '高頻', name:'客戶分群', colName: 'CALL_SEGMENT_NAME' },
							{ label: '核心', value: '核心', name:'客戶分群', colName: 'CALL_SEGMENT_NAME', options:[
									{ label: '高頻', value: '高頻', name:'子分群', colName: 'CUST_TYPE_CODE' },
									{ label: '高資產', value: '高資產', name:'子分群', colName: 'CUST_TYPE_CODE' },
									{ label: '超高貢獻', value: '超高貢獻', name:'子分群', colName: 'CUST_TYPE_CODE' },
									{ label: '高貢獻', value: '高貢獻', name:'子分群', colName: 'CUST_TYPE_CODE' },
									{ label: ' 中貢獻', value: ' 中貢獻', name:'子分群', colName: 'CUST_TYPE_CODE' },
									{ label: '低貢獻', value: '低貢獻', name:'子分群', colName: 'CUST_TYPE_CODE' },
								]
							},
							{ label: '數客', value: '數客', name:'客戶分群', colName: 'CALL_SEGMENT_NAME', options:[
									{ label: 'C1', value: 'C1', name:'子分群', colName: 'CUST_TYPE_CODE' },
									{ label: 'C2', value: 'C2', name:'子分群', colName: 'CUST_TYPE_CODE' },
									{ label: 'C3', value: 'C3', name:'子分群', colName: 'CUST_TYPE_CODE' },
								]
							},
							{ label: '新戶', value: '新戶', name:'客戶分群', colName: 'CALL_SEGMENT_NAME' },
							{ label: '法人戶', value: '法人戶', name:'客戶分群', colName: 'CALL_SEGMENT_NAME' },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "全客群NESFRRFM", nameEN: "NESFRM", nameCH: "全客群NESFRRFM", desc: "RFM : Recency、Frequency、MonetaryNES : New、Existing、Sleeping", options: [ 
							{ label: '新戶', value: '1.新戶', colName: "RFM_NES_DESC" },
							{ label: 'vip', value: '2.vip', colName: "RFM_NES_DESC" },
							{ label: '半夢半醒貴人', value: '3.半夢半醒貴人', colName: "RFM_NES_DESC" },
							{ label: '忠誠常客', value: '4.忠誠常客', colName: "RFM_NES_DESC" },
							{ label: '好久不見稀客', value: '5.好久不見稀客', colName: "RFM_NES_DESC" },
							{ label: '不愛台股愛其他', value: '6.不愛台股愛其他', colName: "RFM_NES_DESC" },
							{ label: '琵琶抱別的舊戶', value: '7.琵琶抱別的舊戶', colName: "RFM_NES_DESC" },
							{ label: '靜止有庫存', value: '8.靜止有庫存', colName: "RFM_NES_DESC" },
							{ label: '靜止無庫存', value: '9.靜止無庫存', colName: "RFM_NES_DESC" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "抽籤註記", nameEN: "DRAWING_IND", nameCH: "抽籤註記", desc: "指今年有抽籤", options: [ 
							{ label: 'Y', value: 'Y', colName: "DW_FLAG" },
							{ label: 'N', value: 'N', colName: "DW_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "限售客戶註記", nameEN: "NOSELL_IND", nameCH: "限售客戶註記", desc: "限制銷售的客戶", options: [ 
							{ label: 'Y', value: 'Y', colName: "NOT_SELLING_FLAG" },
							{ label: 'N', value: 'N', colName: "NOT_SELLING_FLAG" },
						]
					},
					{ id: "5", type: "CHECKBOX", name: "同意共銷戶註記", nameEN: "CROSSSELLING", nameCH: "同意共銷戶註記", desc: "同意接受共同行銷商品的客戶", options: [
							{ label: 'Y', value: 'Y', colName: "CROSS_SELLING_FLAG" },
							{ label: 'N', value: 'N', colName: "CROSS_SELLING_FLAG" },
						]
					},
				]
			},
			{ id: "3", name: "開戶及簽署", children: [
					{ id: "1", type: "CHECKBOX", name: "開戶方式", nameEN: "OPEN_CHANNEL_CODE", nameCH: "開戶方式", desc: "客戶透過線上或臨櫃開立證券帳戶", options: [ 
							{ label: '線上', value: '線上', colName: "OPEN_CHANNEL_DESC" },
							{ label: '臨櫃', value: '臨櫃', colName: "OPEN_CHANNEL_DESC" },
						]
					},
					{ id: "2", type: "MCHECKBOX", name: "線上開戶進件來源", nameEN: "OPEN_SOURCE ", nameCH: "線上開戶進件來源", desc: "", options: [ 
							{ label: '線上進件', value: '線上進件', name:'線上進件', colName: 'OPEN_ONLINE_FLAG', options:[
									{ label: '關鍵字廣告及直接來源', value: '關鍵字廣告及直接來源', colName: 'OPEN_OL_SOURCE_DESC' },
									{ label: 'MGM推薦連結', value: 'MGM推薦連結', colName: 'OPEN_OL_SOURCE_DESC' },
									{ label: '下單平台', value: '下單平台', colName: 'OPEN_OL_SOURCE_DESC' },
									{ label: '官網', value: '官網', colName: 'OPEN_OL_SOURCE_DESC' },
									{ label: '跨BU', value: '跨BU', colName: 'OPEN_OL_SOURCE_DESC' },
									{ label: '富邦LINE', value: '富邦LINE', colName: 'OPEN_OL_SOURCE_DESC' },
								]
							},
						]
					},
					{ id: "3", type: "CHECKBOX", name: "開戶客戶來源", nameEN: "CUST_SOURCE_CODE ", nameCH: "開戶客戶來源", desc: "分潤之進件來源", options: [ 
							{ label: '自來戶', value: '自來戶', colName: "CUST_SOURCE_DESC" },
							{ label: '自開戶', value: '自開戶', colName: "CUST_SOURCE_DESC" },
							{ label: '關係企業', value: '關係企業', colName: "CUST_SOURCE_DESC" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當年新開戶", nameEN: "NEWOPEN ", nameCH: "當年新開戶", desc: "", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_ACCT_NEWOPEN_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_ACCT_NEWOPEN_FLAG" },
						]
					},
					{ id: "5", type: "CHECKBOX", name: "分戶帳註記", nameEN: "SBCD_IND ", nameCH: "分戶帳註記", desc: "泛指用非富邦證券配合之交割銀行，作為證券戶之交割銀行的方式開戶", options: [ 
							{ label: 'Y', value: 'Y', colName: "CL_SIGN_FLAG" },
							{ label: 'N', value: 'N', colName: "CL_SIGN_FLAG" },
						]
					},
					{ id: "6", type: "CHECKBOX", name: "電子戶註記", nameEN: "EC_IND ", nameCH: "電子戶註記", desc: "指開戶時同意以電子方式進行交易", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_ACCT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_ACCT_FLAG" },
						]
					},
					{ id: "7", type: "CHECKBOX", name: "信用戶註記", nameEN: "CREDIT_IND ", nameCH: "信用戶註記", desc: "信用戶需符合交易滿三個月，且近一年成交筆數10筆以上", options: [ 
							{ label: 'Y', value: 'Y', colName: "CD_ACCT_FLAG" },
							{ label: 'N', value: 'N', colName: "CD_ACCT_FLAG" },
						]
					},
					{ id: "8", type: "CHECKBOX", name: "潛在信用戶", nameEN: "POTENTIAL_CREDIT_IND ", nameCH: "符合信用資格之非信用戶", desc: "同上，但尚未加開信用戶", options: [ 
							{ label: 'Y', value: 'Y', colName: "POTENTIAL_C_FLAG" },
							{ label: 'N', value: 'N', colName: "POTENTIAL_C_FLAG" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "當沖戶註記", nameEN: "", nameCH: "當沖戶註記", desc: "當沖客戶", options: [ 
							{ label: '近一個月有當沖', value: 'Y', name:'近一個月有當沖', colName: 'L1_DT_TXN_FLAG' },
							{ label: '近三個月有當沖', value: 'Y', name:'近三個月有當沖', colName: 'L3_DT_TXN_FLAG' },
							{ label: '當年有當沖', value: 'Y', name:'當年當沖', colName: 'YM_DT_TXN_FLAG' },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "期貨IB註記", nameEN: "IB_IND", nameCH: "期貨IB註記", desc: "指期貨 IB 的客戶", options: [ 
							{ label: 'Y', value: 'Y', colName: "FUT_IB_ACC_FLAG" },
							{ label: 'N', value: 'N', colName: "FUT_IB_ACC_FLAG" },
						]
					},
					{ id: "11", type: "CHECKBOX", name: "複委託註記", nameEN: "ACCTF_IND", nameCH: "複委託註記", desc: "指有開複委託帳戶的客戶", options: [ 
							{ label: 'Y', value: 'Y', colName: "SBK_ACCT_FLAG" },
							{ label: 'N', value: 'N', colName: "SBK_ACCT_FLAG" },
						]
					},
					{ id: "12", type: "CHECKBOX", name: "現股當沖簽署", nameEN: "DAYTRADE_SIGN", nameCH: "現股當沖簽署", desc: "交易現股當沖前，需簽署契約", options: [ 
							{ label: 'Y', value: 'Y', colName: "DT_SIGN_FLAG" },
							{ label: 'N', value: 'N', colName: "DT_SIGN_FLAG" },
						]
					},
					{ id: "13", type: "CHECKBOX", name: "出借簽署", nameEN: "D8CD_SIGN", nameCH: "出借簽署", desc: "股票出借前，需簽署契約", options: [ 
							{ label: 'Y', value: 'Y', colName: "BSBL_SIGN_FLAG" },
							{ label: 'N', value: 'N', colName: "BSBL_SIGN_FLAG" },
						]
					},
					{ id: "14", type: "CHECKBOX", name: "不限用途簽署", nameEN: "C7CD_SIGN", nameCH: "不限用途簽署", desc: "股票借貸前，需簽署契約", options: [ 
							{ label: 'Y', value: 'Y', colName: "URUL_SIGN_FLAG" },
							{ label: 'N', value: 'N', colName: "URUL_SIGN_FLAG" },
						]
					},
					{ id: "15", type: "CHECKBOX", name: "定期定額簽署", nameEN: "DCACCT_SIGN", nameCH: "定期定額簽署", desc: "定期定額前，需簽署契約", options: [ 
							{ label: 'Y', value: 'Y', colName: "DC_SIGN_FLAG" },
							{ label: 'N', value: 'N', colName: "DC_SIGN_FLAG" },
						]	
					},
				]
			},
			{ id: "4", name: "風險偏好", children: [
					{ id: "1", type: "CHECKBOX", name: "洗防風險等級", nameEN: "AML_RISK_LEVEL", nameCH: "洗防風險等級", desc: "洗防風險等級，分高、中、低風險", options: [ 
							{ label: '高', value: 'H', colName: "AML_RISK_CODE" },
							{ label: '中', value: 'L', colName: "AML_RISK_CODE" },
							{ label: '低', value: 'M', colName: "AML_RISK_CODE" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "KYC", nameEN: "KYC", nameCH: "KYC", desc: "", options: [ 
							{ label: 'C1', value: 'C1', colName: "KYC_RISK_CODE" },
							{ label: 'C2', value: 'C2', colName: "KYC_RISK_CODE" },
							{ label: 'C3', value: 'C3', colName: "KYC_RISK_CODE" },
							{ label: 'C4', value: 'C4', colName: "KYC_RISK_CODE" },
							{ label: 'C5', value: 'C5', colName: "KYC_RISK_CODE" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當日買賣額度", nameEN: "DAILYLIMIT_LEVEL", nameCH: "當日買賣額度", desc: "指現貨交易當日買進+賣出的金額限制", options: [ 
							{ label: '未滿50萬', value: '未滿50萬', colName: "DAILY_LM_AMT_DESC" },
							{ label: '50萬以上，未滿100萬', value: '50萬以上，未滿100萬', colName: "DAILY_LM_AMT_DESC" },
							{ label: '100萬以上，未滿300萬', value: '100萬以上，未滿300萬', colName: "DAILY_LM_AMT_DESC" },
							{ label: '300萬以上，未滿1千萬', value: '300萬以上，未滿1千萬', colName: "DAILY_LM_AMT_DESC" },
							{ label: '1千萬以上，未滿5千萬', value: '1千萬以上，未滿5千萬', colName: "DAILY_LM_AMT_DESC" },
							{ label: '5千萬以上，未滿1億', value: '5千萬以上，未滿1億', colName: "DAILY_LM_AMT_DESC" },
							{ label: '1億以上', value: '1億以上', colName: "DAILY_LM_AMT_DESC" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "信用額度", nameEN: "CRAMT_LEVEL", nameCH: "信用額度", desc: "指進行信用交易時，可向券商借錢的金額限制", options: [ 
							{ label: '無信用額度', value: '無信用額度', colName: "CD_DAILY_LM_AMT_DESC" },
							{ label: '未滿50萬', value: '未滿50萬', colName: "CD_DAILY_LM_AMT_DESC" },
							{ label: '50萬以上&未滿300萬', value: '50萬以上&未滿300萬', colName: "CD_DAILY_LM_AMT_DESC" },
							{ label: '300萬以上&未滿1000萬', value: '300萬以上&未滿1000萬', colName: "CD_DAILY_LM_AMT_DESC" },
							{ label: '1千萬以上&未滿5千萬', value: '1千萬以上&未滿5千萬', colName: "CD_DAILY_LM_AMT_DESC" },
							{ label: '5千萬以上&未滿1億', value: '5千萬以上&未滿1億', colName: "CD_DAILY_LM_AMT_DESC" },
						]
					},
					{ id: "5", type: "RANGE", name: "融資利率", nameEN: "CRRATE", nameCH: "融資利率", desc: "", options: [ 
							{ label: '可輸入0~1', value: '可輸入0~1', colName: "MARGIN_LOAN_RATE" },
						]
					},
					{ id: "6", type: "RANGE", name: "融資均額", nameEN: "MARGIN_LOAN_AVG", nameCH: "融資均額", desc: "", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "AVG_MARGIN_LOAN_AMT" },
						]
					},
				]
			},
		]
	},
	{ id: "2", name: "接觸通路", icon: 'fa-hand-pointer', children: [
			{ id: "1", name: "平台實動", children: [
					{ id: "1", type: "CHECKBOX", name: "登入e點通", nameEN: "EPOINT", nameCH: "登入e點通", desc: "當年是否有登入， Y:有登入 N:未登入", options: [ 
							{ label: 'Y:有登入', value: 'Y', colName: "EPOINT_LOGIN_FLAG" },
							{ label: 'N:未登入', value: 'N', colName: "EPOINT_LOGIN_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "登入e+PC", nameEN: "E01PC", nameCH: "登入e+PC", desc: "當年是否有登入， Y:有登入 N:未登入", options: [ 
							{ label: 'Y:有登入', value: 'Y', colName: "EPLUS_PC_LOGIN_FLAG" },
							{ label: 'N:未登入', value: 'N', colName: "EPLUS_PC_LOGIN_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "登入e+手機", nameEN: "E01MOBILE", nameCH: "登入e+手機", desc: "當年是否有登入， Y:有登入 N:未登入", options: [ 
							{ label: 'Y:有登入', value: 'Y', colName: "EPLUS_M_LOGIN_FLAG" },
							{ label: 'N:未登入', value: 'N', colName: "EPLUS_M_LOGIN_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "登入e01", nameEN: "E01", nameCH: "登入e01", desc: "當年是否有登入， Y:有登入 N:未登入", options: [ 
							{ label: 'Y:有登入', value: 'Y', colName: "E01_LOGIN_FLAG" },
							{ label: 'N:未登入', value: 'N', colName: "E01_LOGIN_FLAG" },
						]
					},
				]
			},
			{ id: "2", name: "可接觸通路", children: [
					{ id: "1", type: "CHECKBOX", name: "手機", nameEN: "MOBILE_IND", nameCH: "手機", desc: "是否可透過手機接觸", options: [ 
							{ label: 'Y:可', value: 'Y', colName: "MOBILE_FLAG" },
							{ label: 'N:不可', value: 'N', colName: "MOBILE_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "EMAIL", nameEN: "EMAIL_IND", nameCH: "EMAIL", desc: "是否可透過EMAIL接觸", options: [ 
							{ label: 'Y:可', value: 'Y', colName: "EMAIL_FLAG" },
							{ label: 'N:不可', value: 'N', colName: "EMAIL_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "綁定LINE", nameEN: "LINE_IND", nameCH: "綁定LINE", desc: "是否可透過LINE BC接觸", options: [ 
							{ label: 'Y:可', value: 'Y', colName: "LINE_BC_FLAG" },
							{ label: 'N:不可', value: 'N', colName: "LINE_BC_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "綁定M+VIP", nameEN: "MPLUS_IND", nameCH: "綁定M+VIP", desc: "是否可透過M+接觸", options: [ 
							{ label: 'Y:可', value: 'Y', colName: "MPLUS_FLAG" },
							{ label: 'N:不可', value: 'N', colName: "MPLUS_FLAG" },
						]
					},
				]
			},
		]
	},
	{ id: "3", name: "產品交易", icon: 'fa-handshake', children: [
			{ id: "1", name: "損益", children: [
					{ id: "1", type: "CHECKBOX", name: "台股已領股息", nameEN: "DTINT_LEVEL", nameCH: "台股已領股息", desc: "", options: [ 
							{ label: '未滿1萬', value: '未滿1萬', colName: "ACTU_DVD_AMT_DESC" },
							{ label: '1萬~5萬', value: '1萬~5萬', colName: "ACTU_DVD_AMT_DESC" },
							{ label: '5萬~10萬', value: '5萬~10萬', colName: "ACTU_DVD_AMT_DESC" },
							{ label: '10萬~30萬', value: '10萬~30萬', colName: "ACTU_DVD_AMT_DESC" },
							{ label: '30萬~50萬', value: '30萬~50萬', colName: "ACTU_DVD_AMT_DESC" },
							{ label: '50萬~100萬', value: '50萬~100萬', colName: "ACTU_DVD_AMT_DESC" },
							{ label: '100萬~300萬', value: '100萬~300萬', colName: "ACTU_DVD_AMT_DESC" },
							{ label: '300萬以上', value: '300萬以上', colName: "ACTU_DVD_AMT_DESC" },
						]
					},
					{ id: "2", type: "RANGE", name: "台股未實現損益", nameEN: "UNBENEFIT", nameCH: "台股已領股息", desc: "指今年尚未實現之台股庫存損益", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "BENEFIT_AMT" },
						]
					},
					{ id: "3", type: "RANGE", name: "台股已實現損益", nameEN: "BENEFIT", nameCH: "台股已實現損益", desc: "指今年已實現之台股庫存損益", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "ACTU_BENEFIT_AMT" },
						]
					},
				]
			},
			{ id: "2", name: "全產品", children: [
					{ id: "1", type: "CHECKBOX", name: "當年實動戶", nameEN: "ACTIVE_IND", nameCH: "當年實動戶", desc: "當年任一產品實動，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "當年電子實動戶", nameEN: "ECACTIVE_IND", nameCH: "當年電子實動戶", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月實動戶", nameEN: "ACTIVE_IND_M", nameCH: "當月實動戶", desc: "當月任一產品實動，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "AT_FLAG" },
							{ label: 'N', value: 'N', colName: "AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "電子實動戶", nameEN: "ECACTIVE_IND_M", nameCH: "電子實動戶", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "總庫存", nameEN: "AUM", nameCH: "總庫存", desc: "月底總庫存，包含台股、融資融券、定期定額、海外股票、借券、不限用途、基金、海外債、結構商品", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "TOTAL_AMT_TWD" },
						]
					},
					{ id: "6", type: "RANGE", name: "總貢獻", nameEN: "FEE", nameCH: "總貢獻", desc: "今年總貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "TOTAL_SF_AMT_TWD" },
						]
					},
				]	
			},
			{ id: "3", name: "定期定額", children: [
					{ id: "1", type: "CHECKBOX", name: "定期定額註記", nameEN: "DCACCT_IND", nameCH: "定期定額註記", desc: "指今年交易任一類定期定額(包含台股、ETF、複委託基金及信託基金)", options: [ 
							{ label: '定期定額台股', value: '定期定額台股', name:'定期定額註記', colName: 'DC_STOCK_TXN_FLAG' },
							{ label: '定期定額ETF', value: '定期定額ETF', name:'定期定額註記', colName: 'DC_ETF_TXN_FLAG' },
							{ label: '定期定額複委託基金', value: '定期定額複委託基金', name:'定期定額註記', colName: 'SBK_MF_DC_TXN_FLAG' },
							{ label: '定期定額信託金', value: '定期定額信託金', name:'定期定額註記', colName: 'WT_MF_DC_TXN_FLAG' },
						]
					},
					{ id: "2", type: "RANGE", name: "台股定期定額月扣天數", nameEN: "DCACCT_DAY", nameCH: "台股定期定額月扣天數", desc: "台股定期定額及ETF當月扣款天數", options: [ 
							{ label: '最多為3', value: '最多為3', colName: "M_DC_TXN_DAY" },
						]
					},
					{ id: "3", type: "RANGE", name: "台股定期定額月扣筆數", nameEN: "DCACCT_CNT", nameCH: "台股定期定額月扣筆數", desc: "台股定期定額及ETF平均每月扣款筆數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "M_DC_TXN_CNT" },
						]
					},
					{ id: "4", type: "RANGE", name: "台股定期定額當月實扣金額", nameEN: "DCACCT_AMT", nameCH: "台股定期定額當月實扣金額", desc: "台股定期定額及ETF平均每月扣款金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "DC_TXN_AMT" },
						]
					},
					{ id: "5", type: "RANGE", name: "台股定期定額年累實扣金額", nameEN: "DCACCT_AMT_Y", nameCH: "台股定期定額年累實扣金額", desc: "台股定期定額及ETF年累扣款金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_DC_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "台股定期定額手續費", nameEN: "DCACCT_FEE", nameCH: "台股定期定額手續費", desc: "台股定期定額及ETF年累手續費", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_DC_TXN_FEE" },
						]
					},
					{ id: "7", type: "RANGE", name: "信託基金月扣天數", nameEN: "MF_DAY", nameCH: "信託基金月扣天數", desc: "信託基金當月扣款天數", options: [ 
							{ label: '最多為3', value: '最多為3', colName: "WT_MF_TXN_DAY" },
						]
					},
					{ id: "8", type: "RANGE", name: "信託基金月扣筆數", nameEN: "MF_CNT", nameCH: "信託基金月扣筆數", desc: "信託基金平均每月扣款筆數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "WT_MF_TXN_CNT" },
						]
					},
					{ id: "9", type: "RANGE", name: "信託基金當月實扣金額", nameEN: "MF_AMT", nameCH: "信託基金當月實扣金額", desc: "信託基金平均每月扣款金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "WT_MF_TXN_AMT" },
						]
					},
					{ id: "10", type: "RANGE", name: "信託基金年累實扣金額", nameEN: "MFT_AMT_Y", nameCH: "信託基金年累實扣金額", desc: "信託基金年累扣款金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_WT_MF_TXN_AMT" },
						]
					},
					{ id: "11", type: "RANGE", name: "信託基金手續費", nameEN: "MF_FEE", nameCH: "信託基金手續費", desc: "信託基金年累手續費", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_WT_MF_TXN_FEE" },
						]
					},
					{ id: "12", type: "RANGE", name: "複委託基金月扣天數", nameEN: "ACCTF_DAY", nameCH: "複委託基金月扣天數", desc: "複委託基金當月扣款天數", options: [ 
							{ label: '最多為3', value: '最多為3', colName: "SBK_MF_TXN_DAY" },
						]
					},
					{ id: "13", type: "RANGE", name: "複委託基金月扣筆數", nameEN: "ACCTF_CNT", nameCH: "複委託基金月扣筆數", desc: "複委託基金平均每月扣款筆數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "SBK_MF_TXN_CNT" },
						]
					},
					{ id: "14", type: "RANGE", name: "複委託基金當月實扣金額", nameEN: "ACCTF_AMT", nameCH: "複委託基金當月實扣金額", desc: "複委託基金平均每月扣款金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "SBK_MF_TXN_AMT" },
						]
					},
					{ id: "15", type: "RANGE", name: "複委託基金年累實扣金額", nameEN: "ACCTF_AMT_Y", nameCH: "複委託基金年累實扣金額", desc: "複委託基金年累扣款金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_SBK_MF_TXN_AMT" },
						]
					},
					{ id: "16", type: "RANGE", name: "複委託基金手續費", nameEN: "ACCTF_FEE", nameCH: "複委託基金手續費", desc: "複委託基金年累手續費", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_SBK_MF_TXN_FEE" },
						]
					},
				]
			},
			{ id: "4", name: "產品_台股", children: [
					{ id: "1", type: "CHECKBOX", name: "台股實動", nameEN: "ACTIVE_SK", nameCH: "台股實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_TS_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_TS_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "台股電子實動", nameEN: "ECACTIVE_SK", nameCH: "台股電子實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_TS_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_TS_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月台股實動", nameEN: "ACTIVE_SK_M", nameCH: "當月台股實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "TS_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "TS_AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當月台股電子實動", nameEN: "ECACTIVE_SK_M", nameCH: "當月台股電子實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_TS_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_TS_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "台股年累交易量", nameEN: "TXAMT_SK", nameCH: "台股年累交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_TS_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "台股年累電子交易量", nameEN: "TXAMT_SK", nameCH: "台股年累電子交易量", desc: "當年產品電子交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_YM_TS_TXN_AMT" },
						]
					},
					{ id: "7", type: "RANGE", name: "台股當月交易量", nameEN: "TXAMT_SK_M", nameCH: "台股當月交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "TS_TXN_AMT" },
						]
					},
					{ id: "8", type: "RANGE", name: "台股當月電子交易量", nameEN: "TXAMT_SK_M", nameCH: "台股當月交易量", desc: "當月產品電子交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_TS_TXN_AMT" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "台股當月交易量級距", nameEN: "TXLEVEL_SK", nameCH: "台股當月交易量級距", desc: "台股交易金額級距", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "TS_TXN_AMT_DESC" },
							{ label: '01 50萬以下', value: '01 50萬以下', colName: "TS_TXN_AMT_DESC" },
							{ label: '02 50萬(含)~3000萬', value: '02 50萬(含)~3000萬', colName: "TS_TXN_AMT_DESC" },
							{ label: '03 3000萬(含)~1.5億', value: '03 3000萬(含)~1.5億', colName: "TS_TXN_AMT_DESC" },
							{ label: '04 1.5億以上', value: '04 1.5億以上', colName: "TS_TXN_AMT_DESC" },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "台股當月電子交易量級距", nameEN: "ECTXLEVEL_SK", nameCH: "台股當月電子交易量級距", desc: "台股電子交易金額級距", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "EC_TS_TXN_AMT_DESC" },
							{ label: '01 50萬以下', value: '01 50萬以下', colName: "EC_TS_TXN_AMT_DESC" },
							{ label: '02 50萬(含)~3000萬', value: '02 50萬(含)~3000萬', colName: "EC_TS_TXN_AMT_DESC" },
							{ label: '03 3000萬(含)~1.5億', value: '03 3000萬(含)~1.5億', colName: "EC_TS_TXN_AMT_DESC" },
							{ label: '04 1.5億以上', value: '04 1.5億以上', colName: "EC_TS_TXN_AMT_DESC" },
						]
					},
					{ id: "11", type: "RANGE", name: "台股庫存資產", nameEN: "AUM_SK", nameCH: "台股庫存資產", desc: "月底台股庫存資產", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "TS_AMT_TWD" },
						]
					},
					{ id: "12", type: "RANGE", name: "台股淨貢獻", nameEN: "FEE_SK", nameCH: "台股淨貢獻", desc: "今年台股淨貢獻包含融資券、定期定額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "TS_SF_AMT_TWD" },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "期權當月電子交易口數級距", nameEN: "EC_FUT_TXN_QTY_DESC", nameCH: "期權電子交易級距", desc: "", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "EC_FUT_TXN_QTY_DESC" },
							{ label: '01 0~50口', value: '01 0~50口', colName: "EC_FUT_TXN_QTY_DESC" },
							{ label: '02 51~200口', value: '02 51~200口', colName: "EC_FUT_TXN_QTY_DESC" },
							{ label: '03 201~1000口', value: '03 201~1000口', colName: "EC_FUT_TXN_QTY_DESC" },
							{ label: '04 1000口以上', value: '04 1000口以上', colName: "EC_FUT_TXN_QTY_DESC" },
						]
					},
				]
			},
			{ id: "5", name: "產品_信用", children: [
					{ id: "1", type: "CHECKBOX", name: "信用實動", nameEN: "ACTIVE_CREDIT", nameCH: "信用實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_CD_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_CD_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "信用電子實動", nameEN: "ECACTIVE_CREDIT", nameCH: "信用電子實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_CD_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_CD_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月信用實動", nameEN: "ACTIVE_CREDIT_M", nameCH: "當月信用實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "CD_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "CD_AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當月信用電子實動", nameEN: "ECACTIVE_CREDIT_M", nameCH: "當月信用電子實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_CD_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_CD_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "信用年累交易量", nameEN: "TXAMT_CREDIT", nameCH: "信用年累交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_CD_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "信用年累電子交易量", nameEN: "TXAMT_CREDIT", nameCH: "信用年累電子交易量", desc: "當年產品電子交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_YM_CD_TXN_AMT" },
						]
					},
					{ id: "7", type: "RANGE", name: "信用當月交易量", nameEN: "TXAMT_CREDIT_M", nameCH: "信用當月交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "CD_TXN_AMT" },
						]
					},
					{ id: "8", type: "RANGE", name: "信用當月電子交易量", nameEN: "TXAMT_CREDIT_M", nameCH: "信用當月電子交易量", desc: "當月產品電子交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_CD_TXN_AMT" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "融資均額級距", nameEN: "TXLEVEL_CREDIT", nameCH: "融資均額級距", desc: "融資均額級距", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "CD_TXN_AMT_DESC" },
							{ label: '01 5000萬(含)以上', value: '01 5000萬(含)以上', colName: "CD_TXN_AMT_DESC" },
							{ label: '02 1000萬(含)-5000萬', value: '02 1000萬(含)-5000萬', colName: "CD_TXN_AMT_DESC" },
							{ label: '03 300萬(含)-1000萬', value: '03 300萬(含)-1000萬', colName: "CD_TXN_AMT_DESC" },
							{ label: '04 300萬以下', value: '04 300萬以下', colName: "CD_TXN_AMT_DESC" },
						]
					},
					{ id: "10", type: "RANGE", name: "信用庫存資產", nameEN: "AUM_CREDIT", nameCH: "信用庫存資產", desc: "月底信用庫存資產", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "CD_AMT_TWD" },
						]
					},
					{ id: "11", type: "RANGE", name: "信用貢獻", nameEN: "FEE_CREDIT", nameCH: "信用貢獻", desc: "今年信用貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "CD_SF_AMT_TWD" },
						]
					},
				]
			},
			{ id: "6", name: "產品_不限用途", children: [
					{ id: "1", type: "CHECKBOX", name: "不限用途實動", nameEN: "ACTIVE_C7CD", nameCH: "不限用途實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_URUL_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_URUL_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "不限用途電子實動", nameEN: "ECACTIVE_C7CD", nameCH: "不限用途電子實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_URUL_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_URUL_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月不限用途實動", nameEN: "ACTIVE_C7CD_M", nameCH: "當月不限用途實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "URUL_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "URUL_AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當月不限用途實電子實動", nameEN: "ECACTIVE_C7CD_M", nameCH: "當月不限用途實電子實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_URUL_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_URUL_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "不限用途實年累累交易量", nameEN: "TXAMT_C7CD", nameCH: "不限用途實年累累交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_URUL_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "不限用途實年累電子交易量", nameEN: "TXAMT_C7CD", nameCH: "不限用途實年累電子交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_YM_URUL_TXN_AMT" },
						]
					},
					{ id: "7", type: "RANGE", name: "不限用途當月交易量", nameEN: "TXAMT_C7CD_M", nameCH: "不限用途當月交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "URUL_TXN_AMT" },
						]
					},
					{ id: "8", type: "RANGE", name: "不限用途實當月電子交易量", nameEN: "TXAMT_C7CD_M", nameCH: "不限用途實當月電子交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_URUL_TXN_AMT" },
						]
					},
					{ id: "9", type: "RANGE", name: "不限用途庫存資產", nameEN: "AUM_C7CD", nameCH: "不限用途庫存資產", desc: "月底不限用途庫存資產", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "URUL_AMT_TWD" },
						]
					},
					{ id: "10", type: "RANGE", name: "不限用途貢獻", nameEN: "FEE_C7CD", nameCH: "不限用途貢獻", desc: "今年不限用途貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "URUL_SF_AMT_TWD" },
						]
					},
				]
			},
			{ id: "7", name: "產品_通入借入", children: [
					{ id: "1", type: "CHECKBOX", name: "通入借入實動", nameEN: "ACTIVE_D8CD", nameCH: "通入借入實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_BSBL_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_BSBL_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "通路借入電子實動", nameEN: "ECACTIVE_D8CD", nameCH: "通路借入電子實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_BSBL_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_BSBL_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月通路借入實動", nameEN: "ACTIVE_D8CD_M", nameCH: "當月通路借入實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "BSBL_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "BSBL_AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當月通路借入電子實動", nameEN: "ECACTIVE_D8CD_M", nameCH: "當月通路借入實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_BSBL_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_BSBL_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "通路借入年累交易量", nameEN: "TXAMT_D8CD", nameCH: "通路借入年累交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_BSBL_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "通路借入年累電子交易量", nameEN: "TXAMT_D8CD", nameCH: "通路借入年累電子交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_YM_BSBL_TXN_AMT" },
						]
					},
					{ id: "7", type: "RANGE", name: "通路借入當月交易量", nameEN: "TXAMT_D8CD_M", nameCH: "通路借入當月交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "BSBL_TXN_AMT" },
						]
					},
					{ id: "8", type: "RANGE", name: "通路借入當月電子交易量", nameEN: "TXAMT_D8CD_M", nameCH: "通路借入當月電子交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_BSBL_TXN_AMT" },
						]
					},
					{ id: "9", type: "RANGE", name: "通路借入庫存資產", nameEN: "AUM_D8CD", nameCH: "通路借入庫存資產", desc: "月底通路借入庫存資產", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "BSBL_AMT_TWD" },
						]
					},
					{ id: "10", type: "RANGE", name: "通入借入貢獻", nameEN: "FEE_D8CD", nameCH: "通入借入貢獻", desc: "今年通入借入貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "BSBL_SF_AMT_TWD" },
						]
					},
				]
			},
			{ id: "8", name: "產品_期權", children: [
					{ id: "1", type: "CHECKBOX", name: "期權實動", nameEN: "ACTIVE_FU", nameCH: "期權實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_FUT_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_FUT_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "期權電子實動", nameEN: "ECACTIVE_FU", nameCH: "期權電子實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_FUT_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_FUT_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月期權實動", nameEN: "ACTIVE_FU_M", nameCH: "當月期權實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "FUT_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "FUT_AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當月期權電子實動", nameEN: "ECACTIVE_FU_M", nameCH: "當月期權電子實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_FUT_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_FUT_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "當月期權電子實動", nameEN: "TXAMT_FU", nameCH: "當月期權電子實動", desc: "當年產品全部交易口數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_FUT_TXN_UNIT_QTY" },
						]
					},
					{ id: "6", type: "RANGE", name: "期權年累電子交易口數", nameEN: "TXAMT_FU", nameCH: "期權年累電子交易口數", desc: "當年產品電子交易口數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_YM_FUT_TXN_AMT" },
						]
					},
					{ id: "7", type: "RANGE", name: "期權當月交易口數", nameEN: "TXAMT_FU_M", nameCH: "期權當月交易口數", desc: "當月產品全部交易口數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "FUT_TXN_UNIT_QTY" },
						]
					},
					{ id: "8", type: "RANGE", name: "期權當月電子交易量", nameEN: "TXAMT_FU_M", nameCH: "期權當月電子交易量", desc: "當月產品全部交易口數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_FUT_TXN_AMT" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "期權當月交易口數級距", nameEN: "TXLEVEL_FU", nameCH: "期權當月交易口數級距", desc: "期權交易口數級距", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "FUT_TXN_QTY_DESC" },
							{ label: '01 0~50口', value: '01 0~50口', colName: "FUT_TXN_QTY_DESC" },
							{ label: '02 51~200口', value: '02 51~200口', colName: "FUT_TXN_QTY_DESC" },
							{ label: '03 201~1000口', value: '03 201~1000口', colName: "FUT_TXN_QTY_DESC" },
							{ label: '04 1000口以上', value: '04 1000口以上', colName: "FUT_TXN_QTY_DESC" },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "期權當月電子交易口數級距", nameEN: "ECTXLEVEL_FU", nameCH: "期權當月電子交易口數級距", desc: "期貨電子交易口數級距", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "EC_FUT_AT_FLAG" },
							{ label: '01 50萬以下', value: '01 50萬以下', colName: "EC_FUT_AT_FLAG" },
							{ label: '02 50萬(含)~3000萬', value: '02 50萬(含)~3000萬', colName: "EC_FUT_AT_FLAG" },
						]
					},
					{ id: "11", type: "RANGE", name: "期貨貢獻", nameEN: "FEE_FU", nameCH: "期貨貢獻", desc: "今年期貨貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "FUT_SF_AMT_TWD" },
						]
					},
				]
			},
			{ id: "9", name: "產品_海外股", children: [
					{ id: "1", type: "CHECKBOX", name: "海外股實動", nameEN: "ACTIVE_FOREIGNSK", nameCH: "海外股實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_FS_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_FS_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "海外股票電子實動", nameEN: "ECACTIVE_FOREIGNSK", nameCH: "海外股票電子實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_FS_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_FS_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月海外股實動", nameEN: "ACTIVE_FOREIGNSK_M", nameCH: "當月海外股實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "FS_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "FS_AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當月海外股電子實動", nameEN: "ECACTIVE_FOREIGNSK_M", nameCH: "當月海外股電子實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_FS_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_FS_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "海外股年累交易量", nameEN: "TXAMT_FOREIGNSK", nameCH: "海外股年累交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_FS_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "海外股年累電子交易量", nameEN: "TXAMT_FOREIGNSK", nameCH: "海外股年累電子交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_YM_FS_TXN_AMT" },
						]
					},
					{ id: "7", type: "RANGE", name: "海外股當月交易量", nameEN: "TXAMT_FOREIGNSK_M", nameCH: "海外股當月交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "FS_TXN_AMT" },
						]
					},
					{ id: "8", type: "RANGE", name: "海外股當月電子交易量", nameEN: "TXAMT_FOREIGNSK_M", nameCH: "海外股當月電子交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_FS_TXN_AMT" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "海外股當月交易量級距", nameEN: "TXLEVEL_FOREIGNSK", nameCH: "海外股當月交易量級距", desc: "海外股交易金額級距", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "FS_TXN_AMT_DESC" },
							{ label: '01 30萬(含)以下', value: '01 30萬(含)以下', colName: "FS_TXN_AMT_DESC" },
							{ label: '02 30萬~300萬(含)', value: '02 30萬~300萬(含)', colName: "FS_TXN_AMT_DESC" },
							{ label: '03 300萬~3000萬(含)', value: '03 300萬~3000萬(含)', colName: "FS_TXN_AMT_DESC" },
							{ label: '04 3000萬以上', value: '04 3000萬以上', colName: "FS_TXN_AMT_DESC" },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "海外股當月電子交易量級距", nameEN: "ECTXLEVEL_FOREIGNSK", nameCH: "海外股當月電子交易量級距", desc: "海外股電子交易金額級距", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "EC_FS_TXN_AMT_DESC" },
							{ label: '01 30萬(含)以下', value: '01 30萬(含)以下', colName: "EC_FS_TXN_AMT_DESC" },
							{ label: '02 30萬~300萬(含)', value: '02 30萬~300萬(含)', colName: "EC_FS_TXN_AMT_DESC" },
							{ label: '03 300萬~3000萬(含)', value: '03 300萬~3000萬(含)', colName: "EC_FS_TXN_AMT_DESC" },
							{ label: '04 3000萬以上', value: '04 3000萬以上', colName: "EC_FS_TXN_AMT_DESC" },
						]
					},
					{ id: "11", type: "RANGE", name: "海外股庫存資產", nameEN: "AUM_FOREIGNSK", nameCH: "海外股庫存資產", desc: "月底海外股庫存資產", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "FS_AMT_TWD" },
						]
					},
					{ id: "12", type: "RANGE", name: "海外股貢獻", nameEN: "FEE_FOREIGNSK", nameCH: "海外股貢獻", desc: "今年海外股貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "FS_SF_AMT_TWD" },
						]
					},
					{ id: "13", type: "CHECKBOX", name: "海外債當月交易量級距", nameEN: "BOND_TXN_AMT_DESC", nameCH: "海外債交易級距", desc: "", options: [ 
							{ label: '00 當月未交易', value: '00 當月未交易', colName: "BOND_TXN_AMT_DESC" },
							{ label: '01 300萬(含)以下', value: '01 300萬(含)以下', colName: "BOND_TXN_AMT_DESC" },
							{ label: '02 300萬(含)~3000萬', value: '02 300萬(含)~3000萬', colName: "BOND_TXN_AMT_DESC" },
							{ label: '03 300萬(含)~1億', value: '03 300萬(含)~1億', colName: "BOND_TXN_AMT_DESC" },
							{ label: '04 1億(含)以上', value: '04 1億(含)以上', colName: "BOND_TXN_AMT_DESC" },
						]
					},
				]
			},
			{ id: "10", name: "產品_基金", children: [
					{ id: "1", type: "CHECKBOX", name: "基金實動", nameEN: "ACTIVE_MF", nameCH: "基金實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_MF_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_MF_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "基金電子實動", nameEN: "ECACTIVE_MF", nameCH: "基金電子實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_MF_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_MF_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月基金實動", nameEN: "ACTIVE_MF_M", nameCH: "當月基金實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "MF_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "MF_AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當月基金電子實動", nameEN: "ECACTIVE_MF_M", nameCH: "當月基金電子實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_MF_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_MF_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "基金年累交易量", nameEN: "TXAMT_MF", nameCH: "基金年累交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_MF_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "基金年累電子交易量", nameEN: "TXAMT_MF", nameCH: "基金年累電子交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_YM_MF_TXN_AMT" },
						]
					},
					{ id: "7", type: "RANGE", name: "基金當月交易量", nameEN: "TXAMT_MF_M", nameCH: "基金當月交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "MF_TXN_AMT" },
						]
					},
					{ id: "8", type: "RANGE", name: "基金當月電子交易量", nameEN: "TXAMT_MF_M", nameCH: "基金當月電子交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_MF_TXN_AMT" },
						]
					},
					{ id: "9", type: "RANGE", name: "基金庫存資產", nameEN: "TXAMT_MF", nameCH: "基金庫存資產", desc: "月底基金庫存資產", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "MF_AMT_TWD" },
						]
					},
					{ id: "10", type: "RANGE", name: "基金貢獻", nameEN: "FEE_MF", nameCH: "基金貢獻", desc: "今年基金貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "MF_SF_AMT_TWD" },
						]
					},
				]
			},
			{ id: "11", name: "產品_海外債", children: [
					{ id: "1", type: "CHECKBOX", name: "海外債實動", nameEN: "ACTIVE_BOND", nameCH: "海外債實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_BOND_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_BOND_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "當月海外債實動", nameEN: "ACTIVE_BOND_M", nameCH: "當月海外債實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "DW_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "DW_AT_FLAG" },
						]
					},
					{ id: "3", type: "RANGE", name: "海外債年累交易量", nameEN: "TXAMT_BOND", nameCH: "海外債年累交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_BOND_TXN_AMT" },
						]
					},
					{ id: "4", type: "RANGE", name: "海外債當月交易量", nameEN: "TXAMT_BOND_M", nameCH: "海外債當月交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "BOND_TXN_AMT" },
						]
					},
					{ id: "5", type: "CHECKBOX", name: "海外債當月交易金額級距", nameEN: "TXLEVEL_BOND", nameCH: "海外債當月交易金額級距", desc: "海外債交易金額級距", options: [ 
						]
					},
					{ id: "6", type: "RANGE", name: "海外債庫存資產", nameEN: "TXAMT_BOND", nameCH: "海外債庫存資產", desc: "月底海外債庫存資產", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "BOND_AMT_TWD" },
						]
					},
					{ id: "7", type: "RANGE", name: "海外債貢獻", nameEN: "FEE_BOND", nameCH: "海外債貢獻", desc: "今年海外債貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "BOND_SF_AMT_TWD" },
						]
					},
				]
			},
			{ id: "12", name: "產品_結構型商品", children: [
					{ id: "1", type: "CHECKBOX", name: "結構型商品實動", nameEN: "ACTIVE_SN", nameCH: "結構型商品實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_SN_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_SN_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "當月結構型商品實動", nameEN: "ACTIVE_SN_M", nameCH: "當月結構型商品實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "SN_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "SN_AT_FLAG" },
						]
					},
					{ id: "3", type: "RANGE", name: "結構型商品年累交易量", nameEN: "TXAMT_SN", nameCH: "結構型商品年累交易量", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_SN_TXN_AMT" },
						]
					},
					{ id: "4", type: "RANGE", name: "結構商品當月交易量", nameEN: "TXAMT_SN_M", nameCH: "結構商品當月交易量", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "SN_TXN_AMT" },
						]
					},
					{ id: "5", type: "RANGE", name: "結構型商品庫存資產", nameEN: "TXAMT_SN", nameCH: "結構型商品庫存資產", desc: "月底結構型商品庫存資產", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "SN_AMT_TWD" },
						]
					},
					{ id: "6", type: "RANGE", name: "結構型商品貢獻", nameEN: "FEE_SN", nameCH: "結構型商品貢獻", desc: "今年結構型商品貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "SN_SF_AMT_TWD" },
						]
					},
				]
			},
			{ id: "13", name: "產品_保險", children: [
					{ id: "1", type: "CHECKBOX", name: "保險實動", nameEN: "ACTIVE_INSURE", nameCH: "保險實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_INSURE_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_INSURE_AT_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "當月保險實動", nameEN: "ACTIVE_INSURE_M", nameCH: "當月保險實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "INSURE_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "INSURE_AT_FLAG" },
						]
					},
					{ id: "3", type: "RANGE", name: "年累保險金額", nameEN: "TXAMT_INSURE", nameCH: "年累保險金額", desc: "當年產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_INSURE_TXN_AMT" },
						]
					},
					{ id: "4", type: "RANGE", name: "當月保險金額", nameEN: "TXAMT_INSURE_M", nameCH: "當月保險金額", desc: "當月產品全部交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "INSURE_TXN_AMT" },
						]
					},
					{ id: "5", type: "RANGE", name: "保險保費收入", nameEN: "TXAMT_INSURE", nameCH: "保險保費收入", desc: "月底保險保費收入", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "INSURE_SF_AMT_TWD" },
						]
					},
					{ id: "6", type: "RANGE", name: "保險貢獻", nameEN: "FEE_INSURE", nameCH: "保險貢獻", desc: "今年保險貢獻", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "INSURE_SF_AMT_TWD" },
						]
					},
				]
			},
			{ id: "14", name: "產品_抽籤", children: [
					{ id: "1", type: "CHECKBOX", name: "抽籤實動", nameEN: "ACTIVE_DRAWING", nameCH: "抽籤實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "YM_DW_ACTICE_FLAG" },
							{ label: 'N', value: 'N', colName: "YM_DW_ACTICE_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "抽籤電子實動", nameEN: "ECACTIVE_DRAWING", nameCH: "抽籤電子實動", desc: "當年是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_YM_DW_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_YM_DW_AT_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "當月抽籤實動", nameEN: "ACTIVE_DRAWING_M", nameCH: "當月抽籤實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "DW_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "DW_AT_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "當月抽籤電子實動", nameEN: "ECACTIVE_DRAWING_M", nameCH: "當月抽籤電子實動", desc: "當月是否交易該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "EC_DW_AT_FLAG" },
							{ label: 'N', value: 'N', colName: "EC_DW_AT_FLAG" },
						]
					},
					{ id: "5", type: "RANGE", name: "抽籤年累交易筆數", nameEN: "TXAMT_DRAWING", nameCH: "抽籤年累交易筆數", desc: "當年產品全部交易筆數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_DW_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "抽籤年累電子筆數", nameEN: "TXAMT_DRAWING", nameCH: "抽籤年累電子筆數", desc: "當月產品電子交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_YM_DW_TXN_CNT" },
						]
					},
					{ id: "7", type: "RANGE", name: "抽籤當月交易筆數", nameEN: "TXAMT_DRAWING_M", nameCH: "抽籤當月交易筆數", desc: "當月產品全部交易筆數", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "DW_TXN_AMT_TWD" },
						]
					},
					{ id: "8", type: "RANGE", name: "抽籤當月電子交易筆數", nameEN: "TXAMT_DRAWING_M", nameCH: "抽籤當月電子交易筆數", desc: "當月產品電子交易量", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EC_DW_TXN_CNT" },
						]
					},
				]
			},
			{ id: "15", name: "電子平台交易量", children: [
					{ id: "1", type: "RANGE", name: "台股e01金額", nameEN: "SK_E01", nameCH: "台股e01金額", desc: "台股e01金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_E01_TXN_AMT" },
						]
					},
					{ id: "2", type: "RANGE", name: "台股e+PC金額", nameEN: "SK_EPLUSPC", nameCH: "台股e+PC金額", desc: "台股e+PC金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_EPLUS_PC_TXN_AMT" },
						]
					},
					{ id: "3", type: "RANGE", name: "台股e+行動金額", nameEN: "SK_EPLUS", nameCH: "台股e+行動金額", desc: "台股e+行動金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_EPLUS_M_TXN_AMT" },
						]
					},
					{ id: "4", type: "RANGE", name: "台股e點通金額", nameEN: "SK_EPOINT", nameCH: "台股e點通金額", desc: "台股e點通金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "YM_EPOINT_TXN_AMT" },
						]
					},
					{ id: "5", type: "RANGE", name: "台股當月e01金額", nameEN: "SK_E01_M", nameCH: "台股當月e01金額", desc: "台股當月e01金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "E01_TXN_AMT" },
						]
					},
					{ id: "6", type: "RANGE", name: "台股當月e+PC金額", nameEN: "SK_EPLUSPC_M", nameCH: "台股當月e+PC金額", desc: "台股當月e+PC金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EPLUS_PC_TXN_AMT" },
						]
					},
					{ id: "7", type: "RANGE", name: "台股當月e+行動金額", nameEN: "SK_EPLUS_M", nameCH: "台股當月e+行動金額", desc: "台股當月e+行動金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EPLUS_M_TXN_AMT" },
						]
					},
					{ id: "8", type: "RANGE", name: "台股當月e點通金額", nameEN: "SK_EPOINT_M", nameCH: "台股當月e點通金額", desc: "台股當月e點通金額", options: [ 
							{ label: '可輸入 >=、 <=、 between ? ~ ?', value: '可輸入 >=、 <=、 between ? ~ ?', colName: "EPOINT_TXN_AMT" },
						]
					},
				]
			},
		]
	},
	{ id: "4", name: "產品偏好", icon: 'fa-grin-hearts', children: [
			{ id: "1", name: "當月是否持有產品", children: [
					{ id: "1", type: "RANGE", name: "持有產品個數", nameEN: "HOLDIND", nameCH: "持有產品個數", desc: "客戶持有庫存的產品個數，產品種類共11項，包含:1.台股、2.海外股票、3.複委託基金、4.通入借入、5.不限用途、6.信託基金、7.海外債、8.結構型商品、9.人壽", options: [ 
							{ label: '0~9', value: '0~9', colName: "TOTAL_HOLDING_CNT" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "持有台股註記", nameEN: "HOLDIND_SK", nameCH: "持有台股註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "TS_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "TS_HOLDING_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "持有信用註記", nameEN: "HOLDIND_CREDIT", nameCH: "持有信用註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "CD_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "CD_HOLDING_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "持有不限用途註記", nameEN: "HOLDIND_C7CD", nameCH: "持有不限用途註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "URUL_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "URUL_HOLDING_FLAG" },
						]
					},
					{ id: "5", type: "CHECKBOX", name: "持有通入借入註記", nameEN: "HOLDIND_D8CD", nameCH: "持有通入借入註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "BSBL_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "BSBL_HOLDING_FLAG" },
						]
					},
					{ id: "6", type: "CHECKBOX", name: "持有海外股註記", nameEN: "HOLDIND_FOREIGNSK", nameCH: "持有海外股註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "FS_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "FS_HOLDING_FLAG" },
						]
					},
					{ id: "7", type: "CHECKBOX", name: "持有基金註記", nameEN: "HOLDIND_MF", nameCH: "持有基金註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "MF_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "MF_HOLDING_FLAG" },
						]
					},
					{ id: "8", type: "CHECKBOX", name: "持有海外債註記", nameEN: "HOLDIND_BOND", nameCH: "持有海外債註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "BOND_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "BOND_HOLDING_FLAG" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "持有結構型商品註記", nameEN: "HOLDIND_SN", nameCH: "持有結構型商品註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "SN_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "SN_HOLDING_FLAG" },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "持有保險商品註記", nameEN: "HOLDIND_INSURE", nameCH: "持有保險商品註記", desc: "是否持有該產品，Ｙ：是，Ｎ：否", options: [ 
							{ label: 'Y', value: 'Y', colName: "INSURE_HOLDING_FLAG" },
							{ label: 'N', value: 'N', colName: "INSURE_HOLDING_FLAG" },
						]
					},
				]
			},
			{ id: "2", name: "喜好的台股產業類股", children: [
					{ id: "1", type: "CHECKBOX", name: "化工", nameEN: "CHEMICAL_IND", nameCH: "化工", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "CHEMICAL_FLAG" },
							{ label: '0', value: '0', colName: "CHEMICAL_FLAG" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "生技", nameEN: "BIO_IND", nameCH: "生技", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "BIO_FLAG" },
							{ label: '0', value: '0', colName: "BIO_FLAG" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "金融", nameEN: "FINANCE_IND", nameCH: "金融", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "FINANCE_FLAG" },
							{ label: '0', value: '0', colName: "FINANCE_FLAG" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "玻璃", nameEN: "GLASS_IND", nameCH: "玻璃", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "GLASS_FLAG" },
							{ label: '0', value: '0', colName: "GLASS_FLAG" },
						]
					},
					{ id: "5", type: "CHECKBOX", name: "食品", nameEN: "FOOD_IND", nameCH: "食品", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "FOOD_FLAG" },
							{ label: '0', value: '0', colName: "FOOD_FLAG" },
						]
					},
					{ id: "6", type: "CHECKBOX", name: "紡織", nameEN: "SPINN_IND", nameCH: "紡織", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "SPINN_FLAG" },
							{ label: '0', value: '0', colName: "SPINN_FLAG" },
						]
					},
					{ id: "7", type: "CHECKBOX", name: "航運", nameEN: "SHIPP_IND", nameCH: "航運", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "SHIPP_FLAG" },
							{ label: '0', value: '0', colName: "SHIPP_FLAG" },
						]
					},
					{ id: "8", type: "CHECKBOX", name: "通訊軟體", nameEN: "SOFT_IND", nameCH: "通訊軟體", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "SOFT_FLAG" },
							{ label: '0', value: '0', colName: "SOFT_FLAG" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "貿易", nameEN: "TRADE_IND", nameCH: "貿易", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "TRADE_FLAG" },
							{ label: '0', value: '0', colName: "TRADE_FLAG" },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "塑膠", nameEN: "PLASTIC_IND", nameCH: "塑膠", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "PLASTIC_FLAG" },
							{ label: '0', value: '0', colName: "PLASTIC_FLAG" },
						]
					},
					{ id: "11", type: "CHECKBOX", name: "電子", nameEN: "ELEC_IND", nameCH: "電子", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "ELEC_FLAG" },
							{ label: '0', value: '0', colName: "ELEC_FLAG" },
						]
					},
					{ id: "12", type: "CHECKBOX", name: "電器電纜", nameEN: "ELECAPPLI_IND", nameCH: "電器電纜", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "ELECAPPLI_FLAG" },
							{ label: '0', value: '0', colName: "ELECAPPLI_FLAG" },
						]
					},
					{ id: "13", type: "CHECKBOX", name: "橡膠", nameEN: "RUBBER_IND", nameCH: "橡膠", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "RUBBER_FLAG" },
							{ label: '0', value: '0', colName: "RUBBER_FLAG" },
						]
					},
					{ id: "14", type: "CHECKBOX", name: "鋼鐵", nameEN: "STEEL_IND", nameCH: "鋼鐵", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "STEEL_FLAG" },
							{ label: '0', value: '0', colName: "STEEL_FLAG" },
						]
					},
					{ id: "15", type: "CHECKBOX", name: "營建", nameEN: "CONSTRUATION_IND", nameCH: "營建", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "CONSTRUATION_FLAG" },
							{ label: '0', value: '0', colName: "CONSTRUATION_FLAG" },
						]
					},
					{ id: "16", type: "CHECKBOX", name: "觀光", nameEN: "TRAVEL_IND", nameCH: "觀光", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "TRAVEL_FLAG" },
							{ label: '0', value: '0', colName: "TRAVEL_FLAG" },
						]
					},
					{ id: "17", type: "CHECKBOX", name: "水泥", nameEN: "CEMENT_IND", nameCH: "水泥", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "CEMENT_FLAG" },
							{ label: '0', value: '0', colName: "CEMENT_FLAG" },
						]
					},
					{ id: "18", type: "CHECKBOX", name: "汽車", nameEN: "CAR_IND", nameCH: "汽車", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "CAR_FLAG" },
							{ label: '0', value: '0', colName: "CAR_FLAG" },
						]
					},
					{ id: "19", type: "CHECKBOX", name: "造紙", nameEN: "PAPER_IND", nameCH: "造紙", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "PAPER_FLAG" },
							{ label: '0', value: '0', colName: "PAPER_FLAG" },
						]
					},
					{ id: "20", type: "CHECKBOX", name: "基金", nameEN: "MT_IND", nameCH: "基金", desc: "當年有交易該產業類股，１：是　０：否", options: [ 
							{ label: '1', value: '1', colName: "MT_FLAG" },
							{ label: '0', value: '0', colName: "MT_FLAG" },
						]
					},
				]
			},
			{ id: "3", name: "產品交易旅程", children: [
					{ id: "1", type: "CHECKBOX", name: "第一交易產品", nameEN: "PREFER_PRD_1", nameCH: "第一交易產品", desc: "客戶交易旅程的第 1 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_1" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_1" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_1" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_1" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_1" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_1" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_1" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_1" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_1" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_1" },
						]
					},
					{ id: "2", type: "CHECKBOX", name: "第二交易產品", nameEN: "PREFER_PRD_2", nameCH: "第二交易產品", desc: "客戶交易旅程的第 2 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_2" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_2" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_2" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_2" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_2" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_2" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_2" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_2" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_2" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_2" },
						]
					},
					{ id: "3", type: "CHECKBOX", name: "第三交易產品", nameEN: "PREFER_PRD_3", nameCH: "第三交易產品", desc: "客戶交易旅程的第 3 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_3" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_3" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_3" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_3" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_3" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_3" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_3" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_3" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_3" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_3" },
						]
					},
					{ id: "4", type: "CHECKBOX", name: "第四交易產品", nameEN: "PREFER_PRD_4", nameCH: "第四交易產品", desc: "客戶交易旅程的第 4 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_4" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_4" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_4" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_4" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_4" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_4" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_4" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_4" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_4" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_4" },
						]
					},
					{ id: "5", type: "CHECKBOX", name: "第五交易產品", nameEN: "PREFER_PRD_5", nameCH: "第五交易產品", desc: "客戶交易旅程的第 5 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_5" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_5" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_5" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_5" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_5" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_5" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_5" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_5" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_5" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_5" },
						]
					},
					{ id: "6", type: "CHECKBOX", name: "第六交易產品", nameEN: "PREFER_PRD_6", nameCH: "第六交易產品", desc: "客戶交易旅程的第 6 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_6" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_6" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_6" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_6" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_6" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_6" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_6" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_6" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_6" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_6" },
						]
					},
					{ id: "7", type: "CHECKBOX", name: "第七交易產品", nameEN: "PREFER_PRD_7", nameCH: "第七交易產品", desc: "客戶交易旅程的第 7 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_7" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_7" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_7" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_7" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_7" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_7" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_7" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_7" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_7" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_7" },
						]
					},
					{ id: "8", type: "CHECKBOX", name: "第八交易產品", nameEN: "PREFER_PRD_8", nameCH: "第八交易產品", desc: "客戶交易旅程的第 8 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_8" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_8" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_8" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_8" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_8" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_8" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_8" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_8" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_8" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_8" },
						]
					},
					{ id: "9", type: "CHECKBOX", name: "第九交易產品", nameEN: "PREFER_PRD_9", nameCH: "第九交易產品", desc: "客戶交易旅程的第 9 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_9" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_9" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_9" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_9" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_9" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_9" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_9" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_9" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_9" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_9" },
						]
					},
					{ id: "10", type: "CHECKBOX", name: "第十交易產品", nameEN: "PREFER_PRD_10", nameCH: "第十交易產品", desc: "客戶交易旅程的第 10 個商品", options: [ 
							{ label: '海外債', value: '海外債', colName: "PREFER_PROD_10" },
							{ label: '不限用途', value: '不限用途', colName: "PREFER_PROD_10" },
							{ label: '結構型', value: '結構型', colName: "PREFER_PROD_10" },
							{ label: '定期定額', value: '定期定額', colName: "PREFER_PROD_10" },
							{ label: '期權', value: '期權', colName: "PREFER_PROD_10" },
							{ label: '台股', value: '台股', colName: "PREFER_PROD_10" },
							{ label: '海外股', value: '海外股', colName: "PREFER_PROD_10" },
							{ label: '抽籤', value: '抽籤', colName: "PREFER_PROD_10" },
							{ label: '基金', value: '基金', colName: "PREFER_PROD_10" },
							{ label: '通路借入', value: '通路借入', colName: "PREFER_PROD_10" },
						]
					},
				]
			},
		]
	},
];