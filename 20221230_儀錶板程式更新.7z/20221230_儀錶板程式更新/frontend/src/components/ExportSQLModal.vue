<template>
	<div class="modal fade" data-backdrop="static" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header text-center">
					<!-- SQL指定 -->
					<h5 class="modal-title w-100 m-1 py-2 font-weight-bold text-primary">
						{{ $t('sql.statement') }}
						<button type="button" class="close float-right" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</h5>
				</div>
				<div class="modal-body">
					{{ sql }}
					
					<br/>
					<div class="text-primary">
						<!-- 點我複製程式碼 -->
						<i class="fas fa-fw fa-clipboard "></i>
						<a @click="copySQL" style="font-size: medium;">{{ $t('click.to.copy') }}</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<style scoped>
@import '@/assets/css/style.css';

</style>
<script type="ts" src="./ExportSQLModal.ts"></script>