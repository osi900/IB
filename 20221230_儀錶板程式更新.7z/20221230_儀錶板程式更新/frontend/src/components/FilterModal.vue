<template>
	<div class="modal fade" data-backdrop="static" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">{{ tag.name }}</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<p v-if="tag.type != 'RANGE' && tag.type != 'TIME'"><!-- 全選 / 全部不選 -->
						<input id="selectAll" type="checkbox" @click="doSelectAll" v-model="selectAll"/>
						<label for="selectAll"> {{ $t('filter.toggle.all') }}</label>
					</p>
					<template v-if="tag.type == 'CHECKBOX'">
						<!-- 一般選項 -->
						<div v-for="(opt, i) in tag.options" :key="i" class="form-check form-check-inline">
							<input class="form-check-input" type="checkbox" @click="checkOptions(opt, i)" :id="opt.colName + '_' + i" :value="opt.value">
							<label class="form-check-label" :for="opt.colName + '_' + i" >{{ opt.label }}</label>
						</div>
					</template>
					<template v-if="tag.type == 'MCHECKBOX'">
						<!-- 兩層選項 -->
						<div :id="'collapse_' + i" class="accordion" v-for="(lv1opt, i) in tag.options" :key="i">
							<div class="card">
								<div class="card-header">
									<h2 class="mb-0">
										<input :class="'lv1Check_' + i" type="checkbox" @click="checkLv1Options(lv1opt, i)"/>
										<button class="btn btn-link" type="button" data-toggle="collapse" :data-target="'#' + lv1opt.colName + '_' + i" aria-expanded="true" :aria-controls="'collapse_' + i">{{ lv1opt.label }}</button>
									</h2>
								</div>
								<div v-if="lv1opt.options && lv1opt.options.length > 0" :id="lv1opt.colName + '_' + i" class="collapse" aria-labelledby="headingOne" :data-parent="'#collapse_' + i">
									<div class="card-body">
										<div v-for="(lv2opt, j) in lv1opt.options" :key="j" class="form-check form-check-inline">
											<input :class="'form-check-input ' + lv1opt.colName + '_' + i + '_' + j" type="checkbox" :id="lv2opt.colName + '_' + i + '_' + j" :value="lv2opt.value" @click="checkOptions(lv2opt, i + '_' + j)"/>
											<label :for="lv2opt.colName + '_' + i + '_' + j" class="form-check-label">{{ lv2opt.label }}</label>
										</div>
									</div>
								</div>
							</div>
						</div>
					</template>
					<template v-if="tag.type == 'RANGE'">
						<!-- 數字條件 -->
						<div class="form-inline">
							<div class="mb-2 mr-sm-2">
								<a>{{ tag.name }}</a>
							</div>
							<div class="mb-2 mr-sm-5 col-2">
								<select v-model="op" class="custom-select mr-sm-3" name="oneselect">
									<option selected value="&gt;">&gt;</option>
									<option selected value="&lt;">&lt;</option>
									<option selected value="&gt;=">≥</option>
									<option value="&lt;=">≤</option>
									<option value="between">between</option>
								</select>
							</div>
							<div class="mb-2 mr-sm-2 col-4">
								<input v-model="quantity" class="form-control text-right col-auto" type="text">
							</div>
							<!-- 
							<div class="mb-2 mr-sm-2 col-1">
								<select class="custom-select mr-sm-2">
									<option value="個" selected>個</option>
								</select>
							</div>
							 -->
							<div>
								<p>#Between輸入案例：1 AND 100</p>
								<p v-if="false">#{{ tag.options[0].label }}</p>
							</div>
						</div>
					</template>
					<template v-if="tag.type == 'TIME'">
						<div class="form-inline">
							<div class="mb-2 mr-sm-2">
								<a>{{ tag.name }}</a>
							</div>
							<div class="mb-2 mr-sm-5 col-2">
								<select v-model="op" class="custom-select mr-sm-3" name="oneselect">
									<option selected value="&gt;">&gt;</option>
									<option selected value="&lt;">&lt;</option>
									<option selected value="&gt;=">≥</option>
									<option value="&lt;=">≤</option>
									<option value="between">between</option>
								</select>
							</div>
							<div class="mb-2 mr-sm-2 col-4">
								<input id="dateInput" placeholder="YYYY/MM/DD" class="form-control text-right col-auto" type="text">
								<div :style="op == 'between' ? '' : 'display:none'">
									~
									<input id="dateInput2" placeholder="YYYY/MM/DD" class="form-control text-right col-auto" type="text">
								</div>
							</div>
						</div>
					</template>
				</div>
				<div class="modal-footer">
					<!-- 關閉 -->
					<button type="button" class="btn btn-secondary" data-dismiss="modal">{{ $t('button.close') }}</button>
					<!-- 確認選取 -->
					<button @click="confirm" type="button" class="btn btn-primary">{{ $t('button.confirm.select') }}</button>
				</div>
			</div>
		</div>
	</div>
</template>

<style scoped>
@import '@/assets/css/style.css';

</style>
<script type="ts" src="./FilterModal.ts"></script>