<template>
	<div class="modal fade" data-backdrop="static" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-body">
					<!-- 請命名標籤群 -->
					<div class="form-group">
						<div class="h3">{{ $t('naming.your.group') }}</div>
						<input type="text" class="form-control form-control-user" v-model="groupName"/>
					</div>
				</div>
				<div class="modal-footer">
					<!-- 關閉 -->
					<button class="btn btn-secondary btn-user" data-dismiss="modal">{{ $t('button.close') }}</button>
					<!-- 確認儲存 -->
					<button @click="saveTagGroup" class="btn btn-primary btn-user">{{ $t('button.confirm.save') }}</button>
				</div>
			</div>
		</div>
	</div>
</template>
<style scoped>
@import '@/assets/css/style.css';

</style>
<script type="ts" src="./SaveTagGroupModal.ts"></script>