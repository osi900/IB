/* eslint-disable prefer-const */
//import { TAG_DATA } from '@/commons/tags';
import { deepClone } from '@/commons/utilities/deep-clone.fn';
import { isBlank } from '@/commons/validators/is-blank.fn';
import FilterModal from '@/components/FilterModal.vue';
import { PageBaseComponent } from '@/components/PageBaseComponent';
import $ from 'jquery';
import { Component } from 'vue-property-decorator';
import { TagData, TagDataThird } from './../commons/tags';
import axios from 'axios';

@Component({
	components: {
		FilterModal
	}
})
export default class LeftMenu extends PageBaseComponent {

	tags: TagData[] = [];
	searchKeyword = '';

	$refs!: {
		cateTops: Array<HTMLAnchorElement>,
		filterModal: any
	};

	/**
	 * 建構子
	 */
	constructor() {
		super();
	}

	mounted() {
		($('[data-toggle="tooltip"]') as any).tooltip();
		this.tags = this.$store.state.allTags;
		//this.tags = TAG_DATA;
	}
	
	enterPass() {
		console.log('enter pass');
	}

	/** 依輸入內容過濾分類 */
	onSearchInput() {
		//console.debug('searchKeyword: ', this.searchKeyword);
		if (!isBlank(this.searchKeyword)) {
			const tagDatas = deepClone(this.$store.state.allTags);
			let mainCates: TagData[] = [];
			for (let tagMain of tagDatas) {
				const levelTwos = deepClone(tagMain.children);
				tagMain.children = [];
				for (let tagSecond of levelTwos) {
					let lvThrees = [];
					for (const levelThrids of tagSecond.children) {
						if (levelThrids.name.indexOf(this.searchKeyword) > -1) {
							lvThrees.push(levelThrids);
						}
					}
					if (lvThrees.length > 0) {
						tagSecond.children = lvThrees;
						tagMain.children.push(tagSecond);
					}
				}
				if (tagMain.children.length > 0) {
					mainCates.push(tagMain);
				}
			}
			this.tags = mainCates;
		} else {
			this.tags = this.$store.state.allTags;
		}

	}

	/**
	 * 設定modal
	 */
	showOptions(lv3: any) {
		const modal: any = (this.$refs.filterModal as any);
		modal.show(lv3);
	}
	
	setTooltip() {
		setTimeout(() => {
			($('[data-toggle="tooltip"]') as any).tooltip();
		}, 100);
	}


	public showOptionFromFilterBtn(filterKey: string) {
		
		// 定位標籤
		let mainCateIdx = -1;
		let secondCateIdx = -1;
		let thirdCate: TagDataThird = {} as TagDataThird;
		for (let i = 0; i < this.$store.state.allTags.length; i++) {
			const levelTwos = this.$store.state.allTags[i].children;
			for (let j = 0; j< levelTwos.length; j++) {
				for (const levelThrids of levelTwos[j].children) {
					if (levelThrids.type == 'TIME' && levelThrids.nameEN == filterKey) {
						thirdCate = levelThrids;
						secondCateIdx = j;
						mainCateIdx = i;
						break;
						
					} else {
						for (let k = 0; k < levelThrids.options.length; k++) {
							if (levelThrids.options[k].colName == filterKey) {
								thirdCate = levelThrids;
								secondCateIdx = j;
								mainCateIdx = i;
								break;
							}
							
							if (levelThrids.options[k].options) {
								const opts = levelThrids.options[k].options!;
								for (let l = 0; l < opts.length; l++) {
									if (opts[l].colName == filterKey) {
										thirdCate = levelThrids;
										secondCateIdx = j;
										mainCateIdx = i;
										break;
									}
								}
							}
						}
					}
					
				}
			}
		}

		// 展開標籤
		if(this.$refs.cateTops){
			for( let i = 0; i < this.$refs.cateTops.length; i++){
				if (mainCateIdx == i) {
	
					if(!$(this.$refs.cateTops[i]).attr('aria-expanded')){
						($(`#collapsePages${i}`) as any).collapse('show')
					}
	
					if($(`a[data-target="#collapsePages_${i}_${secondCateIdx}"]`)){
						if(!$(`a[data-target="#collapsePages_${i}_${secondCateIdx}"]`).attr('aria-expanded')){
							($(`#collapsePages_${i}_${secondCateIdx}`) as any).collapse('show');
						}
					}
					this.showOptions(thirdCate);

					break;
				}
	
			}

		}

	}
}