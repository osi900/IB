import { PageBaseComponent } from '@/components/PageBaseComponent';
import $ from 'jquery';
import { Component } from 'vue-property-decorator';
import axios from 'axios';

@Component({})
export default class LogoutModal extends PageBaseComponent {
	
	constructor() {
		super();
	}
	
	show() {
		axios.get('/login/logout', {})
				.then((rs: any) => {
					this.$store.state.token = null;
					($(this.$el) as any).modal('show');
				}).catch((err) => {
					console.log(err);
					console.log('登出失敗');
				});
	}
	
	logout() {
		($(this.$el) as any).modal('hide');
		this.$router.push('/login');
	}
}