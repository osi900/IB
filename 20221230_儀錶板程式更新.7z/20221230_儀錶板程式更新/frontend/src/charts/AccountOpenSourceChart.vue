<template>
	<Chart @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<div ref="acctOpenSourceChart" slot="chart" style="height: 100%;width: 100%; overflow-y: auto;">
			<div class="table-responsive-sm" ref="acctOpenSourceTable">
				<table class="table table-bordered table-sm table-striped table-hover">
						<thead class="text-center">
						<tr>
							<th>進件來源</th>
							<th>當月開戶數</th>
							<th>當月開戶數佔比(%)</th>
							<th>年累開戶數</th>
							<th>年累開戶數佔比(%)</th>
						</tr>
					</thead>
					<tbody>
						<tr v-for="(data_, i) in data" v-bind:key="'acct_open_source_'+i"
						:class="data_.source.indexOf('小計') > -1 ? 'table-info' : ''">
							<td>{{data_.source}}</td>
							<td style="text-align: right;">{{data_.acctOpenThisMonth}}</td>
							<td style="text-align: right;">{{data_.acctOpenThisMonthPropo}}</td>
							<td style="text-align: right;">{{data_.acctOpenThisYear}}</td>
							<td style="text-align: right;">{{data_.acctOpenThisYearPropo}}</td>
						</tr>
					</tbody>
				</table>		
			</div>
		</div>
	</Chart>
</template>

<script type="ts" src="./AccountOpenSourceChart.ts"></script>