<template>
	<div>
		<div class="card shadow mb-4">
			<div class="card-header py-1">
				<div>
					<h6 class="m-1 py-2 font-weight-bold text-primary text-center">
						【<slot name="title"></slot>】
						<button @click="$emit('showModal')" class="btn btn-sm text-gray-600 float-right">
							<i class="fas fa-sm fa-expand"></i>
						</button>
					</h6>
				</div>
			</div>
			<div class="card-body">
				<div style="width:100%; min-width: 100%;height:400px;">
					<slot name="chart"></slot>
				</div>
			</div>
		</div>
	</div>
</template>

<style>

</style>

<script type="ts" src="./Chart.ts"></script>