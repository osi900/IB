<template>
	<Chart @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<template slot="chart">
			<a @click="exportExcel" class="sidebar-brand d-flex align-items-end justify-content-end mb-2">
				<div class="sidebar-brand-icon">
					<img class="img-fluid" src="@/assets/img/excel.png" width="25" />
				</div>
			</a>
			<div class="table-responsive" ref="top10Table" style="height: 90%;width: 100%;">
				<table class="table table-bordered table-sm table-striped table-hover">
					<thead class="text-center">
						<tr>
							<th>排名</th>
							<th>產業</th>
							<th>戶數</th>
							<th>佔比(%)</th>
						</tr>
					</thead>
					<tbody>
						<tr v-for="(data_, i) in data" v-bind:key="i">
							<td style="text-align: center;">{{data_.rank}}</td>
							<td style="text-align: center;">{{data_.industry}}</td>
							<td style="text-align: right;">{{formatNumber(data_.cnt)}}</td>
							<td style="text-align: right;">{{data_.ratio}}</td>
						</tr>
					</tbody>
				</table>		
			</div>
		</template>
	</Chart>
	
</template>

<script type="ts" src="./Top10Chart.ts"></script>