<template>
		<ChartTabs @showModal="showModal">
			<span slot="title">{{ title }}</span>
			<!-- 頁簽 -->
			<ul slot="tabs" class="nav nav-tabs card-header-tabs pull-right" role="tablist">
				<li class="nav-item">
					<a class="nav-link active" id="elecAcctAmtTab1-tab" data-toggle="tab" href="#elecAcctAmtTab1" role="tab" aria-controls="cusincome" aria-selected="true">年累佔比</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" id="elecAcctAmtTab2-tab" data-toggle="tab" href="#elecAcctAmtTab2" role="tab" aria-controls="cusunincome" aria-selected="false">年累金額</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" id="elecAcctAmtTab3-tab" data-toggle="tab" href="#elecAcctAmtTab3" role="tab" aria-controls="cusunincome" aria-selected="false">年累戶數</a>
				</li>
			</ul>
			<template slot="chart">
				<div id="elecAcctAmtTab1" style="height: 100%" class="tab-pane fade show active" role="tabpanel" aria-labelledby="elecAcctAmtTab1-tab">
					<div ref="elecAcctAmtChart" style="height: 100%"></div>		
				</div>
				<div id="elecAcctAmtTab2" style="height: 100%" class="tab-pane fade show active" role="tabpanel" aria-labelledby="elecAcctAmtTab2-tab">
					<div ref="elecAmtChart" style="height: 100%"></div>		
				</div>
				<div id="elecAcctAmtTab3" style="height: 100%" class="tab-pane fade show active" role="tabpanel" aria-labelledby="elecAcctAmtTab3-tab">
					<div ref="elecAcctChart" style="height: 100%"></div>		
				</div>
			</template>
		</ChartTabs>

	
</template>

<script type="ts" src="./ElectronicAcctAmtChart.ts"></script>