<template>
	<Chart @showModal="showModal">
		<span slot="title">{{ title }}</span>
		<div ref="customerDistributionChart" slot="chart" style="height: 100%"></div>
	</Chart>
</template>

<script type="ts" src="./CustomerDistributionChart.ts"></script>