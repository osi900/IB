<template>
	<div class="bg-gradient-primary">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-xl-10 col-lg-12 col-md-9">
					<div class="card o-hidden border-0 shadow-lg my-5">
						<div class="card-body p-12">
							<div class="row">
								<div class="col-lg-12">
									<div class="col-lg-12">
										<div class="text-center">
											<h1 class="h4 text-gray-900 mb-4">歡迎來到 富邦證券客群觀測站</h1>
										</div>
										
										<div v-if="embedded" class="form-group">
											<h5 class="text-center">{{ message }}</h5>
										</div>
										
										<form v-if="!embedded" class="user">
											<div class="form-group">
												<input type="text" class="form-control form-control-user" aria-describedby="emailHelp" 
													:placeholder="$t('login.email.placeholder')" v-model="form.email"/>
											</div>
											<div class="form-group">
												<input type="password" class="form-control form-control-user" 
													:placeholder="$t('login.password.placeholder')" v-model="form.password"/>
											</div>
											<div class="form-group">
												<h5 class="text-center">保密切結書</h5>
												<div style="resize:none; width:100%; font-family:Microsoft JhengHei;border: 1px solid #000;padding: 5px;">
													富邦證券所使用之軟體或程式等所有內容（包括但不限於著作、圖片、檔案、資訊、資料、網站架構、網站畫面的安排、網頁設計等），均由富邦證券依法擁有其智慧財產權（包括但不限於商標權、專利權、著作權、營業秘密與專有技術等）。非經富邦證券合法授權，任何人不得逕自使用、修改、重製、公開播送、改作、散布、發行、公開發表、進行還原工程、解編或反向組譯。
													<ol>
														<li>本人(申請人員)承諾於在職期間或離職後,應依法令或公司規定不得洩漏業務有關之一切資料(包括但不限於客戶資料、足以識別客戶個人之資料、客戶資料庫原始及分析資料、公司營運資料、因職務產生之創作資料等相關資料)予第三人。</li>
														<li>如違上述規定者,本人願對所任職公司、富邦金融控股股份有限公司、其子公司及相關公司客戶或其他受損害之第三人負損害賠償責任。</li>
													</ol>
												</div>
											</div>
											<div class="form-group">
												<input id="ckbox" class="text-dark" type="checkbox" v-model="form.ck"> 
												<label for="ckbox">本人同意遵守上述保密切結書所列事項</label>
											</div>
											
											<hr/>
											<button type="submit" class="btn btn-primary btn-user btn-block" @click.prevent="doLogin" :disabled="!form.ck">登入</button>
										</form>
									</div>
								</div>
							
							
							
							
							
								
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<style scoped>

@import '@/assets/css/style.css';

</style>

<script type="ts" src="./Login.ts"></script>