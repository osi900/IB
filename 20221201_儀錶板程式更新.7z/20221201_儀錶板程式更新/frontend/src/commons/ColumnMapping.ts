
/**
 * 欄位中文名稱
 */
export class ColumnMapping {

	private static mapper: any = {
		
	};

	static initTags(allTags: any) {
		for (const tagMain of allTags) {
				const levelTwos = tagMain.children;
				for (const tagSecond of levelTwos) {
					for (const levelThrids of tagSecond.children) {
						ColumnMapping.mapper[levelThrids.nameEN] = levelThrids.nameCH;
						debugger;
					}
				}
			}
	}

	/**
	 * 查詢欄位名稱
	 */
	static getName(key: string) {
		return this.mapper[key];
	}
}