import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import i18n from './i18n'
import axios from 'axios'

import '@fortawesome/fontawesome-free/css/all.min.css'
import { BootstrapVue } from 'bootstrap-vue'
import 'bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
Vue.use(BootstrapVue)

// 初始化axios
axios.defaults.baseURL = '/Dashboard/api'
axios.defaults.headers.common.Accept = 'application/json'
axios.interceptors.request.use(
	(request) => {
		store.state.showLoading = true;
		
		if (store.state.token) {
			request.headers = {
				'Authorization': `Bearer ${store.state.token}`,
				'Accept': 'application/json'
			}
		}
		
		
		console.log('發送請求: ' + request.url);
		return request;
	},
	(error) => {
		console.log('發送請求失敗: ');
		console.log(error);
		return Promise.reject(error)
	}
)

// ajax錯誤處理
axios.interceptors.response.use(
	(response: any) => {
		console.log('回應: ' + response.config.url);
		console.log(response);
		store.state.showLoading = false;
		
		if (response.data.code === '9990') {
			// 尚未登入
			if (store.state.token) {
				store.state.token = 'timeout';
			}
			router.push('/login');
			
		} else if (response.data.code === '9994') {
			// 欄位檢核失敗
			const keys = Object.keys(response.data.payloads);
			let msg = response.data.code + '-' + response.data.message + '\n';
			for (const k of keys) {
				if (k != 'cause') {
					msg += response.data.payloads[k] + '\n';
				}
			}
			alert(msg);
			return Promise.reject(response.data);
			
		} else if (response.data.type == 'application/octet-stream') { // 檔案下載
			return response.data;
			
		} else if (response.data.code == '9999') {
			alert(response.data.code + '-' + response.data.message);
			return Promise.reject(response.data);
			
		} else if (response.data.code != '0000') {
			return Promise.reject(response.data);
		}
		return response;
	},
	(error) => {
		console.log('回應失敗: ');
		console.log(error);
		
		return Promise.reject(error)
	}
)

Vue.config.productionTip = false

new Vue({
	router,
	store,
	i18n,
	render: h => h(App)
}).$mount('#app')


