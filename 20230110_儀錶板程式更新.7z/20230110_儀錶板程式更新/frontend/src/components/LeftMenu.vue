<template>
	<div class="pt-2">
		<ul id="accordionSidebar" class="navbar-nav bg-gradient-info sidebar sidebar-dark accordion">
			<!-- 
			<a class="sidebar-brand d-flex align-items-center justify-content-center">
				<div class="sidebar-brand-icon">
					<img class="img-fluid" src="@/assets/img/fulogo.png" width="50" height="47"/>
				</div>
				<div class="sidebar-brand-text mx-3">
					<img class="img-fluid" src="@/assets/img/fubon.png"/>
				</div>
			</a>
			<hr class="sidebar-divider my-0"/>
			 -->
			<li class="nav-item active">
				<a class="nav-link">
					<i class="fas fa-fw fa-tachometer-alt active"></i>
					<!-- 客群觀測站 -->
					<span style="font-size:medium;">{{ $t('home.left.menu.title') }}</span>
				</a>
			</li>
			<hr class="sidebar-divider"/>
			
			<form v-on:submit.prevent="enterPass" class="d-none d-sm-inline-block form-inline mr-3 ml-md-3 my- my-md-1 mw-100 navbar-search">
				<div class="input-group">
					<input type="text" v-model="searchKeyword" class="form-control bg-light border-0 small" aria-label="Search" 
						aria-describedby="basic-addon2" :placeholder="$t('home.search.placeholder')" @input="onSearchInput"/>
				</div>
			</form>
			
			<li v-for="(tag, i) in tags" class="nav-item font-weight-bold">
				<a ref="cateTops" class="nav-link collapsed" data-toggle="collapse" :data-target="'#collapsePages' + i" aria-expanded="false" :aria-controls="'collapsePages' + i" :data-topid="'top_'+tag.id">
					<i :class="'fas fa-fw ' + tag.icon"></i>
					<!-- 第一層 -->
					<span style="font-size:medium;">{{ tag.name }}</span>
				</a>
				<div :id="'collapsePages' + i" class="collapse" data-parent="#accordionSidebar">
					<div class="bg-white py-2 collapse-inner rounded">
						<div :id="'page_' + i">
							<template v-for="(lv2, j) in tag.children">
								<a @click="setTooltip()" class="nav-link collapsed" data-toggle="collapse" :data-target="'#collapsePages_' + i + '_' + j" :aria-controls="'collapsePages_' + i + '_' + j">
									<i class="fas fa-fw fa-user"></i>
									<!-- 第二層 -->
									<span class="text-primary" style="font-size:medium;">{{ lv2.name }}</span>
								</a>
								<div :id="'collapsePages_' + i + '_' + j" class="collapse" aria-labelledby="headingPages11" :data-parent="'#page_' + i">
									<div class="bg-white py-2 collapse-inner rounded text-left" style="font-size:medium;">
										<a v-for="(lv3, k) in lv2.children" class="collapse-item" @click="showOptions(lv3)">
											<!-- 第三層 -->
											{{ lv3.name }}
											<button v-show="lv3.desc" class="btn" data-toggle="tooltip" data-html="true" data-placement="right" :title="lv3.desc">
												<img class="img-fluid" width="15" height="15" src="@/assets/img/ques.png">
											</button>
										</a>
									</div>
								</div>
							</template>
						</div>
					</div>
				</div>
			</li>
		</ul>
		<FilterModal ref="filterModal"></FilterModal>
	</div>
</template>

<style scoped>
@import '@/assets/css/style.css';

</style>
<script type="ts" src="./LeftMenu.ts"></script>