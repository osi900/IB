import { Vue } from 'vue-property-decorator';

export class PageBaseComponent extends Vue {
	
}