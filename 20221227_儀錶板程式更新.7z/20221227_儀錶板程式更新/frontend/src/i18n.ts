import Vue from 'vue'
import VueI18n from 'vue-i18n'
import { zhTW } from '@/locale'

Vue.use(VueI18n);

export default new VueI18n({
	locale: 'zh_TW',
	messages: {
		'zh_TW': zhTW
	}
})