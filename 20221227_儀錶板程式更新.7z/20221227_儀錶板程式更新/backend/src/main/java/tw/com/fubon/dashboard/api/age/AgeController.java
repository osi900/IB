package tw.com.fubon.dashboard.api.age;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.RegExUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tw.com.fubon.dashboard.api.ControllerBase;
import tw.com.fubon.dashboard.service.DmsService;
import tw.com.fubon.dashboard.utils.ExcelGenerator;
import tw.com.fubon.dashboard.utils.StringUtil;

@RestController
@RequestMapping(path = "/age")
public class AgeController extends ControllerBase {

	@Autowired
	private DmsService dao;
	
	@RequestMapping(path = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public AgeResponse getData(@RequestBody AgeRequest rq) {
		String snapMonth = rq.getSnapDate();
		String whereCondition = StringUtil.generateSqlConditions(rq.getConditions(), getLoginUser().getJoinAccts());
		whereCondition = replaceConditions(whereCondition);
		logger.info("snapMonth: {}, whereCondition: {}", snapMonth, whereCondition);
		
		AgeResponse rs = new AgeResponse();
		rs.setData(dao.getAgeDataDistrb(snapMonth, whereCondition));
		return rs;
	}

	private String replaceConditions(String where){
		if(!StringUtils.isBlank(where)){
			where = RegExUtils.replaceAll(where, "AGE_DESC = '0-19歲'", "(age < 20)");
			where = RegExUtils.replaceAll(where, "AGE_DESC = '20-30歲'", "(age >= 20 and age <= 30)");
			where = RegExUtils.replaceAll(where, "AGE_DESC = '31-40歲'", "(age > 30 and age <= 40)");
			where = RegExUtils.replaceAll(where, "AGE_DESC = '51-60歲'", "(age > 40 and age <= 50)");
			where = RegExUtils.replaceAll(where, "AGE_DESC = '41-50歲'", "(age > 50 and age <= 60)");
			where = RegExUtils.replaceAll(where, "AGE_DESC = '61歲以上'", "(age > 60)");
		}
		return where;
	}

	/**
	 * 匯出Excel
	 * @param data
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(path = "/exportExcel", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Resource> exportExcel(@RequestBody List<Map<String, String>> data) throws Exception {
		
		return ExcelGenerator.generate((workbook) -> {
			Sheet sheet = workbook.createSheet();
			
			Row headRow = sheet.createRow(0);
			headRow.createCell(0).setCellValue("年齡");
			headRow.createCell(1).setCellValue("全體戶數");
			headRow.createCell(2).setCellValue("全體佔比(%)");
			headRow.createCell(3).setCellValue("受眾戶數");
			headRow.createCell(4).setCellValue("受眾佔比(%)");
			
			DecimalFormat formater = new DecimalFormat("#,###");
			for (int i = 0; i < data.size(); i++) {
				Map<String, String> rcd = data.get(i);
				
				Row rcdRow = sheet.createRow(i + 1);
				rcdRow.createCell(0).setCellValue(rcd.get("label"));
				rcdRow.createCell(1).setCellValue(formater.format(Integer.valueOf(rcd.get("baseAcctCnt"))));
				rcdRow.createCell(2).setCellValue(rcd.get("baseProportion"));
				rcdRow.createCell(3).setCellValue(rcd.get("targetAcctCnt"));
				rcdRow.createCell(4).setCellValue(rcd.get("targetProportion"));
			}
		});
		
	}
}
