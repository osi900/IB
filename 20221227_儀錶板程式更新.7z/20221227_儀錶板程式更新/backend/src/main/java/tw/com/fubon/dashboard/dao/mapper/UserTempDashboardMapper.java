package tw.com.fubon.dashboard.dao.mapper;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.vo.UserTempDashboard;

public interface UserTempDashboardMapper {

	public void deleteByUserName(@Param("loginUser") String loginUser);
	
	public void insert(UserTempDashboard temp);
	
	public long countByUserAcct(@Param("loginUser") String loginUser);
}
