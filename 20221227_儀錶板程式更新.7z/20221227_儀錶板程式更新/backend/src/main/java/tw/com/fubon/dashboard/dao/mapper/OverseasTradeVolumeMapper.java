package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.overseastradevol.OverseasTradeData;

public interface OverseasTradeVolumeMapper {

    /**
     * 海外股月均交易量
     * @param snapDate
     * @return
     */
    public List<OverseasTradeData> getOverseasTradeVolume(
    		@Param("snapDate") String snapDate,
            @Param("conditions") String conditions);
	
}
