package tw.com.fubon.dashboard.api.prodcontribution;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class ProductContributionDistributionResponse extends ResponseBase {

	private List<ProductContributionDistributionData> data;
	
	private List<ProductContributionDistributionData> targetData;

	public List<ProductContributionDistributionData> getData() {
		return data;
	}

	public void setData(List<ProductContributionDistributionData> data) {
		this.data = data;
	}

	public List<ProductContributionDistributionData> getTargetData() {
		return targetData;
	}

	public void setTargetData(List<ProductContributionDistributionData> targetData) {
		this.targetData = targetData;
	}
	
}
