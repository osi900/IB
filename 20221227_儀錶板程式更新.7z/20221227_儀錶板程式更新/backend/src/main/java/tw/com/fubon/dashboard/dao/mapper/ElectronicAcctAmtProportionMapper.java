package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import tw.com.fubon.dashboard.api.electronicacctamt.ElectronicAcctAmtData;

public interface ElectronicAcctAmtProportionMapper {

    /**
     * 電子戶數及金額自佔率
     * @param snapDate
     * @return
     */
    public List<ElectronicAcctAmtData> getElectronicAcctAmtProportion(
    		@Param("snapDate") String snapDate,
            @Param("conditions") String conditions);
	
}
