package tw.com.fubon.dashboard.api.branch;

import tw.com.fubon.dashboard.api.RequestBase;

public class BranchRequest extends RequestBase {

}
