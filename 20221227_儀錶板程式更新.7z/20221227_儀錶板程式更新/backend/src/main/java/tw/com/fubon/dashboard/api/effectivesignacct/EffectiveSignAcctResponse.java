package tw.com.fubon.dashboard.api.effectivesignacct;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class EffectiveSignAcctResponse extends ResponseBase {

	private List<EffectiveSignAcctData> data;

	public List<EffectiveSignAcctData> getData() {
		return data;
	}

	public void setData(List<EffectiveSignAcctData> data) {
		this.data = data;
	}
	
}
