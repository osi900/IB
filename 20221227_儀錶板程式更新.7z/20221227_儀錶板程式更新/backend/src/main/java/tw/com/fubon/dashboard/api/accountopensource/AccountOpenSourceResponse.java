package tw.com.fubon.dashboard.api.accountopensource;

import java.util.List;

import tw.com.fubon.dashboard.api.ResponseBase;

public class AccountOpenSourceResponse extends ResponseBase {

	private List<AccountOpenSourceData> data;

    public List<AccountOpenSourceData> getData() {
        return data;
    }

    public void setData(List<AccountOpenSourceData> data) {
        this.data = data;
    }

	
	
}
