package tw.com.fubon.dashboard.api.electronicacctamt;

import tw.com.fubon.dashboard.api.RequestBase;

public class ElectronicAcctAmtRequest extends RequestBase {

}
