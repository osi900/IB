package tw.com.fubon.dashboard.dao.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import tw.com.fubon.dashboard.dao.bean.Tags;
import tw.com.fubon.dashboard.dao.bean.TagsExample;

public interface TagsMapper {
    long countByExample(TagsExample example);

    int deleteByExample(TagsExample example);

    int deleteByPrimaryKey(Long tagId);

    int insert(Tags record);

    int insertSelective(Tags record);

    List<Tags> selectByExample(TagsExample example);

    Tags selectByPrimaryKey(Long tagId);

    int updateByExampleSelective(@Param("record") Tags record, @Param("example") TagsExample example);

    int updateByExample(@Param("record") Tags record, @Param("example") TagsExample example);

    int updateByPrimaryKeySelective(Tags record);

    int updateByPrimaryKey(Tags record);
}