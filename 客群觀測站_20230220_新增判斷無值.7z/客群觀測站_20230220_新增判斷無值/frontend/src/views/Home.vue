<template>
	<div id="wrapper">
		<!-- 左方標籤 -->
		<LeftMenu ref="leftMenu"></LeftMenu>
		<div id="content-wrapper" class="d-flex flex-column pt-2">
			<div id="content">
				<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
					<!-- 漢堡選單 -->
					<button class="btn btn-link d-md-none rounded-circle mr-3">
						<i class="fa fa-bars"></i>
					</button>
					<!-- 上傳客戶帳號 -->
					<div class="input-group col-3">
						<input @click="selectFile" type="text" class="form-control" placeholder="" v-model="filename" readonly="readonly">
						<div class="input-group-append">
							<span @click="selectFile" class="input-group-text">
								<i v-if="!uploaded" class="fas fa-upload"></i>
								<i v-if="uploaded" class="fas fa-trash"></i>
							</span>
							<input ref="file" @change="fileChanged($event)" type="file" name="file" style="display: none;" />
						</div>
					</div>
					<!-- 匯出SQL指令 -->
					<button @click="exportSQL" class="btn btn-info mr-3">{{ $t('button.export.sql') }}</button>
				</nav>
				<div class="container-fluid">
					<div class="d-sm-flex align-items-center justify-content-between mb-4">
						<h1 class="h3 mb-0 text-gray-800">{{ $t('home.greeting', [$store.state.username]) }}</h1>
						<!-- 清除所有條件 -->
						<button @click="clearFilters()" class="btn btn-primary">{{ $t('home.clear.filters') }}</button>
					</div>
					<div class="d-sm-flex align-items-center justify-content-between mb-4">
						<h4 class="h4 mb-0 text-gray-800">
							<div class="form-inline">
								<!-- 資料年月 -->
								<label>{{ $t('home.data.time') }}：</label>
								<a>{{ ($store.state.snapDate != null ? $store.state.snapDate.text : '') }}</a>
							</div>
						</h4>
						<!-- 登出 -->
						<button v-if="!$store.state.token" @click="logout" class="btn btn-primary">{{ $t('home.logout') }}</button>
					</div>
					<div class="d-sm-flex align-items-center justify-content-between mb-4">
						<div class="dropdown">
							<!-- 點選查看其他年月資料： -->
							<button class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								{{ $t('home.change.data.time') }}
							</button>
							<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
								<a v-for="(dt, i) in $store.state.snapDates" :key="i" :value="dt.value" class="dropdown-item" @click="changeSnapDt(dt)">{{ dt.label }}</a>
							</div>
						</div>
					</div>
					<div class="row text-left">
						<!-- 原始戶數 -->
						<div class="col-xl-3 col-md-6 mb-4">
							<div class="card border-left-primary shadow h-100 py-2">
								<div class="card-body">
									<div class="row no-gutters align-items-center">
										<div class="col mr-2">
											<div class="text-sm font-weight-bold text-primary text-uppercase mb-1">{{ $t('home.original.number.of.accounts') }}</div>
											<div class="h5 mb-0 font-weight-bold text-gray-800">{{ $t('home.account.count', [formatNumber($store.state.total)]) }}</div>
										</div>
										<div class="col-auto">
											<i class="fas fa-users fa-2x text-gray-300"></i>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- 篩選後戶數 -->
						<div class="col-xl-3 col-md-6 mb-4">
							<div class="card border-left-success shadow h-100 py-2">
								<div class="card-body">
									<div class="row no-gutters align-items-center">
										<div class="col mr-2">
											<div class="text-sm font-weight-bold text-success text-uppercase mb-1">
												{{ $t('home.filtered.counts') }}
											</div>
											<div class="h5 mb-0 font-weight-bold text-gray-800">
												{{ $t('home.account.count', [formatNumber($store.state.filteredCount)]) }}
											</div>
											<div class="h6 mb-0  mt-1 font-weight-bold text-gray-800">
												{{ $t('home.percent.of.original', [$store.state.percentage]) }}
											</div>
										</div>
										<div class="col-auto">
											<i class="fas fa-user-circle fa-2x text-gray-300"></i>
										</div>
									</div>
									<br/>
									
									<div class="dropdown">
										<!-- 標籤群組 -->
										<button class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
											{{ currTagGroup ? currTagGroup.name : $t('tag.group') }}
										</button>
										<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
											<a v-for="(g, i) in $store.state.tagGroups" :key="i" :value="g.id" class="dropdown-item" @click="selectTagGroup(g)">{{ g.name }}</a>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- 篩選條件內容 -->
						<div class="col-xl-6 col-md-6 mb-4" ref="filters">
							<div class="card border-left-info shadow h-100 py-2">
								<div class="card-body">
									<div class="row no-gutters align-items-center">
										<div class="col mr-2">
											<div class="text-sm font-weight-bold text-info text-uppercase mb-1">
												{{ $t('home.filter.content') }}
												<a class="text-sm font-weight-bold text-danger text-uppercase mb-1">{{ $t('home.filter.content.desc') }}</a>
											</div>
											<div class="row no-gutters align-items-center">
												<div class="h8 mb-0 font-weight-bold text-gray-800">
													<template v-for="(c, k) of $store.state.conditions" >
														<button v-if="k != 'snapYYYYMM'" :key="k" @click="onClickFilter(k)" data-toggle="modal" class="btn btn-danger text-center mb-2 px-2 btn-sm mr-1">{{ getButtonName(k) }}</button>
													</template>
												</div>
											</div>
										</div>
										<div class="col-auto">
											<i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
										</div>
									</div>
									<!-- 儲存為標籤群組 -->
									<button @click="popTagGroup" class="btn btn-primary">{{ $t('save.as.tag.group') }}</button>
								</div>
							</div>
						</div>
					</div>
					
					<div ref="charts" class="row">
						
					</div>
					
				</div>
			</div>
		</div>
		<ChartModal ref="chartModal"></ChartModal>
		<SaveTagGroupModal ref="saveTagGroupModal"></SaveTagGroupModal>
		<ExportSQLModal ref="exportSQLModal"></ExportSQLModal>
		<LogoutModal ref="logoutModal"></LogoutModal>
	</div>
</template>

<style scoped>
@import '@/assets/css/style.css';

.text-left {
	text-align: left;
}

#content-wrapper {
	overflow: hidden;
}
</style>

<script type="ts" src="./Home.ts"></script>