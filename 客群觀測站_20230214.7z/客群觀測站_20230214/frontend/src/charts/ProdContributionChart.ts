import ChartTabs from "@/charts/ChartTabs.vue";
import { DataUtils } from "@/commons/DataUtils";
import { NumberUtils } from '@/commons/utilities/number.utils';
import * as echarts from "echarts";
import { Component } from "vue-property-decorator";

/**
 * 產品貢獻度分布
 */
@Component({
	components: {
		ChartTabs,
	},
})
export default class ProdContributionChart extends ChartTabs {
	
	chartSpan: number;
	
	title: string;

	chart: any;

	option: any;

	data: unknown[];
	
	hasFilter: boolean;
	
	/**
	 * 建構子
	 */
	constructor() {
		super();
		this.chartSpan = 2;
		this.title = "產品貢獻度分布";
		this.chart = null;
		this.data = [];
		this.hasFilter = false;
	}

	/**
	 * 顯示圖表modal
	 */
	showModal() {
		this.$store.commit("showChartModal", {
			title: this.title,
			tabs: [
				{ name: "圖", option: this.option },
				{ name: "表", html: this.$refs.prodContributionTable },
			],
		});
	}

	/**
	 * 開始繪圖
	 */
	draw() {
		new DataUtils(this).getData("/prod_contribute/", (data: any) => {
			if (data) {
				this.hasFilter = this.checkFilter();
				const formatUtil = echarts.format;

				const commodityProduct: Record<string, any> = {
					cateName: '經紀商品',
					cateBgColor:'bg-warning',
					prodBgColor:'table-warning',
					productNames: [
						"台股",
						"台股定期定額",
						"信用",
						"不限用途",
						"通路借入",
						"期貨",
					],
					datas: [],
					targetData: [],
					rowSpan: 1
				};
				
				
				const finMgmProduct: Record<string, any> = {
					cateName: '財管商品',
					cateBgColor:'bg-success',
					prodBgColor:'table-success',
					productNames: ["海外股", "基金", "海外債", "結構型", "保險"],
					datas: [],
					targetData: [],
					rowSpan: 1
				};
				
				let maxY = 0;
				const accts: number[] = [];
				const targetAccts: number[] = [];
				
				const contributionProportion: number[] = [];
				const contributionProportionTarget: number[] = [];
				
				// 滲透率
				const participationRate: number[] = [];
				const participationRateTarget: number[] = []; 

				for (let i = 0; i < data.data.length; i++) {
					const dat = data.data[i];
					const prodName = dat["product"];
					
					// 全體
					accts.push(dat['accountCnt']);
					contributionProportion.push(dat['contributionProportion'])
					participationRate.push(dat['participationRate']);
					if (commodityProduct.productNames.includes(prodName)) {
						commodityProduct.datas.push(dat);
					}
					if (!commodityProduct.productNames.includes(prodName)) {
						finMgmProduct.datas.push(dat);
					}
					
					// 受眾
					if (data.targetData) {
						targetAccts.push(data.targetData[i]['accountCnt']);
						contributionProportionTarget.push(data.targetData[i]['contributionProportion'])
						participationRateTarget.push(data.targetData[i]['participationRate']);
						if (commodityProduct.productNames.includes(prodName)) {
							commodityProduct.targetData.push(data.targetData[i]);
						}
						if (!commodityProduct.productNames.includes(prodName)) {
							finMgmProduct.targetData.push(data.targetData[i]);
						}
					} else {
						targetAccts.push(0);
						contributionProportionTarget.push(0)
						commodityProduct.targetData.push(0);
						finMgmProduct.targetData.push(0);
					}
					
				}
				commodityProduct.rowSpan = commodityProduct.datas.length;
				finMgmProduct.rowSpan = finMgmProduct.datas.length;
				
				if (!this.chart) {
					const el = this.$refs.prodContributionChart as HTMLElement;
					this.chart = echarts.init(el);
				}
				maxY = Math.max(...participationRate, ...participationRateTarget);
				const xLabel: string[] = [...commodityProduct.productNames, ...finMgmProduct.productNames];
				const allData: any[] = [...commodityProduct.datas, ...finMgmProduct.datas];
				const allTargetData: any[] = [...commodityProduct.targetData, ...finMgmProduct.targetData];
				
				this.option = {
					title: {},
					tooltip: {
						trigger: "axis",
						formatter: function (params: any) {
							let res = '';
							for (let i = 0; i < params.length; i++) {
								if (params[i].seriesName === '全體') {
									const dt = allData.find(d => d['product'] == params[i].name);
									res += `<div style="color: #000;font-size: 14px; padding:0 6px;line-height: 24px">
									<span class="tooltip_icon_base"></span>	
									<strong>${params[i].seriesName} (${params[i].name})</strong><br/>
										戶數: <strong>${formatUtil.addCommas(dt['accountCnt'])}</strong>戶<br/>
										年累貢獻度(新台幣/千元): <strong>${formatUtil.addCommas(dt['contributionYearly'])}</strong><br/>
										戶均貢獻度佔比: <strong>${formatUtil.addCommas(dt['contributionProportion'])}</strong><br/>
									</div><br/>`;
									
								} else {
									const dt = allTargetData.find(d => d['product'] == params[i].name);
									res += `<div style="color: #000;font-size: 14px; padding:0 6px;line-height: 24px">
										<span class="tooltip_icon_target"></span>
										<strong>${params[i].seriesName} (${params[i].name})</strong><br/>
										戶數: <strong>${formatUtil.addCommas(dt['accountCnt'])}</strong>戶<br/>
										年累貢獻度(新台幣/千元): <strong>${formatUtil.addCommas(dt['contributionYearly'])}</strong><br/>
										戶均貢獻度佔比: <strong>${formatUtil.addCommas(dt['contributionProportion'])}</strong>
									</div>`;
								}
								
							}
							return res;
						},
					},
					legend: {
						data: ["全體", "受眾"],
					},
					xAxis: {
						type: "category",
						data: xLabel,
					},
					yAxis: {
						type: "value",
						min: 0,
						max: maxY,
						name: "產品滲透率(%)",
					},
					series: [
						{
							name: "全體",
							data: participationRate,
							type: "bar",
							label: {
								show: true,
								position: "top"
							},
						},
						{
							name: "受眾",
							data: participationRateTarget,
							type: "bar",
							label: {
								show: true,
								position: "top"
							},
						},
					],
				};
				
				this.chart.setOption(this.option);

				this.data = [commodityProduct, finMgmProduct];
				window.addEventListener('resize', this.resizeTheChart);
			}
		});
	}

	resizeTheChart() {
		if (this.chart) {
			this.chart.resize()
		}
	}

	formatFloat(num: string, pt: number) {
		if (!num) {
			num = '0';
		}
		return (parseFloat(num)).toFixed(pt);
	}

	formatNumber(num: string) {
		if (!num) {
			return '0';
		}
		return NumberUtils.commafy(num+'');
	}
	
	updateProdName(name: string): string {
		if(name == '定期定額'){
			return '台股' + name;
		}
		return name;
	}

	/**
	 * 匯出Excel
	 */
	exportExcel() {
		new DataUtils(this).download("/prod_contribute/exportExcel", this.data, this.title + '.xlsx');
	}
	
	checkFilter(): boolean {
		const conditions = this.$store.state.conditions;
		const allConditionKeys = Object.keys(conditions);

		allConditionKeys.splice(
			allConditionKeys.findIndex((ack) => ack == "snapYYYYMM"),
			1
		);
		console.info("allConditionKeys: ", allConditionKeys);
		return allConditionKeys.length > 0 || this.$store.state.uploaded;
	}
}
