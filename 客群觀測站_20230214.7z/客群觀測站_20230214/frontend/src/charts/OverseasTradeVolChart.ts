import ChartTabs from "@/charts/ChartTabs.vue";
import { DataUtils } from "@/commons/DataUtils";
import { NumberUtils } from "@/commons/utilities/number.utils";
import * as echarts from "echarts";
import { Component } from "vue-property-decorator";
@Component({
  components: {
    ChartTabs,
  },
})
export default class OverseasTradeVolChart extends ChartTabs {
  chartSpan: number;

  title: string;

  chart: any;

  option: any;

  data: unknown[];
  dataForTable: unknown[];
  /**
   * 建構子
   */
  constructor() {
    super();
    this.chartSpan = 2;
    this.title = "海外股月均交易量";
    this.chart = null;
    this.data = [];
	this.dataForTable = [];
  }

  /**
   * 顯示圖表modal
   */
  showModal() {
    this.$store.commit("showChartModal", {
      title: this.title,
      tabs: [
        { name: "圖", option: this.option },
        { name: "表", html: this.$refs.overseasTradeVolTable },
      ],
    });
  }

  /**
   * 開始繪圖
   */
  draw() {
    new DataUtils(this).getData("/overseasTradeVolme/", (data: any) => {
      if (data && data.data) {
        const formatUtil = echarts.format;

        const avgMonthlyTradVolCIs = [];
        const sampleAccts: number[] = [];
        const targetAccts: number[] = [];
        const sampleActRatios: number[] = [];
        const targetActRatios: number[] = [];
        const targetTxRatios: number[] = [];

        let maxY = 0;
        for (let i = 0; i < data.data.length; i++) {
          const data_ = data.data[i];

          data_["sampleAcctShow"] = formatUtil.addCommas(data_["sampleAcct"]);
          data_["targetAcctShow"] = formatUtil.addCommas(data_["targetAcct"]);

          const avgMonthlyTradVolCI = data.data[i]["avgMonthlyTradVolCI"];
          const sampleAcct = data.data[i]["sampleAcct"];
          const targetAcct = data.data[i]["targetAcct"];
          const sampleActRatio = data.data[i]["sampleActRatio"];
          const targetActRatio = data.data[i]["targetActRatio"];
          const targetTxRatio = data.data[i]["targetTxRatio"];

          avgMonthlyTradVolCIs.push(avgMonthlyTradVolCI);
          sampleAccts.push(sampleAcct);
          targetAccts.push(targetAcct);
          sampleActRatios.push(sampleActRatio);
          targetActRatios.push(targetActRatio);
          targetTxRatios.push(targetTxRatio);
        }
        maxY = Math.max(...sampleActRatios, ...targetActRatios);

        if (!this.chart) {
          const el = this.$refs.overseasTradeVolChart as HTMLElement;
          this.chart = echarts.init(el);
        }

        this.option = {
          title: {},
          tooltip: {
            trigger: "axis",
            formatter: function (params: any) {
              let res = "";
              for (let i = 0; i < params.length; i++) {
                const isBase = params[i].seriesName === '全體';
                res += `<div style="color: #000;font-size: 14px; padding:0 6px;line-height: 24px">
			  							<strong>${params[i].seriesName}</strong><br/>
			  							<span class="${isBase ? 'tooltip_icon_base' : 'tooltip_icon_target'}"></span>
                      ${params[0].axisValue}: <strong>${
                        isBase ?
                        formatUtil.addCommas(sampleAccts[params[i].dataIndex]) :
                        formatUtil.addCommas(targetAccts[params[i].dataIndex])
              }</strong> 戶
									</div>`;
              }
              return res;
            },
          },
          legend: {
            data: ["全體", "受眾"],
          },
          xAxis: {
            type: "category",
            data: avgMonthlyTradVolCIs,
            axisLabel: {
              interval: 0,
              rotate: "25",
              align: "right",
            },
          },
          yAxis: {
            type: "value",
            min: 0,
            max: maxY,
            name: "交易戶數佔比(%)",
          },
          series: [
            {
              name: "全體",
              data: sampleActRatios,
              type: "bar",
              label: {
                show: true,
                position: "top",
              },
            },
            {
              name: "受眾",
              data: targetActRatios,
              type: "bar",
              label: {
                show: true,
                position: "top",
              },
            },
          ],
        };

        this.chart.setOption(this.option);

        this.data = data.data;
		this.dataForTable = data.data;
		
		this.dataForTable.sort( (a: any, b: any) => {
			const strA = b['seq'];
			const strB = a['seq'];
			if (strA < strB) {
				return -1;
			}
			if (strA > strB) {
				return 1;
			}
			return 0;
		});
        window.addEventListener("resize", this.resizeTheChart);
      }
    });
  }

  resizeTheChart() {
    if (this.chart) {
      this.chart.resize();
    }
  }

  /**
   * 匯出Excel
   */
  exportExcel() {
    new DataUtils(this).download(
      "/overseasTradeVolme/exportExcel",
      this.data,
      this.title + ".xlsx"
    );
  }

  formatNumber(num: string) {
    if (!num) {
      return "0";
    }
    return NumberUtils.commafy(num + "");
  }
}
