package pagecode.caatx.caatx007;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.fubon.tw.pib.persistence.b2c.dao.ICaaApplyDataDAO;
import com.fubon.tw.pib.persistence.b2c.entity.CaaApplyDataEntity;
import com.ibm.tw.commons.error.SeverityType;
import com.ibm.tw.commons.exception.ActionException;
import com.ibm.tw.commons.persistence.dao.DataAccessObjectFactory;
import com.ibm.tw.pib.b2cweb.biz.uaa.CAAWebUser;
import com.ibm.tw.pib.b2cweb.util.B2CWebUtils;
import com.ibm.tw.pib.exception.PibErrorCode;
import com.ibm.tw.pib.system.PibSystemId;
import com.ibm.tw.pib.type.BundleType;

import pagecode.momo.MomoVo;
import pagecode.momo.MomoVo.LoginType;

/**
 * PLDC共用程式
 * 
 * @author jimmywu
 *
 */
public class CAATX007Helper {

	public static final String STEP_READ_RULE = "Rule";
	public static final String STEP_UPLOAD_ID = "Upload_Id";
	public static final String STEP_UPLOAD_OTHER = "Upload_Other";
	public static final String STEP_INPUT = "Input";
	public static final String STEP_CHOOSE_CARD = "Choose_Card";
	public static final String STEP_CONFIRM_APPLY = "Apply";

	public static final String APPLY_STATUS_SUCCESS = "SUCCESS";
	public static final String APPLY_STATUS_REJECT = "REJECT";
	public static final String APPLY_STATUS_REPAIR = "REPAIR";
	
	public static final String CASE_NO = "caseno";
	public static final String PRJ_CODE = "prjCode";

	private static Logger logger = Logger.getLogger(CAATX007Helper.class);

	/**
	 * 檢核申請資料 return [errorCode, errorMessage]
	 */
	public static enum CaaApplyDataValidateResult {
		OK,
		// 您已於 YYYY/MM/DD 送出申請！請點選下方「上 傳證件」按鈕進行上傳。如有疑問，請洽客戶服 務專線 02-8751-6665。
		// 登入驗證, 彈跳視窗阻擋
		ALREADY_COMPLETE_APPLY,
		// 您已於 YYYY/MM/DD 送出申請！若您是要「上傳證件」，須與上次您送出申請資料時，採「相同客戶身分」進行身分認證，方可上傳。如有疑問，請洽客戶服務專線 02-8751-6665。
		// 登入驗證, 彈跳視窗阻擋
		ALREADY_COMPLETE_APPLY_DIFFERENT_LOGIN_TYPE,
		// 您已於 YYYY/MM/DD 送出申請！目前無法再提出新申請或上傳申請文件。如有疑問，請洽客戶服務專線 02-87516665。 
		// 登入驗證, 彈跳視窗阻擋
		CANNOT_UPLOAD_YET,
		// 請先完成「填寫申請資料」，方可上傳證明文件！如有疑問，請洽客戶服務專線02-8751-6665。
//		NOT_COMPLETE_APPLY,
		// 您於 YYYY/MM/DD HH:MM:SS  尚有一筆申請未完成! 
		// 登入驗證, 彈跳視窗阻擋
		HAS_SAVED_DATA,
		// 您於 YYYY/MM/DD HH:MM:SS  尚有一筆申請未完成! 若您要繼續填寫申請，請與上次採「相同身分驗證方式」登入，如有疑問，請洽客戶服務專線02-87516665。 
		// 登入驗證, 彈跳視窗阻擋
		DIFFERENT_LOGIN_TYPE,
		// 已過期
		APPLY_DATA_EXPIRED,
		// 如您有「填寫申請資料」需求，請洽客戶服務專線02-8751-6665。
		UNKNOWN_ERROR;

		String message;
		boolean newData ;
		CaaApplyDataEntity applyData;

		void setMessage(String msg) {
			message = msg;
		}

		public String getMessage() {
			return message;
		}

		public CaaApplyDataEntity getApplyData() {
			return applyData;
		}

		void setApplyData(CaaApplyDataEntity applyData) {
			this.applyData = applyData;
		}
		public boolean isNewData() {
			return this.newData ;
		}
		public void setNewData(boolean newData) {
			this.newData = newData ;
		}
	};

	/**
	 * 取得並驗證使用者現有的CaaApplyData
	 * 
	 * @param loginUser
	 * @param applyStatus
	 * @param loginType
	 * @return
	 * @throws ActionException
	 */
	public static CaaApplyDataValidateResult validateApplyData(CAAWebUser loginUser, MomoVo momoVo) throws ActionException {
		// test 用
		// applyStatus = "5";
		CaaApplyDataValidateResult result = CaaApplyDataValidateResult.OK;
		try {
			ICaaApplyDataDAO applyDao = DataAccessObjectFactory.getDAO(ICaaApplyDataDAO.class);

			CaaApplyDataEntity applySuccessData = null; // 申請成功資料
			List<CaaApplyDataEntity> successDatas = applyDao.getPLDCSuccessedApplyDataByUserKeyTWM(loginUser.getUserKey());
			if (!successDatas.isEmpty()) {
				CaaApplyDataEntity data = successDatas.get(0);
				// 14天內
				Date applyTime = data.getApplyTime();
				Calendar expire = Calendar.getInstance();
				expire.setTime(applyTime);
				expire.add(Calendar.DAY_OF_MONTH, 14);

				// 未過期
				if (expire.after(Calendar.getInstance())) {
					applySuccessData = data;
				} else {
					result = CaaApplyDataValidateResult.APPLY_DATA_EXPIRED;
				}
			}

			CaaApplyDataEntity savedData = null; // 申請中資料
			List<CaaApplyDataEntity> savedDatas = applyDao.getPLDCSavedApplyDataByUserKeyTWM(loginUser.getUserKey());
			if (!savedDatas.isEmpty()) {
				CaaApplyDataEntity data = savedDatas.get(0);

				// 14天內
				Date updateTime = data.getUpdateTime();
				Calendar expire = Calendar.getInstance();
				expire.setTime(updateTime);
				expire.add(Calendar.DAY_OF_MONTH, 14);
				// 未過期
				if (expire.after(Calendar.getInstance())) {
					savedData = data;
				} else {
					if (applySuccessData == null || (applySuccessData != null
							&& applySuccessData.getUpdateTime().before(data.getUpdateTime()))) {
						result = CaaApplyDataValidateResult.APPLY_DATA_EXPIRED;
					}

				}
			}
			boolean isNewData = false ;
			CaaApplyDataEntity data = new CaaApplyDataEntity();
			if (savedData != null && applySuccessData != null) {
				data = savedData;
				applySuccessData = null;
			} else if (savedData != null) {
				data = savedData;
			} else if (applySuccessData != null) {
				data = applySuccessData;
			}
			else {
				isNewData = true ;
			}
			/* 20200514 Wing 退件狀態壓CNCL 新創一筆重新跑流程 */
			boolean applyReturn = StringUtils.isNotBlank(loginUser.getApplyStatus()) && "5".equals(loginUser.getApplyStatus())
					 && applySuccessData != null && StringUtils.isNotBlank(applySuccessData.getApplyStatus()) && "0000".equals(applySuccessData.getApplyStatus());
			if(applyReturn){
				applySuccessData.setApplyStatus("CNCL");
				applySuccessData.setApplyDesc("後端退件");
				ICaaApplyDataDAO dao = DataAccessObjectFactory.getDAO(ICaaApplyDataDAO.class);
				dao.update(applySuccessData);
				data = new CaaApplyDataEntity();
				isNewData = true ;
			}
			
			// 主機狀態5未申請
			if (("5".equals(loginUser.getApplyStatus()) && savedData == null) || ("5".equals(loginUser.getApplyStatus()) && applySuccessData != null
					&& "0000".equals(applySuccessData.getUploadStatus())) || applyReturn) {

				result = CaaApplyDataValidateResult.OK;
				CAAWebUser user = loginUser;
				String birthday = new SimpleDateFormat("yyyyMMdd").format(user.getBirthday());
				momoVo.setIdNo(user.getCompanyUid());
				momoVo.setCustBirth(birthday);
				result.setApplyData(data);
				result.setNewData(isNewData);
				return result;

			} else if ("5".equals(loginUser.getApplyStatus()) && savedData != null) {
				if (savedData.getLoginType().equals(momoVo.getLoginType().getLoginType())
						|| (LoginType.MOMO_CAA_SV.getLoginType().equals(savedData.getLoginType())
								&& LoginType.MOMO_CAA_SV.equals(momoVo.getLoginType()))
						|| (LoginType.MOMO_CAA_OSV.getLoginType().equals(savedData.getLoginType())
								&& LoginType.MOMO_CAA_OSV.equals(momoVo.getLoginType()))) {
					// 您於 YYYY/MM/DD HH:MM:SS  尚有一筆申請未完成!
					// 兩個按鈕, 繼續填寫和重新申請
					result = CaaApplyDataValidateResult.HAS_SAVED_DATA;
					result.setMessage(B2CWebUtils.getBundleString(BundleType.B2C, "caatx006.validate.status5SameType",
							new Object[] { String.format("%1$tY/%1$tm/%1$td %1$tH:%1$tM:%1$tS", savedData.getUpdateTime()) },
							loginUser.getLocale()));
				} else if (!savedData.getLoginType().equals(momoVo.getLoginType().getLoginType())) {
					// 您於 YYYY/MM/DD HH:MM:SS  尚有一筆申請未完成!若您要繼續填寫申請，請與上次採「相同身分驗證方式」登入，如有疑問，請洽客戶服務專線02-87516665。 
					result = CaaApplyDataValidateResult.DIFFERENT_LOGIN_TYPE;
					result.setMessage(B2CWebUtils.getBundleString(BundleType.B2C, "caatx006.validate.status5DiffType",
							new Object[] { String.format("%1$tY/%1$tm/%1$td %1$tH:%1$tM:%1$tS", savedData.getUpdateTime()) },
							loginUser.getLocale()));
				}

				// 主機狀態1申請中, 3待補件
			} else if (("1".equals(loginUser.getApplyStatus()) || "3".equals(loginUser.getApplyStatus())) && applySuccessData != null) {
				if (applySuccessData.getLoginType().equals(momoVo.getLoginType().getLoginType())) {
					// 您已於 YYYY/MM/DD 送出申請！請點選下方「上傳證件」按鈕進行上傳。如有疑問，請洽客戶服務專線 02-8751-6665。 
					result = CaaApplyDataValidateResult.ALREADY_COMPLETE_APPLY;
					result.setMessage(B2CWebUtils.getBundleString(BundleType.B2C, "caatx006.validate.status1Or3SameType",
							new Object[] { String.format("%1$tY/%1$tm/%1$td", applySuccessData.getApplyTime()) },
							loginUser.getLocale()));
				} else {
					// 您已於 YYYY/MM/DD 送出申請！若您是要「上傳證件」，須與上次您送出申請資料時，採「相同客戶身分」進行身分認證，方可上傳。如有疑問，請洽客戶服務專線 02-8751-6665。 
					result = CaaApplyDataValidateResult.ALREADY_COMPLETE_APPLY_DIFFERENT_LOGIN_TYPE;
					result.setMessage(B2CWebUtils.getBundleString(BundleType.B2C, "caatx006.validate.status1Or3DiffType",
							new Object[] { String.format("%1$tY/%1$tm/%1$td", applySuccessData.getApplyTime()) },
							loginUser.getLocale()));
				}


				// 主機狀態2未開戶, 4已補件
			} else if (("2".equals(loginUser.getApplyStatus()) || "4".equals(loginUser.getApplyStatus())) && applySuccessData != null
					&& "0000".equals(applySuccessData.getUploadStatus())) {
				// 您已於 YYYY/MM/DD 送出申請！目前無法再提出新申請或上傳申請文件。如有疑問，請洽客戶服務專線 02-87516665。 
				result = CaaApplyDataValidateResult.CANNOT_UPLOAD_YET;
				result.setMessage(B2CWebUtils.getBundleString(BundleType.B2C, "caatx006.validate.status2Or4",
						new Object[] { String.format("%1$tY/%1$tm/%1$td", applySuccessData.getUploadTime()) },
						loginUser.getLocale()));

				// 如您有「填寫申請資料」需求，請洽客戶服務專線02-8751-6665。
			} else {
				result = CaaApplyDataValidateResult.UNKNOWN_ERROR;
				result.setMessage(B2CWebUtils.getBundleString(BundleType.CAATX, "caatx006.home.unknownError"));
			}

			result.setApplyData(data);
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error(ex);
			throw new ActionException(PibSystemId.CAA.getSystemId(), PibErrorCode.UNKNOWN_EXCEPTION.getErrorCode(),
					SeverityType.ERROR, ex.getMessage());
		}

		return result;
	}
}
